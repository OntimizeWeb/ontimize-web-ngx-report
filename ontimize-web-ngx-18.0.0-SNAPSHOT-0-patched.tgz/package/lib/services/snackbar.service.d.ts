import { MatSnackBar, MatSnackBarRef } from '@angular/material/snack-bar';
import { OSnackBarComponent, OSnackBarConfig } from '../shared/components/snackbar/o-snackbar.component';
import * as i0 from "@angular/core";
export declare class SnackBarService {
    protected static DEFAULT_DURATION: number;
    protected static DEFAULT_CONTAINER_CLASS: string;
    protected matSnackBar: MatSnackBar;
    protected snackBarRef: MatSnackBarRef<OSnackBarComponent>;
    open(message: string, config?: OSnackBarConfig): Promise<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SnackBarService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SnackBarService>;
}
//# sourceMappingURL=snackbar.service.d.ts.map