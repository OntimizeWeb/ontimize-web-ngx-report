import { TemplateRef } from '@angular/core';
import { ThemePalette } from '@angular/material/core';
import { MatTabHeaderPosition } from '@angular/material/tabs';
import { OFormLayoutManagerComponent } from '../../o-form-layout-manager.component';
import * as i0 from "@angular/core";
export declare class OFormLayoutTabGroupOptionsDirective {
    protected formLayoutManager: OFormLayoutManagerComponent;
    constructor(formLayoutManager: OFormLayoutManagerComponent);
    ngOnChanges(): void;
    backgroundColor: ThemePalette;
    color: ThemePalette;
    protected _disableAnimation: boolean;
    set disableAnimation(value: boolean);
    headerPosition: MatTabHeaderPosition;
    icon: string;
    iconPosition: 'left' | 'right';
    titleDataOrigin: string;
    title: string;
    labelColumns: string;
    separator: string;
    protected _maxTabs: number;
    set maxTabs(value: number);
    set stretchTabs(value: boolean);
    protected _stretchTabs: boolean;
    templateMatTabLabel: TemplateRef<any>;
    getOptions(): Object;
    static ɵfac: i0.ɵɵFactoryDeclaration<OFormLayoutTabGroupOptionsDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OFormLayoutTabGroupOptionsDirective, "o-form-layout-tabgroup-options, o-form-layout-manager[mode=\"tab\"]", never, { "backgroundColor": "background-color"; "color": "color"; "disableAnimation": "disable-animation"; "headerPosition": "header-position"; "icon": "icon"; "iconPosition": "icon-position"; "titleDataOrigin": "title-data-origin"; "title": "title"; "labelColumns": "label-columns"; "separator": "separator"; "maxTabs": "max-tabs"; "stretchTabs": "stretch-tabs"; }, {}, ["templateMatTabLabel"], never, false, never>;
}
//# sourceMappingURL=o-form-layout-tabgroup-options.directive.d.ts.map