import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, Subscription } from 'rxjs';
import { AppConfig } from '../config/app-config';
import { ServiceResponse } from '../interfaces/service-response.interface';
import { ORemoteConfigurationColumns } from '../types/remote-configuration.type';
import { SessionInfo } from '../types/session-info.type';
import { AuthService } from './auth.service';
import { LocalStorageService } from './local-storage.service';
import * as i0 from "@angular/core";
export declare class ORemoteConfigurationService {
    static DEFAULT_COLUMN_USER: string;
    static DEFAULT_COLUMN_APPID: string;
    static DEFAULT_COLUMN_CONFIG: string;
    static DEFAULT_STORAGE_TIMEOUT: number;
    protected localStorageService: LocalStorageService;
    protected authService: AuthService;
    protected httpClient: HttpClient;
    protected _appConfig: AppConfig;
    protected _url: string;
    protected _uuid: string;
    protected _timeout: number;
    protected timerSubscription: Subscription;
    protected storeSubscription: Subscription;
    protected _columns: ORemoteConfigurationColumns;
    beforeunloadHandler(): void;
    constructor();
    getUserConfiguration(): Observable<ServiceResponse>;
    storeUserConfiguration(): Observable<any>;
    initialize(): Observable<any>;
    finalize(): Observable<any>;
    protected hasSession(sessionInfo: SessionInfo): boolean;
    protected buildHeaders(): HttpHeaders;
    static ɵfac: i0.ɵɵFactoryDeclaration<ORemoteConfigurationService, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ORemoteConfigurationService, never, never, {}, {}, never, never, false, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ORemoteConfigurationService>;
}
//# sourceMappingURL=remote-config.service.d.ts.map