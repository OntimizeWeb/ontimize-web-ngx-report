import { Injector, OnDestroy, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { IExportService } from '../../../../../interfaces/export-service.interface';
import { SnackBarService } from '../../../../../services/snackbar.service';
import { OTranslateService } from '../../../../../services/translate/o-translate.service';
import { OTableExportButtonService } from '../../export-button/o-table-export-button.service';
import { OTableExportConfiguration } from '../../header/table-menu/o-table-export-configuration.class';
import * as i0 from "@angular/core";
export declare class OTableExportDialogComponent implements OnInit, OnDestroy {
    dialogRef: MatDialogRef<OTableExportDialogComponent>;
    protected injector: Injector;
    config: OTableExportConfiguration;
    protected snackBarService: SnackBarService;
    protected exportService: IExportService;
    protected translateService: OTranslateService;
    protected oTableExportButtonService: OTableExportButtonService;
    protected visibleButtons: string[];
    private subscription;
    private appConfig;
    constructor(dialogRef: MatDialogRef<OTableExportDialogComponent>, injector: Injector, config: OTableExportConfiguration);
    ngOnInit(): void;
    ngOnDestroy(): void;
    initialize(): void;
    configureService(): void;
    export(exportType: string, button?: any): void;
    isButtonVisible(btn: string): boolean;
    protected handleError(err: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableExportDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTableExportDialogComponent, "o-table-export-dialog", never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=o-table-export-dialog.component.d.ts.map