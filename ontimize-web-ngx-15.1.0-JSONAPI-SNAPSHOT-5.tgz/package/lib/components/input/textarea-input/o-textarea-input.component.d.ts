import { ElementRef, Injector } from '@angular/core';
import { OFormComponent } from '../../form/o-form.component';
import { OTextInputComponent } from '../text-input/o-text-input.component';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_TEXTAREA_INPUT: string[];
export declare class OTextareaInputComponent extends OTextInputComponent {
    rows: number;
    columns: number;
    constructor(form: OFormComponent, elRef: ElementRef, injector: Injector);
    isResizable(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTextareaInputComponent, [{ optional: true; }, null, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTextareaInputComponent, "o-textarea-input", never, { "columns": "columns"; "rows": "rows"; }, {}, never, never, false, never>;
}
//# sourceMappingURL=o-textarea-input.component.d.ts.map