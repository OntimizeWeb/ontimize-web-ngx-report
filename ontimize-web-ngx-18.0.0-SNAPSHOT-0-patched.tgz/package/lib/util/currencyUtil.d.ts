export declare class CurrencyUtil {
    static languageToCurrencyCode: {
        es: string;
        en: string;
        pt: string;
        fr: string;
        de: string;
        it: string;
        ja: string;
        zh: string;
        ru: string;
        ar: string;
        cr: string;
        ng: string;
        ph: string;
        pl: string;
        py: string;
        th: string;
        ua: string;
        vn: string;
    };
    static currencyCodeToSymbol: {
        EUR: string;
        USD: string;
        BRL: string;
        JPY: string;
        CNY: string;
        RUB: string;
        AED: string;
        CRC: string;
        NGN: string;
        PHP: string;
        PLN: string;
        PYG: string;
        THB: string;
        UAH: string;
        VND: string;
    };
    static getCurrencyCode(language: string): string;
    static getCurrencyCodeFromSymbol(symbol: string): string | undefined;
}
//# sourceMappingURL=currencyUtil.d.ts.map