import { AfterViewInit, ElementRef, Injector, OnDestroy } from '@angular/core';
import { Observable, Subscription } from 'rxjs';
import { AppearanceService } from '../services/appearance.service';
import * as i0 from "@angular/core";
export declare abstract class OSkeletonComponent implements AfterViewInit, OnDestroy {
    protected injector: Injector;
    protected elRef: ElementRef;
    isDarkMode: boolean;
    subscription: Subscription;
    appearanceService: AppearanceService;
    rows$: Observable<number[]>;
    private readonly cd;
    constructor(injector: Injector, elRef: ElementRef);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    abstract getRows(): number[];
    static ɵfac: i0.ɵɵFactoryDeclaration<OSkeletonComponent, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OSkeletonComponent, never, never, {}, {}, never, never, true, never>;
}
//# sourceMappingURL=o-skeleton.component.d.ts.map