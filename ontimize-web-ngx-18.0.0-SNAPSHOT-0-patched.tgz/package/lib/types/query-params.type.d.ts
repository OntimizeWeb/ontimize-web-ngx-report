import { OQueryDataArgs } from "./query-data-args.type";
import { SQLOrder } from "./sql-order.type";
export type OQueryParams = {
    filter: Object;
    columns: string[];
    entity: string;
    pageable?: boolean;
    sqlTypes?: Object;
    sort?: SQLOrder[];
    ovrrArgs?: OQueryDataArgs;
};
//# sourceMappingURL=query-params.type.d.ts.map