import { ElementRef, OnDestroy, Renderer2 } from '@angular/core';
import { OFormServiceComponent } from '../components/input/o-form-service-component.class';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_LOCKER: string[];
export declare class OLockerDirective implements OnDestroy {
    private element;
    private renderer;
    private parent;
    private loadingParentDiv;
    private componentDiv;
    private _oLockerMode;
    private subscription;
    constructor(element: ElementRef, renderer: Renderer2, parent: OFormServiceComponent);
    ngOnDestroy(): void;
    private manageLockerMode;
    private manageDisableMode;
    private manageLoadMode;
    private addLoading;
    private removeLoading;
    set oLockerMode(value: 'load' | 'disabled');
    set oLockerDelay(value: number);
    static ɵfac: i0.ɵɵFactoryDeclaration<OLockerDirective, [null, null, { optional: true; host: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OLockerDirective, "[oLocker]", never, { "oLockerMode": { "alias": "oLockerMode"; "required": false; }; "oLockerDelay": { "alias": "oLockerDelay"; "required": false; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=locker.directive.d.ts.map