export type OFormLayoutSidenavOptions = {
    width?: string;
    position?: 'start' | 'end';
    labelColumns?: string;
    separator?: string;
};
//# sourceMappingURL=form-layout-sidenav-options.type.d.ts.map