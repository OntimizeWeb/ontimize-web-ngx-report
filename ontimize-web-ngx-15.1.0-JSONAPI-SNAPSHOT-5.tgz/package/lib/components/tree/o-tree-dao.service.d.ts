import { BehaviorSubject } from 'rxjs';
import { OTreeFlatNode } from './o-tree.component';
import * as i0 from "@angular/core";
export declare class OTreeDao {
    protected _isLoadingResults: boolean;
    protected loadingTimer: any;
    dataChange: BehaviorSubject<any[]>;
    sqlTypesChange: BehaviorSubject<object>;
    get data(): any[];
    rootLevelNodes: OTreeFlatNode[];
    flatNodeMap: Map<OTreeFlatNode, any>;
    setDataArray(data: Array<any>): import("rxjs").Observable<any[]>;
    get isLoadingResults(): boolean;
    set isLoadingResults(val: boolean);
    protected cleanTimer(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTreeDao, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OTreeDao>;
}
//# sourceMappingURL=o-tree-dao.service.d.ts.map