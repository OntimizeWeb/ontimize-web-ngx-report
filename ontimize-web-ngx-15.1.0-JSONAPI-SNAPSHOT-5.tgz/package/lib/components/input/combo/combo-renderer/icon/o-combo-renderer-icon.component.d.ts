import { Injector, OnInit, TemplateRef } from '@angular/core';
import { SafeHtml } from '@angular/platform-browser';
import { IIconPipeArgument, OIconPipe } from '../../../../../pipes/o-icon.pipe';
import { IconService } from '../../../../../services/icon.service';
import { OComboCustomRenderer } from '../o-combo-renderer.class';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_COMBO_RENDERER_ICON: string[];
export declare class OComboRendererIconComponent extends OComboCustomRenderer implements OnInit {
    protected injector: Injector;
    protected iconService: IconService;
    protected iconColumn: string;
    protected iconPosition: string;
    protected componentPipe: OIconPipe;
    protected pipeArguments: IIconPipeArgument;
    templateref: TemplateRef<any>;
    constructor(injector: Injector);
    setComponentPipe(): void;
    initialize(): void;
    getComboData(record: any): string;
    getSafeHtmlComboData(record: any): SafeHtml;
    static ɵfac: i0.ɵɵFactoryDeclaration<OComboRendererIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OComboRendererIconComponent, "o-combo-renderer-icon", never, { "iconPosition": "icon-position"; "iconColumn": "icon-column"; }, {}, never, never, false, never>;
}
//# sourceMappingURL=o-combo-renderer-icon.component.d.ts.map