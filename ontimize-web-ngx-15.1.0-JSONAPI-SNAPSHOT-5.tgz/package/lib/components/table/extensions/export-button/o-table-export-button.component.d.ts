import { EventEmitter, Injector } from '@angular/core';
import { OTableExportButtonService } from './o-table-export-button.service';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_TABLE_EXPORT_BUTTON: string[];
export declare const DEFAULT_OUTPUTS_O_TABLE_EXPORT_BUTTON: string[];
export declare class OTableExportButtonComponent {
    private injector;
    icon: string;
    svgIcon: string;
    olabel: string;
    onClick: EventEmitter<any>;
    protected exportType: string;
    protected oTableExportButtonService: OTableExportButtonService;
    constructor(injector: Injector);
    click(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableExportButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTableExportButtonComponent, "o-table-export-button", never, { "icon": "icon"; "svgIcon": "svg-icon"; "olabel": "label"; "exportType": "export-type"; }, { "onClick": "onClick"; }, never, never, false, never>;
}
//# sourceMappingURL=o-table-export-button.component.d.ts.map