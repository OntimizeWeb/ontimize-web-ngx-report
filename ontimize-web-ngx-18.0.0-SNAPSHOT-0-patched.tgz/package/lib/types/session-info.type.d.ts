export type SessionInfo = {
    id?: string | number;
    user?: string;
};
//# sourceMappingURL=session-info.type.d.ts.map