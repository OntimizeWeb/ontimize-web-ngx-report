export interface IBaseQueryArgument {
    parseQueryParameters(params: any): any;
}
//# sourceMappingURL=base-query-argument.interface.d.ts.map