import { IComponent } from './component.interface';
export interface IMultipleSelection extends IComponent {
    getSelectedItems(): any[];
    setSelectedItems(values: any[]): void;
}
//# sourceMappingURL=multiple-selection.interface.d.ts.map