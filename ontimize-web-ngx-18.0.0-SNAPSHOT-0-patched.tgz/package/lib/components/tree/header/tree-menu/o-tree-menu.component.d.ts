import { EventEmitter } from '@angular/core';
import { MatCheckboxChange } from '@angular/material/checkbox';
import { MatMenu } from '@angular/material/menu';
import * as i0 from "@angular/core";
export declare class OTreeMenuComponent {
    matMenu: MatMenu;
    selectAllCheckbox: boolean;
    selectAllCheckboxVisible: boolean;
    onSelectCheckboxChange: EventEmitter<boolean>;
    toggleShowCheckbox(event: MatCheckboxChange): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTreeMenuComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTreeMenuComponent, "o-tree-menu", never, { "selectAllCheckbox": { "alias": "select-all-checkbox"; "required": false; }; "selectAllCheckboxVisible": { "alias": "select-all-checkbox-visible"; "required": false; }; }, { "onSelectCheckboxChange": "onSelectCheckboxChange"; }, never, never, true, never>;
}
//# sourceMappingURL=o-tree-menu.component.d.ts.map