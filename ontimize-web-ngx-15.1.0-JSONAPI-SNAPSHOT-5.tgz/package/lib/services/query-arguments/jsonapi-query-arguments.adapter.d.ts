import { JSONAPIQueryParameter } from '../../types/json-query-parameter.type';
import { BaseQueryArgument } from './base-query-argument.adapter';
import { IBaseQueryArgument } from './base-query-argument.interface';
import { OQueryParams } from '../../types/query-params.type';
import * as i0 from "@angular/core";
export declare class JSONAPIQueryArgumentsAdapter extends BaseQueryArgument implements IBaseQueryArgument {
    parseQueryParameters(args: OQueryParams): JSONAPIQueryParameter[];
    deCompose(expresion: any, columns: Array<string>, kv: Object): Object;
    deComposeExpresion(expresion: any, columns: Array<string>, kv: Object): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<JSONAPIQueryArgumentsAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<JSONAPIQueryArgumentsAdapter>;
}
//# sourceMappingURL=jsonapi-query-arguments.adapter.d.ts.map