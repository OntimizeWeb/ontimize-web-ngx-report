import { ElementRef, Renderer2 } from '@angular/core';
import * as i0 from "@angular/core";
export type OTabMode = 'ontimize' | 'material';
export declare class OTabGroupDirective {
    protected renderer: Renderer2;
    protected el: ElementRef;
    protected static OTabModes: {
        ontimize: string;
        material: string;
    };
    protected _mode: OTabMode;
    protected _defaultMode: OTabMode;
    set mode(mode: OTabMode);
    get mode(): OTabMode;
    constructor(renderer: Renderer2, el: ElementRef);
    protected applyMode(mode?: OTabMode): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTabGroupDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OTabGroupDirective, "[oTabGroup]", never, { "mode": "oTabGroup"; }, {}, never, never, false, never>;
}
//# sourceMappingURL=o-tab-group.directive.d.ts.map