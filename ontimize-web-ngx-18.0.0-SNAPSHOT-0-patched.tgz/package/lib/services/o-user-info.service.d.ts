import { Injector } from '@angular/core';
import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export interface UserInfo {
    username?: string;
    avatar?: string;
}
export declare class OUserInfoService {
    protected injector: Injector;
    protected storedInfo: UserInfo;
    private subject;
    constructor(injector: Injector);
    setUserInfo(info: UserInfo): void;
    getUserInfo(): UserInfo;
    getUserInfoObservable(): Observable<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OUserInfoService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OUserInfoService>;
}
//# sourceMappingURL=o-user-info.service.d.ts.map