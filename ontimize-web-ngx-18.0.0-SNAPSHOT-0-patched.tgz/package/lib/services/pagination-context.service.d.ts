import { PaginationContext } from '../interfaces/pagination-context.interface';
import * as i0 from "@angular/core";
export declare class PaginationContextService {
    private context;
    constructor();
    setContext(context: PaginationContext): void;
    getContext(): PaginationContext | null;
    reinitializeContext(pageSize?: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PaginationContextService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PaginationContextService>;
}
//# sourceMappingURL=pagination-context.service.d.ts.map