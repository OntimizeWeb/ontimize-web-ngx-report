import * as i0 from "@angular/core";
import * as i1 from "./o-radio.component";
export declare class ORadioModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ORadioModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ORadioModule, never, [typeof i1.ORadioComponent], [typeof i1.ORadioComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ORadioModule>;
}
//# sourceMappingURL=o-radio.module.d.ts.map