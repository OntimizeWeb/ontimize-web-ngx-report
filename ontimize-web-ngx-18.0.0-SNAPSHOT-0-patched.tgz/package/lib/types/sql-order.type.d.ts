export type SQLOrder = {
    columnName: string;
    ascendent: boolean;
};
//# sourceMappingURL=sql-order.type.d.ts.map