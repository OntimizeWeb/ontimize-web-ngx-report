import * as i0 from "@angular/core";
import * as i1 from "./o-text-input.component";
import * as i2 from "../../../shared/shared.module";
import * as i3 from "@angular/common";
export declare class OTextInputModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OTextInputModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OTextInputModule, [typeof i1.OTextInputComponent], [typeof i2.OSharedModule, typeof i3.CommonModule], [typeof i1.OTextInputComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OTextInputModule>;
}
//# sourceMappingURL=o-text-input.module.d.ts.map