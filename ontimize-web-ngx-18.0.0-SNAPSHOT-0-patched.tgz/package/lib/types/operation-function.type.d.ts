export type OperatorFunction = (value: any[]) => number;
//# sourceMappingURL=operation-function.type.d.ts.map