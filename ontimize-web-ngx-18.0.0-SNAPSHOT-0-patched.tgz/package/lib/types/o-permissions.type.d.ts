export type OPermissions = {
    attr: string;
    visible: boolean;
    enabled: boolean;
};
//# sourceMappingURL=o-permissions.type.d.ts.map