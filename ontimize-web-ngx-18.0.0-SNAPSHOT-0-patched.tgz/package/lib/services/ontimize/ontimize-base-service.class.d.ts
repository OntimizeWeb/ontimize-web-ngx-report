import { Injector } from '@angular/core';
import { Observable } from 'rxjs';
import { IAuthService } from '../../interfaces/auth-service.interface';
import { ServiceResponse } from '../../interfaces/service-response.interface';
import { BaseDataService } from '../base-data-service.class';
import * as i0 from "@angular/core";
export declare abstract class OntimizeBaseService extends BaseDataService<ServiceResponse> implements IAuthService {
    protected injector: Injector;
    protected _startSessionPath: string;
    kv: {};
    av: string[];
    sqltypes: {};
    pagesize: number;
    offset: number;
    orderby: Array<object>;
    totalsize: number;
    constructor(injector: Injector);
    configureService(config: any): void;
    startsession(user: string, password: string): Observable<any>;
    endsession(user: string, sessionId: number): Observable<any>;
    hassession(user: string, sessionId: string | number): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OntimizeBaseService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OntimizeBaseService>;
}
//# sourceMappingURL=ontimize-base-service.class.d.ts.map