export type OInputsColor = 'primary' | 'accent';
export type OInputsOptions = {
    iconColor?: OInputsColor;
    selectAllOnClick?: boolean;
};
//# sourceMappingURL=o-inputs-options.type.d.ts.map