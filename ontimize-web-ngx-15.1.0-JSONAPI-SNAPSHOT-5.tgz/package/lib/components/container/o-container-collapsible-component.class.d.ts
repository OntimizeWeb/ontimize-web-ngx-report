import { AfterViewInit, ElementRef, EventEmitter, Injector, OnDestroy } from '@angular/core';
import { MatExpansionPanel } from '@angular/material/expansion';
import { Subscription } from 'rxjs';
import { OContainerComponent } from './o-container-component.class';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_CONTAINER_COLLAPSIBLE: string[];
export declare const DEFAULT_OUTPUTS_O_CONTAINER_COLLAPSIBLE: string[];
export declare class OContainerCollapsibleComponent extends OContainerComponent implements AfterViewInit, OnDestroy {
    protected elRef: ElementRef;
    protected injector: Injector;
    protected matFormDefaultOption: any;
    expanded: boolean;
    collapsedHeight: string;
    expandedHeight: string;
    description: string;
    onClosed: EventEmitter<void>;
    onOpened: EventEmitter<void>;
    onAfterCollapse: EventEmitter<void>;
    onAfterExpand: EventEmitter<void>;
    expPanel: MatExpansionPanel;
    protected containerContent: ElementRef;
    protected oContainerOutline: ElementRef;
    protected expPanelSubscriptions: Subscription;
    constructor(elRef: ElementRef, injector: Injector, matFormDefaultOption: any);
    ngAfterViewInit(): void;
    subscribeEventsExpPanel(): void;
    protected updateOutlineGap(): void;
    protected registerObserver(): void;
    updateInnerHeight(height: number): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OContainerCollapsibleComponent, [null, null, { optional: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OContainerCollapsibleComponent, never, never, { "expanded": "expanded"; "description": "description"; "collapsedHeight": "collapsed-height"; "expandedHeight": "expanded-height"; }, { "onClosed": "onClosed"; "onOpened": "onOpened"; "onAfterCollapse": "onAfterCollapse"; "onAfterExpand": "onAfterExpand"; }, never, never, false, never>;
}
//# sourceMappingURL=o-container-collapsible-component.class.d.ts.map