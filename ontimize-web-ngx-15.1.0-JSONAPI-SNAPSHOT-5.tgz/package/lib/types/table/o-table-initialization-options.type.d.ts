export type OTableInitializationOptions = {
    entity?: string;
    service?: string;
    columns?: string;
    visibleColumns?: string;
    defaultVisibleColumns?: string;
    keys?: string;
    sortColumns?: string;
    parentKeys?: string;
    filterColumns?: string;
};
//# sourceMappingURL=o-table-initialization-options.type.d.ts.map