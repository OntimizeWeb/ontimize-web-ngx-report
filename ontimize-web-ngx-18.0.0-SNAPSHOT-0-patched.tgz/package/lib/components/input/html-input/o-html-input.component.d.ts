import { AfterViewInit, ChangeDetectorRef, ElementRef, Injector, OnInit } from '@angular/core';
import { ValidatorFn } from '@angular/forms';
import { MatTab, MatTabGroup } from '@angular/material/tabs';
import { OFormComponent } from '../../form/o-form.component';
import { CKEditorComponent } from '../../material/ckeditor/ck-editor.component';
import { OFormDataComponent } from '../../o-form-data-component.class';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_HTML_INPUT: string[];
export declare const DEFAULT_OUTPUTS_O_HTML_INPUT: string[];
export declare class OHTMLInputComponent extends OFormDataComponent implements OnInit, AfterViewInit {
    protected _minLength: number;
    protected _maxLength: number;
    ckEditor: CKEditorComponent;
    protected tabGroupContainer: MatTabGroup;
    protected tabContainer: MatTab;
    _subscriptAnimationState: string;
    protected _changeDetectorRef: ChangeDetectorRef;
    constructor(form: OFormComponent, elRef: ElementRef, injector: Injector);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    hasError(error: string): boolean;
    isInActiveTab(): boolean;
    resolveValidators(): ValidatorFn[];
    clearValue(): void;
    destroyCKEditor(): void;
    getCKEditor(): any;
    set minLength(val: number);
    get minLength(): number;
    set maxLength(val: number);
    get maxLength(): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<OHTMLInputComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OHTMLInputComponent, "o-html-input", never, { "oattr": { "alias": "attr"; "required": false; }; "data": { "alias": "data"; "required": false; }; "autoBinding": { "alias": "automatic-binding"; "required": false; }; "autoRegistering": { "alias": "automatic-registering"; "required": false; }; "orequired": { "alias": "required"; "required": false; }; "minLength": { "alias": "min-length"; "required": false; }; "maxLength": { "alias": "max-length"; "required": false; }; "readOnly": { "alias": "read-only"; "required": false; }; "sqlType": { "alias": "sql-type"; "required": false; }; }, { "onFocus": "onFocus"; "onBlur": "onBlur"; }, never, never, true, never>;
}
//# sourceMappingURL=o-html-input.component.d.ts.map