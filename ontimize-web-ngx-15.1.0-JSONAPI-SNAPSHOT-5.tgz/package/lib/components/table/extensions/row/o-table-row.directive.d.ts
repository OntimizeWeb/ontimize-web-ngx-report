import { AfterViewInit, ElementRef, OnDestroy, Renderer2 } from '@angular/core';
import { Subscription } from 'rxjs';
import { OTableBase } from '../../o-table-base.class';
import * as i0 from "@angular/core";
export declare class OTableRowDirective implements AfterViewInit, OnDestroy {
    table: OTableBase;
    protected elementRef: ElementRef;
    protected renderer: Renderer2;
    protected resizeSubscription: Subscription;
    constructor(table: OTableBase, elementRef: ElementRef, renderer: Renderer2);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    registerResize(): void;
    calculateRowWidth(): void;
    setRowWidth(value: number): void;
    get alreadyScrolled(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableRowDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OTableRowDirective, "[oTableRow]", never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=o-table-row.directive.d.ts.map