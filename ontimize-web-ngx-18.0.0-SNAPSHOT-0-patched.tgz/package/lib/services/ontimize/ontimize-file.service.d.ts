import { HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { IFileService } from '../../interfaces/file-service.interface';
import { BaseService } from '../base-service.class';
import { ServiceResponse } from '../../interfaces/service-response.interface';
import * as i0 from "@angular/core";
export declare class OntimizeFileService extends BaseService<ServiceResponse> implements IFileService {
    path: string;
    configureService(config: any): void;
    upload(files: any[], entity: string, data?: object): Observable<any>;
    protected buildHeaders(): HttpHeaders;
    static ɵfac: i0.ɵɵFactoryDeclaration<OntimizeFileService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OntimizeFileService>;
}
//# sourceMappingURL=ontimize-file.service.d.ts.map