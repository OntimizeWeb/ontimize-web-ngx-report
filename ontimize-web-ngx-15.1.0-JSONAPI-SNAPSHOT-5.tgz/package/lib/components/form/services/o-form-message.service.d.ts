import * as i0 from "@angular/core";
export declare class OFormMessageService {
    getQueryErrorMessage(): string;
    getUpdateSuccessMessage(): string;
    getUpdateErrorMessage(): string;
    getDeleteSuccessMessage(): string;
    getDeleteErrorMessage(): string;
    getDeleteConfirmationMessage(): string;
    getDeleteConfirmationDialogTitle(): string;
    getInsertSuccessMessage(): string;
    getInsertErrorMessage(): string;
    getValidationError(): string;
    getValidationErrorDialogTitle(): string;
    getNothingToUpdateMessage(): string;
    getActionPermissionNotEnabledMessage(): string;
    getDiscardChangesConfirmationMessage(): string;
    getDiscardChangesConfirmationDialogTitle(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<OFormMessageService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OFormMessageService>;
}
//# sourceMappingURL=o-form-message.service.d.ts.map