import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injector } from '@angular/core';
import { AppConfig } from '../../config/app-config';
import { Config } from '../../types/config.type';
import { AuthService } from '../auth.service';
export declare class OntimizeBasePermissionsService {
    protected injector: Injector;
    protected httpClient: HttpClient;
    protected _appConfig: Config;
    protected _config: AppConfig;
    protected authService: AuthService;
    constructor(injector: Injector);
    protected buildHeaders(): HttpHeaders;
}
//# sourceMappingURL=ontimize-base-permissions-service.class.d.ts.map