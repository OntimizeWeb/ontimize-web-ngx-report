import { OnDestroy } from "@angular/core";
import { OTableGlobalConfig } from "../../types/table/o-table-global-config.type";
import * as i0 from "@angular/core";
export declare class OTableLoadingService implements OnDestroy {
    private readonly config;
    private readonly loading$;
    private readonly THRESHOLD;
    private readonly MIN_VISIBLE;
    private visibleSince;
    private readonly showSkeleton$;
    private readonly processingBlocked$;
    private readonly destroy$;
    private readonly isInitialLoad$;
    constructor(config: OTableGlobalConfig);
    private readonly isLoading$;
    private readonly handleProcessingBlock$;
    readonly isProcessing$: import("rxjs").Observable<boolean>;
    private readonly handleShow$;
    private readonly handleHide$;
    readonly showLoading$: import("rxjs").Observable<boolean>;
    setLoading(value: boolean): void;
    isBlocked(): boolean;
    setProcessingBlock(value: boolean): void;
    handleProtected(event?: MouseEvent): boolean;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableLoadingService, [{ optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OTableLoadingService>;
}
//# sourceMappingURL=o-table-loading.service.d.ts.map