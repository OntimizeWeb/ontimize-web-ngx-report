import * as i0 from "@angular/core";
import * as i1 from "./o-breadcrumb.component";
import * as i2 from "@angular/common";
import * as i3 from "../../shared/shared.module";
import * as i4 from "@angular/router";
export declare class OBreadcrumbModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OBreadcrumbModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OBreadcrumbModule, [typeof i1.OBreadcrumbComponent], [typeof i2.CommonModule, typeof i3.OSharedModule, typeof i4.RouterModule], [typeof i1.OBreadcrumbComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OBreadcrumbModule>;
}
//# sourceMappingURL=o-breadcrumb.module.d.ts.map