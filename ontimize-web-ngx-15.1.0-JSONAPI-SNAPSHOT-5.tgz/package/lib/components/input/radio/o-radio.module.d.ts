import * as i0 from "@angular/core";
import * as i1 from "./o-radio.component";
import * as i2 from "@angular/common";
import * as i3 from "../../../shared/shared.module";
import * as i4 from "../../contextmenu/o-context-menu.module";
export declare class ORadioModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ORadioModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ORadioModule, [typeof i1.ORadioComponent], [typeof i2.CommonModule, typeof i3.OSharedModule, typeof i4.OContextMenuModule], [typeof i1.ORadioComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ORadioModule>;
}
//# sourceMappingURL=o-radio.module.d.ts.map