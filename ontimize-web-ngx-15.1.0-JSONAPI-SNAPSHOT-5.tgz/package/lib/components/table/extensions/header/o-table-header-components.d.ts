import { OTableButtonComponent } from './table-button/o-table-button.component';
import { OTableButtonsComponent } from './table-buttons/o-table-buttons.component';
import { OTableColumnResizerComponent } from './table-column-resizer/o-table-column-resizer.component';
import { OTableColumnsGroupingColumnComponent } from './table-columns-grouping/columns/o-table-columns-grouping-column.component';
import { OTableColumnsGroupingComponent } from './table-columns-grouping/o-table-columns-grouping.component';
import { OTableColumnsFilterColumnComponent } from './table-columns-filter/columns/o-table-columns-filter-column.component';
import { OTableColumnsFilterComponent } from './table-columns-filter/o-table-columns-filter.component';
import { OTableHeaderColumnFilterIconComponent } from './table-header-column-filter-icon/o-table-header-column-filter-icon.component';
import { OTableInsertableRowComponent } from './table-insertable-row/o-table-insertable-row.component';
import { OTableMenuComponent } from './table-menu/o-table-menu.component';
import { OTableOptionComponent } from './table-option/o-table-option.component';
import { OTableQuickfilterComponent } from './table-quickfilter/o-table-quickfilter.component';
import { OTableHeaderComponent } from './table-header/o-table-header.component';
import { OTableColumnSelectAllDirective } from './table-column-select-all/o-table-column-select-all.directive';
export declare const O_TABLE_HEADER_COMPONENTS: (typeof OTableColumnsFilterColumnComponent | typeof OTableColumnsGroupingColumnComponent | typeof OTableButtonComponent | typeof OTableColumnSelectAllDirective | typeof OTableColumnsFilterComponent | typeof OTableHeaderColumnFilterIconComponent | typeof OTableHeaderComponent | typeof OTableInsertableRowComponent | typeof OTableOptionComponent | typeof OTableButtonsComponent | typeof OTableColumnResizerComponent | typeof OTableColumnsGroupingComponent | typeof OTableMenuComponent | typeof OTableQuickfilterComponent)[];
export declare const O_TABLE_HEADER_COMPONENTS_EXPORTED: (typeof OTableColumnsFilterColumnComponent | typeof OTableColumnsGroupingColumnComponent | typeof OTableButtonComponent | typeof OTableColumnSelectAllDirective | typeof OTableColumnsFilterComponent | typeof OTableHeaderComponent | typeof OTableInsertableRowComponent | typeof OTableOptionComponent | typeof OTableButtonsComponent | typeof OTableColumnResizerComponent | typeof OTableColumnsGroupingComponent | typeof OTableMenuComponent | typeof OTableQuickfilterComponent)[];
//# sourceMappingURL=o-table-header-components.d.ts.map