import { Injector } from '@angular/core';
import { IExportDataProvider } from '../interfaces/export-data-provider.interface';
import { IExportService } from '../interfaces/export-service.interface';
import { IFileService } from '../interfaces/file-service.interface';
import { ILocalStorageService } from '../interfaces/local-service.interface';
import { INameConvention } from '../interfaces/name-convention.interface';
import { IPermissionsService } from '../interfaces/permissions-service.interface';
import { IPreferencesService } from '../interfaces/prefereces-service.interface';
import { IServiceResponseAdapter } from '../interfaces/service-response-adapter.interface';
import { AuthService } from './auth.service';
import { BaseServiceResponse } from './base-service-response.class';
import { LocalStorageService } from './local-storage.service';
import { NameConvention } from './name-convention/name-convention.service';
import { OntimizeExportDataProviderService } from './ontimize-export-data-provider.service';
import { OntimizeExportService } from './ontimize/ontimize-export.service';
import { OntimizeServiceResponseAdapter } from './ontimize/ontimize-service-response.adapter';
import { OntimizeService } from './ontimize/ontimize.service';
import { IBaseRequestArgument } from './request-adapter/base-request-argument.interface';
import { OntimizeRequestArgumentsAdapter } from './request-adapter/ontimize-request-arguments.adapter';
import { AbstractComponentStateService } from './state/o-component-state.service';
export declare function dataServiceFactory(injector: Injector): any;
export declare function createServiceInstance(serviceClass: any, injector: Injector): any;
export declare function fileServiceFactory(injector: Injector): IFileService;
export declare function localStorageServiceFactory(injector: Injector): ILocalStorageService;
export declare function exportServiceFactory(injector: Injector): IExportService;
export declare function exportDataFactory(injector: Injector): IExportDataProvider;
export declare function serviceRequestAdapterFactory(injector: Injector): IBaseRequestArgument;
export declare function serviceResponseAdapterFactory(injector: Injector): IServiceResponseAdapter<BaseServiceResponse>;
export declare function permissionsServiceFactory(injector: Injector): IPermissionsService;
export declare function preferencesServiceFactory(injector: Injector): IPreferencesService;
export declare function authServiceFactory(injector: Injector): AuthService;
export declare function componentStateFactory(injector: Injector): AbstractComponentStateService<any, any>;
export declare const OntimizeServiceProvider: {
    provide: typeof OntimizeService;
    useFactory: typeof dataServiceFactory;
    deps: (typeof Injector)[];
};
export declare const OntimizeExportServiceProvider: {
    provide: typeof OntimizeExportService;
    useFactory: typeof exportServiceFactory;
    deps: (typeof Injector)[];
};
export declare const OntimizeAuthServiceProvider: {
    provide: typeof AuthService;
    useFactory: typeof authServiceFactory;
    deps: (typeof Injector)[];
};
export declare const ComponentStateServiceProvider: {
    provide: typeof AbstractComponentStateService;
    useFactory: typeof componentStateFactory;
    deps: (typeof Injector)[];
};
export declare const ExportDataServiceProvider: {
    provide: typeof OntimizeExportDataProviderService;
    useFactory: typeof exportDataFactory;
    deps: (typeof Injector)[];
};
export declare const ServiceRequestAdapter: {
    provide: typeof OntimizeRequestArgumentsAdapter;
    useFactory: typeof serviceRequestAdapterFactory;
    deps: (typeof Injector)[];
};
export declare const ServiceResponseAdapter: {
    provide: typeof OntimizeServiceResponseAdapter;
    useFactory: typeof serviceResponseAdapterFactory;
    deps: (typeof Injector)[];
};
export declare const NameConventionProvider: {
    provide: typeof NameConvention;
    useFactory: typeof nameConventionServiceFactory;
    deps: (typeof Injector)[];
};
export declare const OntimizeLocalStorageServiceProvider: {
    provide: typeof LocalStorageService;
    useFactory: typeof localStorageServiceFactory;
    deps: (typeof Injector)[];
};
export declare function nameConventionServiceFactory(injector: Injector): INameConvention;
//# sourceMappingURL=factories.d.ts.map