import { AfterViewInit, ChangeDetectorRef, Injector, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { PermissionsService } from '../../services';
import { AppMenuService } from '../../services/app-menu.service';
import { OTranslateService } from '../../services/translate/o-translate.service';
import { OPermissions } from '../../types';
import { MenuRootItem } from '../../types/menu-root-item.type';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_MENU_LAYOUT: string[];
export declare const DEFAULT_OUTPUTS_O_MENU_LAYOUT: any[];
export declare class OCardMenuLayoutComponent implements AfterViewInit, OnDestroy {
    private injector;
    private cd;
    protected translateService: OTranslateService;
    protected translateServiceSubscription: Subscription;
    protected appMenuService: AppMenuService;
    protected menuRoots: MenuRootItem[];
    protected cardItemsArray: MenuRootItem[];
    protected parentMenuId: string;
    protected excludeMenusId: string;
    protected permissions: OPermissions;
    protected permissionsService: PermissionsService;
    protected parentMenuIds: string[];
    protected excludeIds: string[];
    hidden: boolean;
    constructor(injector: Injector, cd: ChangeDetectorRef);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    setCardMenuItems(): void;
    get cardItems(): MenuRootItem[];
    set cardItems(val: MenuRootItem[]);
    protected getItemsFilteredByParentId(array: MenuRootItem[], parentMenuIds: string[]): MenuRootItem[];
    static ɵfac: i0.ɵɵFactoryDeclaration<OCardMenuLayoutComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OCardMenuLayoutComponent, "o-card-menu-layout", never, { "parentMenuId": "parent-menu-id"; "excludeMenusId": "exclude-menus-id"; }, {}, never, ["o-card-menu-item"], false, never>;
}
//# sourceMappingURL=o-card-menu-layout.component.d.ts.map