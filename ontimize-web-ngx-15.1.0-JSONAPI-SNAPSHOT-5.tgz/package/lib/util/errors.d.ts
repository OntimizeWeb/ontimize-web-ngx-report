import { Injector, QueryList } from '@angular/core';
import { OMatErrorOptions } from '../types/o-mat-error.type';
import { AsyncValidatorFn, FormControl, ValidatorFn } from '@angular/forms';
import { ErrorData } from '../types/error-data.type';
import { OValidatorComponent } from '../shared/components/validation/o-validator.component';
import { OMatErrorDirective } from '../directives/o-mat-error.directive';
export interface ComponentWithValidatorsAndErrorsData {
    errorOptions: OMatErrorOptions;
    errorsData: ErrorData[];
    validatorChildren: QueryList<OValidatorComponent>;
    oMatErrorChildren: QueryList<OMatErrorDirective>;
    tooltipPosition: string;
    getFormControl(): FormControl;
    resolveValidators: () => ValidatorFn[];
    resolveAsyncValidators: () => AsyncValidatorFn[];
    hasError: (error: string) => boolean;
}
export declare class ErrorsUtils {
    static getErrorOptions(injector: Injector): OMatErrorOptions;
    static getErrorsTooltipText(comp: ComponentWithValidatorsAndErrorsData): string;
    static getTooltipClasses(comp: ComponentWithValidatorsAndErrorsData): string;
    static updateFormControlValidators(comp: ComponentWithValidatorsAndErrorsData): void;
    static getActiveOErrors(comp: ComponentWithValidatorsAndErrorsData): ErrorData[];
    static pushToErrorsData(comp: ComponentWithValidatorsAndErrorsData, newErrorsData?: ErrorData[]): void;
}
//# sourceMappingURL=errors.d.ts.map