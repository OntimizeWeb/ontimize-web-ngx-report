import { ElementRef, Injector, OnInit } from '@angular/core';
import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';
import { IRealPipeArgument, ORealPipe } from '../../../pipes/o-real.pipe';
import { NumberService } from '../../../services/number.service';
import { OFormComponent } from '../../form/o-form.component';
import { OIntegerInputComponent } from '../integer-input/o-integer-input.component';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_REAL_INPUT: string[];
export declare class ORealInputComponent extends OIntegerInputComponent implements OnInit {
    minDecimalDigits: number;
    maxDecimalDigits: number;
    step: number;
    grouping: boolean;
    strict: boolean;
    protected decimalSeparator: string;
    protected componentPipe: ORealPipe;
    protected pipeArguments: IRealPipeArgument;
    protected numberService: NumberService;
    constructor(form: OFormComponent, elRef: ElementRef, injector: Injector);
    setComponentPipe(): void;
    initialize(): void;
    ngOnInit(): void;
    resolveValidators(): ValidatorFn[];
    ensureOFormValue(arg: any): void;
    protected maxDecimalDigitsValidator(control: AbstractControl): ValidationErrors;
    protected initializeStep(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ORealInputComponent, [{ optional: true; }, null, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ORealInputComponent, "o-real-input", never, { "minDecimalDigits": { "alias": "min-decimal-digits"; "required": false; }; "maxDecimalDigits": { "alias": "max-decimal-digits"; "required": false; }; "decimalSeparator": { "alias": "decimal-separator"; "required": false; }; "strict": { "alias": "strict"; "required": false; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=o-real-input.component.d.ts.map