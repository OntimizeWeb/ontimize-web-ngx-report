import { ElementRef, Injector, TemplateRef, ViewContainerRef } from '@angular/core';
import * as i0 from "@angular/core";
export declare class OMatErrorDirective {
    private element;
    private templateRef;
    private viewContainer;
    private injector;
    text: string;
    private errorOptions;
    constructor(element: ElementRef, templateRef: TemplateRef<any>, viewContainer: ViewContainerRef, injector: Injector);
    set oMatError(val: any);
    static ɵfac: i0.ɵɵFactoryDeclaration<OMatErrorDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OMatErrorDirective, "[oMatError]", never, { "oMatError": { "alias": "oMatError"; "required": false; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=o-mat-error.directive.d.ts.map