import { Injector } from '@angular/core';
import { Router } from '@angular/router';
import { DialogService } from '../../../services';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_USER_INFO_MENU_ITEM: string[];
export declare class OUserInfoConfigurationItemDirective {
    injector: Injector;
    toolTip: boolean;
    confirm: boolean;
    action: () => void;
    route: string;
    confirmText: any;
    protected router: Router;
    protected dialogService: DialogService;
    constructor(injector: Injector);
    triggerOnClick(e: Event): void;
    navigate(): void;
    executeItemAction(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OUserInfoConfigurationItemDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OUserInfoConfigurationItemDirective, "o-user-info-configuration-item", never, { "name": { "alias": "name"; "required": false; }; "route": { "alias": "route"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "action": { "alias": "action"; "required": false; }; "confirm": { "alias": "confirm"; "required": false; }; "confirmText": { "alias": "confirm-text"; "required": false; }; "tooltip": { "alias": "tooltip"; "required": false; }; "class": { "alias": "class"; "required": false; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=o-user-info-configuration-item.directive.d.ts.map