import * as i0 from "@angular/core";
import * as i1 from "./o-user-info.component";
import * as i2 from "./user-info-configuration/o-user-info-configuration.directive";
import * as i3 from "./user-info-configuration-item/o-user-info-configuration-item.directive";
export declare class OUserInfoModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OUserInfoModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OUserInfoModule, never, [typeof i1.OUserInfoComponent, typeof i2.OUserInfoConfigurationDirective, typeof i3.OUserInfoConfigurationItemDirective], [typeof i1.OUserInfoComponent, typeof i2.OUserInfoConfigurationDirective, typeof i3.OUserInfoConfigurationItemDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OUserInfoModule>;
}
//# sourceMappingURL=o-user-info.module.d.ts.map