import { Injector, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { AggregateFunction } from '../../../../../types/aggregate-function.type';
import { OTableComponent } from '../../../o-table.component';
import * as i0 from "@angular/core";
export declare const DEFAULT_TABLE_COLUMN_AGGREGATE: string[];
export declare class OTableColumnAggregateComponent implements OnDestroy, OnInit {
    protected injector: Injector;
    static DEFAULT_AGGREGATE: string;
    attr: string;
    aggregate: string;
    table: OTableComponent;
    title: string;
    protected _aggregateFunction: AggregateFunction;
    protected subscription: Subscription;
    constructor(table: OTableComponent, injector: Injector);
    get functionAggregate(): AggregateFunction;
    set functionAggregate(val: AggregateFunction);
    getColumnData(attr: any): any[];
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableColumnAggregateComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTableColumnAggregateComponent, "o-table-column-aggregate", never, { "attr": { "alias": "attr"; "required": false; }; "title": { "alias": "title"; "required": false; }; "aggregate": { "alias": "aggregate"; "required": false; }; "functionAggregate": { "alias": "aggregate-function"; "required": false; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=o-table-column-aggregate.component.d.ts.map