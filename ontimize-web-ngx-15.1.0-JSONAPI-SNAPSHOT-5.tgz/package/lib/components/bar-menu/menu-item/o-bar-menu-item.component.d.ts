import { ElementRef, Injector, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { OBaseMenuItemClass } from '../o-base-menu-item.class';
import { OBarMenuBase } from '../o-bar-menu-base.class';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_BAR_MENU_ITEM: string[];
export declare class OBarMenuItemComponent extends OBaseMenuItemClass implements OnInit {
    protected menu: OBarMenuBase;
    protected elRef: ElementRef;
    protected injector: Injector;
    protected router: Router;
    route: string;
    action: () => void;
    constructor(menu: OBarMenuBase, elRef: ElementRef, injector: Injector);
    ngOnInit(): void;
    collapseMenu(evt: Event): void;
    onClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OBarMenuItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OBarMenuItemComponent, "o-bar-menu-item", never, { "route": "route"; "action": "action"; }, {}, never, never, false, never>;
}
//# sourceMappingURL=o-bar-menu-item.component.d.ts.map