import * as i0 from "@angular/core";
import * as i1 from "./o-slide-toggle.component";
import * as i2 from "@angular/common";
import * as i3 from "../../../shared/shared.module";
export declare class OSlideToggleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OSlideToggleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OSlideToggleModule, [typeof i1.OSlideToggleComponent], [typeof i2.CommonModule, typeof i3.OSharedModule], [typeof i1.OSlideToggleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OSlideToggleModule>;
}
//# sourceMappingURL=o-slide-toggle.module.d.ts.map