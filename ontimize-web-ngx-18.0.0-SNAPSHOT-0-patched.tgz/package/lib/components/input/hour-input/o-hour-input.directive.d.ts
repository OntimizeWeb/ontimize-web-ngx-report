import { NgxMaterialTimepickerComponent, TimepickerDirective } from 'ngx-material-timepicker';
import * as i0 from "@angular/core";
export declare class OHourTimepickerDirective extends TimepickerDirective {
    set timepicker(picker: NgxMaterialTimepickerComponent);
    updateValue(value: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OHourTimepickerDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OHourTimepickerDirective, "[oNgxTimepicker]", never, { "timepicker": { "alias": "oNgxTimepicker"; "required": false; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=o-hour-input.directive.d.ts.map