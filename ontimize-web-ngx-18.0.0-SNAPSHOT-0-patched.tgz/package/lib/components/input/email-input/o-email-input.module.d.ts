import * as i0 from "@angular/core";
import * as i1 from "./o-email-input.component";
export declare class OEmailInputModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OEmailInputModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OEmailInputModule, never, [typeof i1.OEmailInputComponent], [typeof i1.OEmailInputComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OEmailInputModule>;
}
//# sourceMappingURL=o-email-input.module.d.ts.map