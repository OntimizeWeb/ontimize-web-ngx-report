import { OQueryDataArgs } from "./query-data-args.type";
export type JSONAPIContext = {
    ovrrArgs: OQueryDataArgs;
};
//# sourceMappingURL=jsonapi-context.type.d.ts.map