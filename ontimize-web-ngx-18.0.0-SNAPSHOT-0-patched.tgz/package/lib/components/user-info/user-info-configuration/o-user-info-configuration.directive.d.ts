import { OUserInfoConfigurationItemDirective } from '../user-info-configuration-item/o-user-info-configuration-item.directive';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_USER_INFO_MENU: string[];
export declare const DEFAULT_OUTPUTS_O_USER_INFO_MENU: any[];
export declare class OUserInfoConfigurationDirective {
    userInfoConfigurationItems: Array<OUserInfoConfigurationItemDirective>;
    showProfile: boolean;
    showSettings: boolean;
    showLogout: boolean;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<OUserInfoConfigurationDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OUserInfoConfigurationDirective, "o-user-info-configuration", never, { "showProfile": { "alias": "show-profile"; "required": false; }; "showSettings": { "alias": "show-settings"; "required": false; }; "showLogout": { "alias": "show-logout"; "required": false; }; }, {}, ["userInfoConfigurationItems"], never, true, never>;
}
//# sourceMappingURL=o-user-info-configuration.directive.d.ts.map