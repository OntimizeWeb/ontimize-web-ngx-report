import * as i0 from "@angular/core";
import * as i1 from "./o-phone-input.component";
export declare class OPhoneInputModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OPhoneInputModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OPhoneInputModule, never, [typeof i1.OPhoneInputComponent], [typeof i1.OPhoneInputComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OPhoneInputModule>;
}
//# sourceMappingURL=o-phone-input.module.d.ts.map