import { ElementRef, Renderer2 } from '@angular/core';
import * as i0 from "@angular/core";
export declare class OHiddenDirective {
    constructor(el: ElementRef, renderer: Renderer2);
    static ɵfac: i0.ɵɵFactoryDeclaration<OHiddenDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OHiddenDirective, "[oHidden]", never, {}, {}, never, never, true, never>;
}
//# sourceMappingURL=o-hidden.directive.d.ts.map