import { ElementRef, EventEmitter, OnDestroy, OnInit, Renderer2 } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import { IList } from '../../../interfaces/o-list.interface';
import { ListItem } from './o-list-item';
import * as i0 from "@angular/core";
export declare class OListItemDirective implements OnInit, OnDestroy {
    listItem: ListItem;
    _el: ElementRef;
    private renderer;
    actRoute: ActivatedRoute;
    onClick: EventEmitter<any>;
    onDoubleClick: EventEmitter<any>;
    modelData: any;
    selectable: boolean;
    protected _list: IList;
    protected subscription: Subscription;
    constructor(listItem: ListItem, _el: ElementRef, renderer: Renderer2, actRoute: ActivatedRoute);
    ngOnInit(): void;
    ngOnDestroy(): void;
    onMouseEnter(): void;
    updateActiveState(params: any): void;
    onItemClicked(e?: Event): void;
    onItemDoubleClicked(e?: Event): void;
    isSelected(): boolean;
    setListComponent(list: IList): void;
    setItemData(data: any): void;
    getItemData(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<OListItemDirective, [{ optional: true; host: true; self: true; }, null, null, null]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OListItemDirective, "o-list-item, mat-list-item[o-list-item], mat-card[o-list-item]", ["olistitem"], { "modelData": { "alias": "o-list-item"; "required": false; }; "selectable": { "alias": "selectable"; "required": false; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=o-list-item.directive.d.ts.map