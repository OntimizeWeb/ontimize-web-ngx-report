import { Injector, OnInit, TemplateRef } from '@angular/core';
import { IRealPipeArgument, ORealPipe } from '../../../../../pipes/o-real.pipe';
import { OListPickerRendererIntegerComponent } from '../integer/o-list-picker-renderer-integer.component';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_LISTPICKER_RENDERER_REAL: any[];
export declare class OListPickerRendererRealComponent extends OListPickerRendererIntegerComponent implements OnInit {
    protected injector: Injector;
    minDecimalDigits: number;
    maxDecimalDigits: number;
    protected decimalSeparator: string;
    protected componentPipe: ORealPipe;
    protected pipeArguments: IRealPipeArgument;
    templateref: TemplateRef<any>;
    constructor(injector: Injector);
    setComponentPipe(): void;
    initialize(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OListPickerRendererRealComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OListPickerRendererRealComponent, "o-list-picker-renderer-real", never, { "grouping": { "alias": "grouping"; "required": false; }; "thousandSeparator": { "alias": "thousand-separator"; "required": false; }; "decimalSeparator": { "alias": "decimal-separator"; "required": false; }; "minDecimalDigits": { "alias": "min-decimal-digits"; "required": false; }; "maxDecimalDigits": { "alias": "max-decimal-digits"; "required": false; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=o-list-picker-renderer-real.component.d.ts.map