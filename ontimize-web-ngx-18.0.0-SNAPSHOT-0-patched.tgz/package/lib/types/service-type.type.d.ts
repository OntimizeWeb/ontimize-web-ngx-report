export declare enum ServiceType {
    Ontimize = "Ontimize",
    OntimizeEE = "OntimizeEE",
    JSONAPI = "JSONAPI"
}
//# sourceMappingURL=service-type.type.d.ts.map