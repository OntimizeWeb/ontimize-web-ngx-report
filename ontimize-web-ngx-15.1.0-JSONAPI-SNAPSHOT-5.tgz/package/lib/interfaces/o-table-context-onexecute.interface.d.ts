export interface OnExecuteTableContextEvent {
    event: Event;
    data: any;
}
//# sourceMappingURL=o-table-context-onexecute.interface.d.ts.map