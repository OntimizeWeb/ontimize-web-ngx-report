import * as i0 from "@angular/core";
import * as i1 from "./o-search-input.component";
export declare class OSearchInputModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OSearchInputModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OSearchInputModule, never, [typeof i1.OSearchInputComponent], [typeof i1.OSearchInputComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OSearchInputModule>;
}
//# sourceMappingURL=o-search-input.module.d.ts.map