import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
import * as i2 from "../pipes/o-translate.pipe";
import * as i3 from "./material/custom.material.module";
import * as i4 from "@angular/forms";
import * as i5 from "../pipes/columns-filter.pipe";
import * as i6 from "../pipes/order-by.pipe";
import * as i7 from "../pipes/is-empty-value.pipe";
import * as i8 from "../pipes/o-integer.pipe";
import * as i9 from "../pipes/o-real.pipe";
import * as i10 from "../pipes/o-moment.pipe";
import * as i11 from "../pipes/o-currency.pipe";
import * as i12 from "../pipes/o-percentage.pipe";
import * as i13 from "../pipes/o-icon.pipe";
import * as i14 from "../pipes/o-safe.pipe";
import * as i15 from "../directives/o-hidden.directive";
import * as i16 from "../directives/o-mat-prefix.directive";
import * as i17 from "../directives/o-mat-suffix.directive";
import * as i18 from "../directives/keyboard-listener.directive";
import * as i19 from "../components/list/list-item/o-list-item.directive";
import * as i20 from "../directives/o-tab-group.directive";
import * as i21 from "../directives/locker.directive";
import * as i22 from "../directives/o-mat-error.directive";
import * as i23 from "../directives/o-file-drag-and-drop.directive";
import * as i24 from "../directives/input-regulate.directive";
import * as i25 from "./components/snackbar/o-snackbar.component";
import * as i26 from "./components/error403/o-error-403.component";
import * as i27 from "./components/dialog/o-dialog.component";
import * as i28 from "./components/dialog/o-dialog-internal.component";
import * as i29 from "./components/validation/o-error.component";
import * as i30 from "./components/validation/o-validator.component";
import * as i31 from "./components/filter/load-filter/o-load-filter-dialog.component";
import * as i32 from "./components/filter/store-filter/o-store-filter-dialog.component";
export declare class OSharedModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OSharedModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OSharedModule, never, [typeof i1.CommonModule, typeof i2.OTranslateModule, typeof i3.OCustomMaterialModule, typeof i4.FormsModule, typeof i4.ReactiveFormsModule, typeof i5.ColumnsFilterPipe, typeof i6.OrderByPipe, typeof i7.IsEmptyValuePipe, typeof i8.OIntegerPipe, typeof i9.ORealPipe, typeof i10.OMomentPipe, typeof i11.OCurrencyPipe, typeof i12.OPercentPipe, typeof i13.OIconPipe, typeof i14.OSafePipe, typeof i15.OHiddenDirective, typeof i16.OMatPrefix, typeof i17.OMatSuffix, typeof i18.OKeyboardListenerDirective, typeof i19.OListItemDirective, typeof i20.OTabGroupDirective, typeof i21.OLockerDirective, typeof i22.OMatErrorDirective, typeof i23.OFileDragAndDropDirective, typeof i24.InputRegulateDirective, typeof i25.OSnackBarComponent, typeof i26.Error403Component, typeof i27.ODialogComponent, typeof i28.ODialogInternalComponent, typeof i29.OErrorComponent, typeof i30.OValidatorComponent, typeof i31.OLoadFilterDialogComponent, typeof i32.OStoreFilterDialogComponent], [typeof i4.FormsModule, typeof i4.ReactiveFormsModule, typeof i2.OTranslateModule, typeof i5.ColumnsFilterPipe, typeof i6.OrderByPipe, typeof i8.OIntegerPipe, typeof i9.ORealPipe, typeof i10.OMomentPipe, typeof i11.OCurrencyPipe, typeof i12.OPercentPipe, typeof i13.OIconPipe, typeof i14.OSafePipe, typeof i7.IsEmptyValuePipe, typeof i15.OHiddenDirective, typeof i16.OMatPrefix, typeof i17.OMatSuffix, typeof i18.OKeyboardListenerDirective, typeof i19.OListItemDirective, typeof i20.OTabGroupDirective, typeof i21.OLockerDirective, typeof i22.OMatErrorDirective, typeof i23.OFileDragAndDropDirective, typeof i24.InputRegulateDirective, typeof i3.OCustomMaterialModule, typeof i26.Error403Component, typeof i29.OErrorComponent, typeof i30.OValidatorComponent, typeof i25.OSnackBarComponent, typeof i31.OLoadFilterDialogComponent, typeof i32.OStoreFilterDialogComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OSharedModule>;
}
//# sourceMappingURL=shared.module.d.ts.map