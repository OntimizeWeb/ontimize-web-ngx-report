import { OServiceBasePermissions } from './o-service-base-permissions.type';
export type OFormPermissions = OServiceBasePermissions;
//# sourceMappingURL=o-form-permissions.type.d.ts.map