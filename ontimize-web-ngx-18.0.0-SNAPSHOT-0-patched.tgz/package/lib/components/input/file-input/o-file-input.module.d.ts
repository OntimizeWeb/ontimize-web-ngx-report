import * as i0 from "@angular/core";
import * as i1 from "./o-file-input.component";
export declare class OFileInputModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OFileInputModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OFileInputModule, never, [typeof i1.OFileInputComponent], [typeof i1.OFileInputComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OFileInputModule>;
}
//# sourceMappingURL=o-file-input.module.d.ts.map