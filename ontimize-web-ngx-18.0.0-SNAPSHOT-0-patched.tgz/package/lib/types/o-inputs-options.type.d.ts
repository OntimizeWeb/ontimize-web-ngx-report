export type OInputsColor = 'primary' | 'accent';
export type OInputsOptions = {
    iconColor?: OInputsColor;
    selectAllOnClick?: boolean;
    stringCase?: 'uppercase' | 'lowercase' | 'default';
};
//# sourceMappingURL=o-inputs-options.type.d.ts.map