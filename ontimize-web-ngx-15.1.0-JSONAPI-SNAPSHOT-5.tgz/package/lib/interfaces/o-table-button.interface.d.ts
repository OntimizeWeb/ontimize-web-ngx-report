export interface OTableButton {
    innerOnClick: (event: any) => void;
    isIconPositionLeft: () => boolean;
}
//# sourceMappingURL=o-table-button.interface.d.ts.map