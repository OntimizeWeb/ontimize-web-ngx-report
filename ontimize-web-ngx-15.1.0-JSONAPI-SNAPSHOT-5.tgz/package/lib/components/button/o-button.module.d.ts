import * as i0 from "@angular/core";
import * as i1 from "./o-button.component";
import * as i2 from "@angular/common";
import * as i3 from "../../shared/shared.module";
export declare class OButtonModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OButtonModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OButtonModule, [typeof i1.OButtonComponent], [typeof i2.CommonModule, typeof i3.OSharedModule], [typeof i1.OButtonComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OButtonModule>;
}
//# sourceMappingURL=o-button.module.d.ts.map