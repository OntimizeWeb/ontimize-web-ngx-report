export * from './o-translate-http-loader';
export * from './o-translate.parser';
export * from './o-translate.service';
//# sourceMappingURL=index.d.ts.map