import { EnvironmentProviders } from '@angular/core';
import { Config } from '../types/config.type';
export interface ProvideOntimizeWebOptions {
    noAnimations?: boolean;
}
export declare function provideOntimizeWeb(config: Config, options?: ProvideOntimizeWebOptions): EnvironmentProviders;
//# sourceMappingURL=o-provide.d.ts.map