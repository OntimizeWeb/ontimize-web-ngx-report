export interface IComponent {
    getAttribute(): string;
}
//# sourceMappingURL=component.interface.d.ts.map