import { EventEmitter } from '@angular/core';
import { IFormControlComponent } from '../../../interfaces/form-control-component.interface';
import { IFormDataComponent } from '../../../interfaces/form-data-component.interface';
import { OFormBase } from '../o-form-base.class';
export declare class OFormCacheClass {
    protected form: OFormBase;
    protected initialDataCache: object;
    protected formDataCache: object;
    protected valueChangesStack: Array<any>;
    protected _componentsSubscritpions: any;
    protected blockCaching: boolean;
    protected initializedCache: boolean;
    onCacheStateChanges: EventEmitter<any>;
    protected changedFormControls: string[];
    constructor(form: OFormBase);
    protected updateFormDataCache(): void;
    protected addChangeToStack(comp: IFormControlComponent): void;
    protected registerComponentCaching(comp: IFormDataComponent): void;
    getCachedValue(attr: string): any;
    destroy(): void;
    protected removeUndefinedProperties(arg: any): any;
    registerCache(): void;
    initializeCache(val: any): void;
    getInitialDataCache(): object;
    getDataCache(): object;
    restartCache(): void;
    setCacheSnapshot(): void;
    undoLastChange(): void;
    protected undoComponentValue(attr: string, val: any): void;
    protected hasComponentChanged(attr: string, comp: IFormControlComponent): boolean;
    protected getCacheLastValue(attr: string): any;
    protected updateChangesStack(attr: string): void;
    get isCacheStackEmpty(): boolean;
    isInitialStateChanged(ignoreAttrs?: string[]): boolean;
    getChangedFormControlsAttr(): string[];
}
//# sourceMappingURL=o-form.cache.class.d.ts.map