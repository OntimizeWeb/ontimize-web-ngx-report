import * as i0 from "@angular/core";
import * as i1 from "./o-time-input.component";
export declare class OTimeInputModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OTimeInputModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OTimeInputModule, never, [typeof i1.OTimeInputComponent], [typeof i1.OTimeInputComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OTimeInputModule>;
}
//# sourceMappingURL=o-time-input.module.d.ts.map