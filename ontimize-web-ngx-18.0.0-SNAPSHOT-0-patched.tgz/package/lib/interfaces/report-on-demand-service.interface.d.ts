import { OTableBase } from "../components/table/o-table-base.class";
export interface IReportService {
    openReportOnDemand(table: OTableBase): void;
}
//# sourceMappingURL=report-on-demand-service.interface.d.ts.map