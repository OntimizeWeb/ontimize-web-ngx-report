import { EventEmitter } from '@angular/core';
import { ILocalStorageComponent } from '../interfaces/local-storage-component.interface';
export interface ILocalStorageService {
    onRouteChange: EventEmitter<any>;
    onSetLocalStorage: EventEmitter<any>;
    getComponentStorage(comp: ILocalStorageComponent, routeKey?: string): any;
    updateComponentStorage(comp: ILocalStorageComponent, routeKey?: string): any;
    updateAppComponentStorage(componentKey: string, componentData: object): any;
    getSessionUserComponentsData(): object;
    storeSessionUserComponentsData(componentsData: object): any;
    getStoredData(): object;
    setBackwardCompatibility(): any;
    setLocalStorage(appData: any): any;
    removeStoredData(): any;
}
//# sourceMappingURL=local-service.interface.d.ts.map