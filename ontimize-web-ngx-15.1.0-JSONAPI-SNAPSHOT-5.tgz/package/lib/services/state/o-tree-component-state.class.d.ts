import { DefaultServiceComponentStateClass } from './o-component-state.class';
export declare class OTreeComponentStateClass extends DefaultServiceComponentStateClass {
}
//# sourceMappingURL=o-tree-component-state.class.d.ts.map