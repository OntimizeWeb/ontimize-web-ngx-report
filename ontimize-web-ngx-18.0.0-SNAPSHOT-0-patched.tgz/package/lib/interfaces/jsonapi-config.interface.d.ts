export interface IJsonApiConfig {
    multipleKeyDelimiter: string;
}
//# sourceMappingURL=jsonapi-config.interface.d.ts.map