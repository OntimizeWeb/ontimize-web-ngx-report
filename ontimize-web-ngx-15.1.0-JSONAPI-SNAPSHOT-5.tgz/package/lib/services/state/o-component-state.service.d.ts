import { Injector } from '@angular/core';
import { ILocalStorageComponent } from '../../interfaces/local-storage-component.interface';
import { LocalStorageService } from '../local-storage.service';
import { AbstractComponentStateClass, DefaultComponentStateClass, DefaultServiceComponentStateClass } from './o-component-state.class';
import * as i0 from "@angular/core";
export declare abstract class AbstractComponentStateService<S extends AbstractComponentStateClass, C extends ILocalStorageComponent = any> {
    protected injector: Injector;
    protected localStorageService: LocalStorageService;
    protected component: C;
    state: S;
    constructor(injector: Injector);
    initialize(comp: C): void;
    initializeState(state: S): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AbstractComponentStateService<any, any>, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AbstractComponentStateService<any, any>>;
}
export declare class DefaultComponentStateService extends AbstractComponentStateService<DefaultComponentStateClass, ILocalStorageComponent> {
    initialize(comp: ILocalStorageComponent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DefaultComponentStateService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DefaultComponentStateService>;
}
export declare class DefaultServiceComponentStateService extends AbstractComponentStateService<DefaultServiceComponentStateClass, ILocalStorageComponent> {
    initialize(comp: ILocalStorageComponent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DefaultServiceComponentStateService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DefaultServiceComponentStateService>;
}
//# sourceMappingURL=o-component-state.service.d.ts.map