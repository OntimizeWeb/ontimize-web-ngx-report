export type ErrorData = {
    name: string;
    text: string;
};
//# sourceMappingURL=error-data.type.d.ts.map