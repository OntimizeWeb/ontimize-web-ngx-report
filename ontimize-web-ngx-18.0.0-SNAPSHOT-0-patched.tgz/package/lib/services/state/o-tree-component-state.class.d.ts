import { DefaultServiceComponentStateClass } from './o-component-state.class';
export declare class OTreeComponentStateClass extends DefaultServiceComponentStateClass {
    protected 'filter': string;
    'currentPage': number;
    'selection': any[];
}
//# sourceMappingURL=o-tree-component-state.class.d.ts.map