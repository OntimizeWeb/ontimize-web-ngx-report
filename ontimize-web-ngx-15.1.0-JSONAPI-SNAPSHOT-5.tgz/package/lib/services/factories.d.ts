import { InjectionToken, Injector } from '@angular/core';
import { IChartOnDemandService } from '../interfaces/chart-on-demand.interface';
import { IExportDataProvider } from '../interfaces/export-data-provider.interface';
import { IExportService } from '../interfaces/export-service.interface';
import { IFileService } from '../interfaces/file-service.interface';
import { IPermissionsService } from '../interfaces/permissions-service.interface';
import { IReportService } from '../interfaces/report-on-demand-service.interface';
import { OMatErrorOptions } from '../types/o-mat-error.type';
import { AuthService } from './auth.service';
import { OErrorDialogManager } from './o-error-dialog-manager.service';
import { OntimizeExportDataProviderService } from './ontimize-export-data-provider.service';
import { OntimizeExportService } from './ontimize/ontimize-export.service';
import { OntimizeService } from './ontimize/ontimize.service';
import { AbstractComponentStateService, DefaultComponentStateService } from './state/o-component-state.service';
import { OntimizeQueryArgumentsAdapter } from './query-arguments/ontimize-query-arguments.adapter';
import { IBaseQueryArgument } from './query-arguments/base-query-argument.interface';
import { OntimizeServiceResponseAdapter } from './ontimize/ontimize-service-response.adapter';
import { IServiceResponseAdapter } from '../interfaces/service-response-adapter.interface';
import { BaseServiceResponse } from './base-service-response.class';
import { IPreferencesService } from '../interfaces/prefereces-service.interface';
export declare const O_DATA_SERVICE: InjectionToken<unknown>;
export declare const O_TRANSLATE_SERVICE: InjectionToken<unknown>;
export declare const O_FILE_SERVICE: InjectionToken<IFileService>;
export declare const O_EXPORT_SERVICE: InjectionToken<IExportService>;
export declare const O_PERMISSION_SERVICE: InjectionToken<IPermissionsService>;
export declare const O_AUTH_SERVICE: InjectionToken<AuthService>;
export declare const O_COMPONENT_STATE_SERVICE: InjectionToken<DefaultComponentStateService>;
export declare const O_CHART_ON_DEMAND_SERVICE: InjectionToken<IChartOnDemandService>;
export declare const O_REPORT_SERVICE: InjectionToken<IReportService>;
export declare const O_ERROR_DIALOG_MANAGER: InjectionToken<OErrorDialogManager>;
export declare const O_EXPORT_DATA_SERVICE: InjectionToken<IExportDataProvider>;
export declare const O_MAT_ERROR_OPTIONS: InjectionToken<OMatErrorOptions>;
export declare const O_FORM_MESSAGE_SERVICE: InjectionToken<unknown>;
export declare function dataServiceFactory(injector: Injector): any;
export declare function fileServiceFactory(injector: Injector): IFileService;
export declare function exportServiceFactory(injector: Injector): IExportService;
export declare function exportDataFactory(injector: Injector): IExportDataProvider;
export declare function serviceRequestAdapterFactory(injector: Injector): IBaseQueryArgument;
export declare function serviceResponseAdapterFactory(injector: Injector): IServiceResponseAdapter<BaseServiceResponse>;
export declare function permissionsServiceFactory(injector: Injector): IPermissionsService;
export declare function preferencesServiceFactory(injector: Injector): IPreferencesService;
export declare function authServiceFactory(injector: Injector): AuthService;
export declare function componentStateFactory(injector: Injector): AbstractComponentStateService<any, any>;
export declare const OntimizeServiceProvider: {
    provide: typeof OntimizeService;
    useFactory: typeof dataServiceFactory;
    deps: (typeof Injector)[];
};
export declare const OntimizeExportServiceProvider: {
    provide: typeof OntimizeExportService;
    useFactory: typeof exportServiceFactory;
    deps: (typeof Injector)[];
};
export declare const OntimizeAuthServiceProvider: {
    provide: typeof AuthService;
    useFactory: typeof authServiceFactory;
    deps: (typeof Injector)[];
};
export declare const ComponentStateServiceProvider: {
    provide: typeof AbstractComponentStateService;
    useFactory: typeof componentStateFactory;
    deps: (typeof Injector)[];
};
export declare const ExportDataServiceProvider: {
    provide: typeof OntimizeExportDataProviderService;
    useFactory: typeof exportDataFactory;
    deps: (typeof Injector)[];
};
export declare const ServiceRequestAdapter: {
    provide: typeof OntimizeQueryArgumentsAdapter;
    useFactory: typeof serviceRequestAdapterFactory;
    deps: (typeof Injector)[];
};
export declare const ServiceResponseAdapter: {
    provide: typeof OntimizeServiceResponseAdapter;
    useFactory: typeof serviceResponseAdapterFactory;
    deps: (typeof Injector)[];
};
export declare function _getInjectionTokenValue<T>(token: InjectionToken<T>, injector: Injector): T;
//# sourceMappingURL=factories.d.ts.map