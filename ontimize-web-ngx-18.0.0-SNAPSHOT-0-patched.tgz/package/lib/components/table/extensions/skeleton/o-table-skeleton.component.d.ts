import { OSkeletonComponent } from '../../../o-skeleton.component';
import * as i0 from "@angular/core";
export declare class OTableSkeletonComponent extends OSkeletonComponent {
    getRows(): number[];
    private getElementTotalHeight;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableSkeletonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTableSkeletonComponent, "o-table-skeleton", never, {}, {}, never, never, true, never>;
}
//# sourceMappingURL=o-table-skeleton.component.d.ts.map