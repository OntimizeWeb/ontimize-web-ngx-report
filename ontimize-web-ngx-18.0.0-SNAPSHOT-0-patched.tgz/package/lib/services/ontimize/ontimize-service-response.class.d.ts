import { BaseServiceResponse } from '../base-service-response.class';
export declare class OntimizeServiceResponse extends BaseServiceResponse {
}
//# sourceMappingURL=ontimize-service-response.class.d.ts.map