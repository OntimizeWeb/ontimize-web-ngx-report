export type OFormGlobalConfig = {
    headerActions: string;
};
//# sourceMappingURL=o-form-global-config.type.d.ts.map