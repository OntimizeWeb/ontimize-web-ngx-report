import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { Moment } from 'moment';
import * as i0 from "@angular/core";
export declare class OntimizeMomentDateAdapter extends MomentDateAdapter {
    oFormat: string;
    constructor(dateLocale: string);
    format(date: any, displayFormat: string): string;
    parse(value: any, parseFormat: string | string[]): any | null;
    deserialize(value: any): Moment | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<OntimizeMomentDateAdapter, [{ optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OntimizeMomentDateAdapter>;
}
//# sourceMappingURL=ontimize-moment-date-adapter.d.ts.map