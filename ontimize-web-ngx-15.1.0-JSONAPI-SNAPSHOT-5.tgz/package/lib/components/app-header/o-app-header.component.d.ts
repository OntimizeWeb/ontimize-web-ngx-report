import { EventEmitter, Injector } from '@angular/core';
import { ThemePalette } from '@angular/material/core';
import { Observable } from 'rxjs';
import { AuthService } from '../../services';
import { DialogService } from '../../services/dialog.service';
import { OModulesInfoService } from '../../services/o-modules-info.service';
import { OUserInfoBase } from '../user-info/o-user-info-base.class';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_APP_HEADER: string[];
export declare const DEFAULT_OUTPUTS_O_APP_HEADER: string[];
export declare class OAppHeaderComponent {
    protected injector: Injector;
    protected dialogService: DialogService;
    protected modulesInfoService: OModulesInfoService;
    protected authService: AuthService;
    showTitle: boolean;
    showStaticTitle: boolean;
    staticTitle: string;
    headerTitle$: Observable<string>;
    userInfo: OUserInfoBase;
    showUserInfo: boolean;
    showLanguageSelector: boolean;
    useFlagIcons: boolean;
    onSidenavToggle: EventEmitter<void>;
    protected _headerHeight: string;
    set headerHeight(value: string);
    get headerHeight(): string;
    private _color;
    constructor(injector: Injector);
    ngOnInit(): void;
    onLogoutClick(): void;
    set color(newValue: ThemePalette);
    get color(): ThemePalette;
    static ɵfac: i0.ɵɵFactoryDeclaration<OAppHeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OAppHeaderComponent, "o-app-header", never, { "showUserInfo": "show-user-info"; "showLanguageSelector": "show-language-selector"; "useFlagIcons": "use-flag-icons"; "color": "color"; "headerHeight": "header-height"; "showTitle": "show-title"; "staticTitle": "static-title"; "showStaticTitle": "show-static-title"; }, { "onSidenavToggle": "onSidenavToggle"; }, never, ["*", "o-app-layout-header-projection-start", "o-app-layout-header-projection-end"], false, never>;
}
//# sourceMappingURL=o-app-header.component.d.ts.map