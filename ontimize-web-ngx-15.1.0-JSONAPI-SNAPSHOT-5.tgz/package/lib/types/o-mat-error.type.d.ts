export type OMatErrorType = 'standard' | 'lite';
export type OMatErrorOptions = {
    type?: OMatErrorType;
};
//# sourceMappingURL=o-mat-error.type.d.ts.map