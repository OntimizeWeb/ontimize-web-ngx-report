import { InjectionToken } from '@angular/core';
export declare const O_TREE_NODE_TOKEN: InjectionToken<any>;
//# sourceMappingURL=o-tree-tokens.d.ts.map