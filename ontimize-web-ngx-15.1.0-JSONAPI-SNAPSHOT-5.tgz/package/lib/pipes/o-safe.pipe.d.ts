import { Injector, PipeTransform } from '@angular/core';
import { DomSanitizer, SafeHtml, SafeUrl, SafeResourceUrl } from '@angular/platform-browser';
import * as i0 from "@angular/core";
export declare class OSafePipe implements PipeTransform {
    protected injector: Injector;
    protected sanitizer: DomSanitizer;
    constructor(injector: Injector);
    transform(value: any, type: string): SafeHtml | SafeUrl | SafeResourceUrl;
    static ɵfac: i0.ɵɵFactoryDeclaration<OSafePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<OSafePipe, "oSafe", false>;
}
//# sourceMappingURL=o-safe.pipe.d.ts.map