/// <amd-module name="ontimize-web-ngx" />
export * from './public-api';
//# sourceMappingURL=ontimize-web-ngx.d.ts.map