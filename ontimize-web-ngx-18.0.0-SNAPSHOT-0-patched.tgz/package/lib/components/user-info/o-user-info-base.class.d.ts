import type { OUserInfoConfigurationDirective } from "./user-info-configuration/o-user-info-configuration.directive";
export declare abstract class OUserInfoBase {
    abstract registerUserInfoConfiguration(userInfoMenu: OUserInfoConfigurationDirective): any;
}
//# sourceMappingURL=o-user-info-base.class.d.ts.map