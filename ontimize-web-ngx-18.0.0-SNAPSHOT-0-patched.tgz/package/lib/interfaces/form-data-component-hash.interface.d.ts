import { IFormDataComponent } from "./form-data-component.interface";
export interface IFormDataComponentHash {
    [attr: string]: IFormDataComponent;
}
//# sourceMappingURL=form-data-component-hash.interface.d.ts.map