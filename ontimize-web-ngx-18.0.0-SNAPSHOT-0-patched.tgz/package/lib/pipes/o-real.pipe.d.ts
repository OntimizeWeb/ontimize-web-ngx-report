import { Injector, PipeTransform } from '@angular/core';
import { OIntegerPipe } from './o-integer.pipe';
import * as i0 from "@angular/core";
export interface IRealPipeArgument {
    grouping?: boolean;
    thousandSeparator?: string;
    locale?: string;
    decimalSeparator?: string;
    minDecimalDigits?: number;
    maxDecimalDigits?: number;
    truncate?: boolean;
}
export declare class ORealPipe extends OIntegerPipe implements PipeTransform {
    protected injector: Injector;
    constructor(injector: Injector);
    transform(text: string, args: IRealPipeArgument): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ORealPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<ORealPipe, "oReal", true>;
}
//# sourceMappingURL=o-real.pipe.d.ts.map