import * as i0 from "@angular/core";
import * as i1 from "./o-dual-list-selector.component";
import * as i2 from "./dual-list-selector-item/date/o-dual-list-selector-date-item.component";
import * as i3 from "@angular/common";
import * as i4 from "../../shared/shared.module";
import * as i5 from "@angular/cdk/drag-drop";
export declare class ODualListSelectorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ODualListSelectorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ODualListSelectorModule, [typeof i1.ODualListSelectorComponent, typeof i2.ODualListSelectorDateItemComponent], [typeof i3.CommonModule, typeof i4.OSharedModule, typeof i5.DragDropModule], [typeof i1.ODualListSelectorComponent, typeof i2.ODualListSelectorDateItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ODualListSelectorModule>;
}
//# sourceMappingURL=o-dual-list-selector.module.d.ts.map