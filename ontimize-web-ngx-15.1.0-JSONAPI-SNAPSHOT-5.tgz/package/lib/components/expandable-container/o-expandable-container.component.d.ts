import { AfterViewInit } from '@angular/core';
import { IServiceDataComponent } from '../../interfaces/service-data-component.interface';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUT_O_EXPANDABLE_CONTAINER: string[];
export declare class OExpandableContainerComponent implements AfterViewInit {
    targets: IServiceDataComponent[];
    data: any;
    constructor();
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OExpandableContainerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OExpandableContainerComponent, "o-expandable-container", never, { "targets": "targets"; "data": "data"; }, {}, never, ["*"], false, never>;
}
//# sourceMappingURL=o-expandable-container.component.d.ts.map