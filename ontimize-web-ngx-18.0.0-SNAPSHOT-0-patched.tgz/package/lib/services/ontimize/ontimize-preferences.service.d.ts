import { Injector } from '@angular/core';
import { Observable } from 'rxjs';
import { OntimizeEEService } from './ontimize-ee.service';
import * as i0 from "@angular/core";
export declare class OntimizePreferencesService extends OntimizeEEService {
    constructor(injector: Injector);
    path: string;
    configureService(config: any): void;
    configureAdapter(): void;
    saveAsPreferences(preferencesparams?: object): Observable<any>;
    savePreferences(id: number, preferencesparams?: object): Observable<any>;
    getPreferences(entity: string, service: string, type: string): Observable<any>;
    deletePreferences(id?: number): Observable<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OntimizePreferencesService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OntimizePreferencesService>;
}
//# sourceMappingURL=ontimize-preferences.service.d.ts.map