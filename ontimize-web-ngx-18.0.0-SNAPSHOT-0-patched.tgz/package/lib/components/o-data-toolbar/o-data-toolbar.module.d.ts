import * as i0 from "@angular/core";
import * as i1 from "./o-data-toolbar.component";
export declare class ODataToolbarModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ODataToolbarModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ODataToolbarModule, never, [typeof i1.ODataToolbarComponent], [typeof i1.ODataToolbarComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ODataToolbarModule>;
}
//# sourceMappingURL=o-data-toolbar.module.d.ts.map