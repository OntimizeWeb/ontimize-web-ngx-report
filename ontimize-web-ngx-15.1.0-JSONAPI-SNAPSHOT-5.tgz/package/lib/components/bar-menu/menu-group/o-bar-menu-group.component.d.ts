import { ElementRef, Injector } from '@angular/core';
import { OBaseMenuItemClass } from '../o-base-menu-item.class';
import { OBarMenuBase } from '../o-bar-menu-base.class';
import * as i0 from "@angular/core";
export declare class OBarMenuGroupComponent extends OBaseMenuItemClass {
    protected menu: OBarMenuBase;
    protected elRef: ElementRef;
    protected injector: Injector;
    id: string;
    constructor(menu: OBarMenuBase, elRef: ElementRef, injector: Injector);
    static ɵfac: i0.ɵɵFactoryDeclaration<OBarMenuGroupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OBarMenuGroupComponent, "o-bar-menu-group", never, {}, {}, never, ["*"], false, never>;
}
//# sourceMappingURL=o-bar-menu-group.component.d.ts.map