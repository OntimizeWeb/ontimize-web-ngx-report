import { Injector, OnInit, TemplateRef } from '@angular/core';
import { ICurrencyPipeArgument, OCurrencyPipe } from '../../../../../pipes/o-currency.pipe';
import { CurrencyService } from '../../../../../services/currency.service';
import { OListPickerRendererRealComponent } from '../real/o-list-picker-renderer-real.component';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_LISTPICKER_RENDERER_CURRENCY: string[];
export declare class OListPickerRendererCurrencyComponent extends OListPickerRendererRealComponent implements OnInit {
    protected injector: Injector;
    minDecimalDigits: number;
    maxDecimalDigits: number;
    protected currencySymbol: string;
    protected currencySymbolPosition: string;
    protected decimalSeparator: string;
    protected grouping: boolean;
    protected thousandSeparator: string;
    protected currencyService: CurrencyService;
    protected componentPipe: OCurrencyPipe;
    protected pipeArguments: ICurrencyPipeArgument;
    templateref: TemplateRef<any>;
    constructor(injector: Injector);
    setComponentPipe(): void;
    initialize(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OListPickerRendererCurrencyComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OListPickerRendererCurrencyComponent, "o-list-picker-renderer-currency", never, { "currencySymbol": { "alias": "currency-symbol"; "required": false; }; "currencySymbolPosition": { "alias": "currency-symbol-position"; "required": false; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=o-list-picker-renderer-currency.component.d.ts.map