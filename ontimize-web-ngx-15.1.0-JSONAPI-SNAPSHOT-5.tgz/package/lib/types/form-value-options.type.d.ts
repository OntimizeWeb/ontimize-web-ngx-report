export type FormValueOptions = {
    onlySelf?: boolean;
    emitEvent?: boolean;
    emitModelToViewChange?: boolean;
    emitViewToModelChange?: boolean;
    changeType?: number;
    emitModelToViewValueChange?: boolean;
};
//# sourceMappingURL=form-value-options.type.d.ts.map