export declare abstract class AbstractComponentStateClass {
    abstract setData(data: any): any;
}
export declare abstract class AbstractServiceComponentStateClass extends AbstractComponentStateClass {
    abstract queryRows: number;
    abstract totalQueryRecordsNumber: number;
    abstract queryRecordOffset: number;
    abstract quickFilterValue: string;
}
export declare class DefaultComponentStateClass extends AbstractComponentStateClass {
    setData(data: any): void;
}
export declare class DefaultServiceComponentStateClass extends AbstractServiceComponentStateClass {
    protected 'filter-case-sensitive': boolean;
    protected filterValue: string;
    totalQueryRecordsNumber: number;
    queryRecordOffset: number;
    protected 'query-rows': number;
    get filterCaseSensitive(): boolean;
    set filterCaseSensitive(value: boolean);
    get quickFilterValue(): string;
    set quickFilterValue(value: string);
    get queryRows(): number;
    set queryRows(value: number);
    constructor();
    setData(data: any): void;
}
//# sourceMappingURL=o-component-state.class.d.ts.map