import { AfterContentInit, ChangeDetectorRef, ElementRef, Injector, QueryList, Renderer2 } from '@angular/core';
import { MatListItem, MatListItemLine, MatListItemTitle } from '@angular/material/list';
import { OListComponent } from '../o-list.component';
import { ListItem } from './o-list-item';
import * as i0 from "@angular/core";
export declare class OListItemComponent implements ListItem, AfterContentInit {
    elRef: ElementRef;
    protected _renderer: Renderer2;
    protected _injector: Injector;
    protected cd: ChangeDetectorRef;
    _list: OListComponent;
    modelData: any;
    linesNo: number;
    _lines: QueryList<MatListItemLine>;
    _titles: QueryList<MatListItemTitle>;
    _innerListItem: MatListItem;
    constructor(elRef: ElementRef, _renderer: Renderer2, _injector: Injector, cd: ChangeDetectorRef, _list: OListComponent);
    ngAfterContentInit(): void;
    onDetailIconClicked(e?: Event): void;
    onEditIconClicked(e?: Event): void;
    setItemData(data: any): void;
    getItemData(): any;
    onCheckboxChange(): void;
    onCheckboxClicked(event: Event): void;
    get isSelected(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<OListItemComponent, [null, null, null, null, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OListItemComponent, "o-list-item", never, {}, {}, ["_lines", "_titles"], ["[o-list-item-avatar], [matListAvatar], [matListIcon]", "[matLine]", "o-list-item-card-image,o-list-item-card", "o-list-item-text,o-list-item-avatar, [o-list-item]"], false, never>;
}
//# sourceMappingURL=o-list-item.component.d.ts.map