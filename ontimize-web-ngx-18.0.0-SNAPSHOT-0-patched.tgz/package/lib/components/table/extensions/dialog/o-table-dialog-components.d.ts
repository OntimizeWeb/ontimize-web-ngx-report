import { OTableApplyConfigurationDialogComponent } from './apply-configuration/o-table-apply-configuration-dialog.component';
import { OTableExportDialogComponent } from './export/o-table-export-dialog.component';
import { OTableFilterByColumnDataDialogComponent } from './filter-by-column/o-table-filter-by-column-data-dialog.component';
import { OTableGroupByColumnsDialogComponent } from './group-by-columns/o-table-group-by-columns-dialog.component';
import { OTableStoreConfigurationDialogComponent } from './store-configuration/o-table-store-configuration-dialog.component';
import { OTableVisibleColumnsDialogComponent } from './visible-columns/o-table-visible-columns-dialog.component';
export declare const O_TABLE_DIALOGS: (typeof OTableApplyConfigurationDialogComponent | typeof OTableExportDialogComponent | typeof OTableFilterByColumnDataDialogComponent | typeof OTableStoreConfigurationDialogComponent | typeof OTableVisibleColumnsDialogComponent | typeof OTableGroupByColumnsDialogComponent)[];
//# sourceMappingURL=o-table-dialog-components.d.ts.map