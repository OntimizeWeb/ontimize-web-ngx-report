import { Expression } from './expression.type';
export type FilterExpression = {
    '@filter_expression': Expression;
};
//# sourceMappingURL=filter-expression.type.d.ts.map