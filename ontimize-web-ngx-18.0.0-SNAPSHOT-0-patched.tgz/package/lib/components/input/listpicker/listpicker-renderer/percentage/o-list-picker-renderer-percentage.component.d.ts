import { Injector, OnInit, TemplateRef } from '@angular/core';
import { IPercentPipeArgument, OPercentageValueBaseType, OPercentPipe } from '../../../../../pipes/o-percentage.pipe';
import { OListPickerRendererRealComponent } from '../real/o-list-picker-renderer-real.component';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_LISTPICKER_RENDERER_PERCENTAGE: any[];
export declare class OListPickerRendererPercentageComponent extends OListPickerRendererRealComponent implements OnInit {
    protected injector: Injector;
    decimalSeparator: string;
    minDecimalDigits: number;
    maxDecimalDigits: number;
    valueBase: OPercentageValueBaseType;
    protected componentPipe: OPercentPipe;
    protected pipeArguments: IPercentPipeArgument;
    templateref: TemplateRef<any>;
    constructor(injector: Injector);
    setComponentPipe(): void;
    initialize(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OListPickerRendererPercentageComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OListPickerRendererPercentageComponent, "o-list-picker-renderer-percentage", never, { "grouping": { "alias": "grouping"; "required": false; }; "thousandSeparator": { "alias": "thousand-separator"; "required": false; }; "decimalSeparator": { "alias": "decimal-separator"; "required": false; }; "minDecimalDigits": { "alias": "min-decimal-digits"; "required": false; }; "maxDecimalDigits": { "alias": "max-decimal-digits"; "required": false; }; "valueBase": { "alias": "value-base"; "required": false; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=o-list-picker-renderer-percentage.component.d.ts.map