import { Injector } from '@angular/core';
import { MatIconRegistry } from '@angular/material/icon';
import { Observable } from 'rxjs';
import { OSafePipe } from '../pipes/o-safe.pipe';
import * as i0 from "@angular/core";
export declare class OntimizeMatIconRegistry {
    protected matIconRegistry: MatIconRegistry;
    protected injector: Injector;
    static ONTIMIZE_ICON_SET_PATH: string;
    static ONTIMIZE_NAMESPACE: string;
    protected oSafePipe: OSafePipe;
    constructor(matIconRegistry: MatIconRegistry, injector: Injector);
    initialize(): void;
    addOntimizeSvgIcon(iconName: string, url: string): MatIconRegistry;
    getSVGElement(iconName: string): Observable<SVGElement>;
    existsIcon(iconName: string): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OntimizeMatIconRegistry, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OntimizeMatIconRegistry>;
}
//# sourceMappingURL=ontimize-icon-registry.service.d.ts.map