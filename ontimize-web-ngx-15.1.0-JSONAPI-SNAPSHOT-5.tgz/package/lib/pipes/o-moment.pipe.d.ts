import { Injector, PipeTransform } from '@angular/core';
import { MomentService } from '../services/moment.service';
import * as i0 from "@angular/core";
export interface IMomentPipeArgument {
    format?: string;
}
export declare class OMomentPipe implements PipeTransform {
    protected injector: Injector;
    protected momentService: MomentService;
    constructor(injector: Injector);
    transform(value: any, args: IMomentPipeArgument): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<OMomentPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<OMomentPipe, "oMoment", false>;
}
//# sourceMappingURL=o-moment.pipe.d.ts.map