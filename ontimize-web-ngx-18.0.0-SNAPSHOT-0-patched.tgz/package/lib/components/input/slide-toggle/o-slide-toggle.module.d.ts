import * as i0 from "@angular/core";
import * as i1 from "./o-slide-toggle.component";
export declare class OSlideToggleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OSlideToggleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OSlideToggleModule, never, [typeof i1.OSlideToggleComponent], [typeof i1.OSlideToggleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OSlideToggleModule>;
}
//# sourceMappingURL=o-slide-toggle.module.d.ts.map