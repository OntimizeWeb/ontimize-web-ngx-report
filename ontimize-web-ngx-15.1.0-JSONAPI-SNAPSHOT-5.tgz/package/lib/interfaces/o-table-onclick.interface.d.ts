export interface OnClickTableEvent {
    row: any;
    rowIndex: number;
    mouseEvent: MouseEvent;
    columnName: string;
    cell: any;
}
//# sourceMappingURL=o-table-onclick.interface.d.ts.map