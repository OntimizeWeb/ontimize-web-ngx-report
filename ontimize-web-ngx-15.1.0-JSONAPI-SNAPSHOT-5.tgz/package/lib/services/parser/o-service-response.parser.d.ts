import { Injector } from '@angular/core';
import { Subscriber } from 'rxjs';
import { BaseService } from '../base-service.class';
import { BaseResponse } from '../../interfaces/base-response.interface';
import { HttpErrorResponse } from '@angular/common/http';
import { AppConfig } from '../../config/app-config';
import * as i0 from "@angular/core";
export declare class OntimizeServiceResponseParser<T extends BaseResponse> {
    protected injector: Injector;
    appConfig: AppConfig;
    nameConvention: string;
    constructor(injector: Injector);
    parseSuccessfulResponse(resp: T, subscriber: Subscriber<T>, service: BaseService<T>): void;
    parseData(data: any): any;
    parseUnsuccessfulResponse(error: HttpErrorResponse, subscriber: Subscriber<T>, service: BaseService<T>): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OntimizeServiceResponseParser<any>, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OntimizeServiceResponseParser<any>>;
}
//# sourceMappingURL=o-service-response.parser.d.ts.map