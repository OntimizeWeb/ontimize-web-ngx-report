import { Injector } from '@angular/core';
import { OFormLayoutManagerComponent } from '../layouts/form-layout/o-form-layout-manager.component';
import * as i0 from "@angular/core";
export declare class OFormLayoutManagerService {
    protected injector: Injector;
    protected registeredFormLayoutManagers: {};
    protected _activeFormLayoutManager: OFormLayoutManagerComponent;
    constructor(injector: Injector);
    registerFormLayoutManager(comp: OFormLayoutManagerComponent): void;
    removeFormLayoutManager(comp: OFormLayoutManagerComponent): void;
    get activeFormLayoutManager(): OFormLayoutManagerComponent;
    set activeFormLayoutManager(arg: OFormLayoutManagerComponent);
    static ɵfac: i0.ɵɵFactoryDeclaration<OFormLayoutManagerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OFormLayoutManagerService>;
}
//# sourceMappingURL=o-form-layout-manager.service.d.ts.map