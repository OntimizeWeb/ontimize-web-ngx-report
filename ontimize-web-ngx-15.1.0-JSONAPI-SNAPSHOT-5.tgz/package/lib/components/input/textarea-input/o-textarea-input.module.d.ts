import * as i0 from "@angular/core";
import * as i1 from "./o-textarea-input.component";
import * as i2 from "@angular/common";
import * as i3 from "../../../shared/shared.module";
export declare class OTextareaInputModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OTextareaInputModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OTextareaInputModule, [typeof i1.OTextareaInputComponent], [typeof i2.CommonModule, typeof i3.OSharedModule], [typeof i1.OTextareaInputComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OTextareaInputModule>;
}
//# sourceMappingURL=o-textarea-input.module.d.ts.map