export type OColumnDisplay = {
    attr: string;
    visible: boolean;
    width: string;
};
//# sourceMappingURL=o-column-display.type.d.ts.map