import { OnInit } from '@angular/core';
import { ODateValueType } from '../../../../../../types/o-date-value.type';
import * as i0 from "@angular/core";
export type OTableFilterMode = 'default' | 'custom' | 'selection';
export type OFilterColumn = {
    attr: string;
    sort: 'asc' | 'desc' | '';
    startView: 'month' | 'year' | 'multi-year' | '';
    queryMethod?: string;
    filterValuesInData?: 'current-page' | 'all-data';
    service?: string;
    entity?: string;
    serviceType?: string;
    separator?: string;
    visibleColumns?: string[];
    filterLocked?: boolean;
    filterLockedMessage?: string;
    mode?: OTableFilterMode;
    dateFormat?: string;
    dateValueType?: ODateValueType;
};
export declare const DEFAULT_INPUTS_O_TABLE_COLUMN_FILTER_COLUMN: string[];
export declare class OTableColumnsFilterColumnComponent implements OnInit {
    attr: string;
    sort: 'asc' | 'desc' | '';
    startView: 'month' | 'year' | 'multi-year' | '';
    queryMethod: string;
    filterValuesInData: 'current-page' | 'all-data';
    filterLocked: boolean;
    filterLockedMessage: string;
    service: string;
    serviceType: string;
    entity: string;
    visibleColsArray: string[];
    visibleColumns: string;
    separator: string;
    dateFormat: string;
    mode: OTableFilterMode;
    private _dateValueType;
    ngOnInit(): void;
    set dateValueType(val: any);
    get dateValueType(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableColumnsFilterColumnComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTableColumnsFilterColumnComponent, "o-table-columns-filter-column", never, { "attr": { "alias": "attr"; "required": false; }; "sort": { "alias": "sort"; "required": false; }; "startView": { "alias": "start-view"; "required": false; }; "queryMethod": { "alias": "query-method"; "required": false; }; "filterValuesInData": { "alias": "filter-values-in-data"; "required": false; }; "filterLocked": { "alias": "filter-locked"; "required": false; }; "filterLockedMessage": { "alias": "filter-locked-message"; "required": false; }; "service": { "alias": "service"; "required": false; }; "serviceType": { "alias": "service-type"; "required": false; }; "entity": { "alias": "entity"; "required": false; }; "visibleColumns": { "alias": "visible-columns"; "required": false; }; "separator": { "alias": "separator"; "required": false; }; "dateFormat": { "alias": "date-format"; "required": false; }; "dateValueType": { "alias": "date-value-type"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=o-table-columns-filter-column.component.d.ts.map