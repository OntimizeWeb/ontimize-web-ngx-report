import { Injector } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { type ODialogConfig } from '../shared';
import { ODialogInternalComponent } from '../shared/components/dialog/o-dialog-internal.component';
import { SessionInfo } from '../types/session-info.type';
import * as i0 from "@angular/core";
export declare abstract class AuthService {
    protected injector: Injector;
    onLogin: Subject<any>;
    onLogout: Subject<any>;
    protected ng2Dialog: MatDialog;
    dialogRef: MatDialogRef<ODialogInternalComponent>;
    constructor(injector: Injector);
    abstract login(user: string, password: string): Observable<any>;
    abstract logout(): Observable<any>;
    abstract clearSessionData(): void;
    abstract isLoggedIn(): boolean;
    abstract getSessionInfo(): SessionInfo;
    logoutWithConfirmation(): void;
    confirm(title: string, message: string, config?: ODialogConfig): Promise<any>;
    protected openDialog(observer: any): void;
    alert(title: string, message: string, config?: ODialogConfig): Promise<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AuthService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AuthService>;
}
//# sourceMappingURL=auth.service.d.ts.map