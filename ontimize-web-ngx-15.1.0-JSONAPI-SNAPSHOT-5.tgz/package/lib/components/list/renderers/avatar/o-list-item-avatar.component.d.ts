import { AfterViewInit, ElementRef, Injector, OnInit, Renderer2 } from '@angular/core';
import { OListItemComponent } from '../../list-item/o-list-item.component';
import { OListItemTextRenderer } from '../o-list-item-text-renderer.class';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_LIST_ITEM_AVATAR: string[];
export declare class OListItemAvatarComponent extends OListItemTextRenderer implements AfterViewInit, OnInit {
    protected _listItem: OListItemComponent;
    avatarSrc: string;
    protected avatar: string;
    protected avatarType: string;
    protected emptyAvatar: string;
    constructor(elRef: ElementRef, _renderer: Renderer2, _injector: Injector, _listItem: OListItemComponent);
    ngAfterViewInit(): void;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OListItemAvatarComponent, [null, null, null, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OListItemAvatarComponent, "o-list-item-avatar", never, { "avatar": "avatar"; "emptyAvatar": "empty-avatar"; "avatarType": "avatar-type"; }, {}, never, never, false, never>;
}
//# sourceMappingURL=o-list-item-avatar.component.d.ts.map