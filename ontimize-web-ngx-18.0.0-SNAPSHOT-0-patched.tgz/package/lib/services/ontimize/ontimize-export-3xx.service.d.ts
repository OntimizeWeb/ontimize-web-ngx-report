import { HttpHeaders } from '@angular/common/http';
import { Injector } from '@angular/core';
import { Observable } from 'rxjs';
import { IExportDataProvider } from '../../interfaces/export-data-provider.interface';
import { IExportService } from '../../interfaces/export-service.interface';
import { ServiceResponse } from '../../interfaces/service-response.interface';
import { BaseService } from '../base-service.class';
import * as i0 from "@angular/core";
export declare class OntimizeExportService3X extends BaseService<ServiceResponse> implements IExportService {
    protected injector: Injector;
    exportPath: string;
    servicePath: string;
    protected exportDataProvider: IExportDataProvider;
    constructor(injector: Injector);
    configureService(config: any): void;
    protected buildHeaders(): HttpHeaders;
    exportData(format: string, columns?: string[], landscape?: boolean, filename?: string): Observable<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OntimizeExportService3X, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OntimizeExportService3X>;
}
//# sourceMappingURL=ontimize-export-3xx.service.d.ts.map