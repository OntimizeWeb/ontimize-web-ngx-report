import { Injector } from "@angular/core";
import type { IExportDataProvider } from "../interfaces/export-data-provider.interface";
import { OntimizeExportDataBaseProviderService } from "./ontimize-export-data-base-provider.service";
import * as i0 from "@angular/core";
export declare class OntimizeExportDataProviderService3X extends OntimizeExportDataBaseProviderService implements IExportDataProvider {
    protected injector: Injector;
    constructor(injector: Injector);
    getExportConfiguration(param: any): any;
    private parseColumns;
    static ɵfac: i0.ɵɵFactoryDeclaration<OntimizeExportDataProviderService3X, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OntimizeExportDataProviderService3X>;
}
//# sourceMappingURL=ontimize-export-data-provider-3x.service.d.ts.map