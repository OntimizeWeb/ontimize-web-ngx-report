import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_DATA_TOOLBAR: string[];
export declare class ODataToolbarComponent {
    showTitle: boolean;
    title: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ODataToolbarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ODataToolbarComponent, "o-data-toolbar", never, { "showTitle": { "alias": "show-title"; "required": false; }; "title": { "alias": "title"; "required": false; }; }, {}, never, ["[o-data-toolbar-projection-start]", "[o-data-toolbar-custom-projection-start]", "[o-data-toolbar-custom-projection-end]", "[o-data-toolbar-projection-end]"], true, never>;
}
//# sourceMappingURL=o-data-toolbar.component.d.ts.map