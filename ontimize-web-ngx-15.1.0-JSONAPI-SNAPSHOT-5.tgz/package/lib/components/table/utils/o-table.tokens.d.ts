import { InjectionToken } from "@angular/core";
import { OTableGlobalConfig } from "../../../types/table/o-table-global-config.type";
export declare const O_TABLE_GLOBAL_CONFIG: InjectionToken<OTableGlobalConfig>;
//# sourceMappingURL=o-table.tokens.d.ts.map