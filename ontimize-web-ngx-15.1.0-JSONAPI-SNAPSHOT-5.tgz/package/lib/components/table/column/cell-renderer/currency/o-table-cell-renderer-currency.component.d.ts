import { Injector, OnInit, TemplateRef } from '@angular/core';
import { ICurrencyPipeArgument, OCurrencyPipe } from '../../../../../pipes/o-currency.pipe';
import { CurrencyService } from '../../../../../services/currency.service';
import { OTableCellRendererRealComponent } from '../real/o-table-cell-renderer-real.component';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_TABLE_CELL_RENDERER_CURRENCY: string[];
export declare class OTableCellRendererCurrencyComponent extends OTableCellRendererRealComponent implements OnInit {
    protected injector: Injector;
    minDecimalDigits: number;
    maxDecimalDigits: number;
    protected currencySymbol: string;
    protected currencySymbolPosition: string;
    protected decimalSeparator: string;
    protected grouping: boolean;
    protected thousandSeparator: string;
    protected currencyService: CurrencyService;
    protected componentPipe: OCurrencyPipe;
    protected pipeArguments: ICurrencyPipeArgument;
    templateref: TemplateRef<any>;
    constructor(injector: Injector);
    setComponentPipe(): void;
    initialize(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableCellRendererCurrencyComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTableCellRendererCurrencyComponent, "o-table-cell-renderer-currency", never, { "currencySymbol": "currency-symbol"; "currencySymbolPosition": "currency-symbol-position"; }, {}, never, never, false, never>;
}
//# sourceMappingURL=o-table-cell-renderer-currency.component.d.ts.map