import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_APP_LAYOUT_SIDENAV: string[];
export declare class OAppLayoutSidenavComponent {
    position: 'start' | 'end';
    static ɵfac: i0.ɵɵFactoryDeclaration<OAppLayoutSidenavComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OAppLayoutSidenavComponent, "o-app-layout-sidenav", never, { "position": { "alias": "position"; "required": false; }; }, {}, never, ["*"], true, never>;
}
//# sourceMappingURL=o-app-layout-sidenav.component.d.ts.map