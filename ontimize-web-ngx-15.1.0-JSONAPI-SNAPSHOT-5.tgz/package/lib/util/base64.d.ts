export declare class Base64 {
    private static PADCHAR;
    private static ALPHA;
    static decode(s: string): string;
    static encode(s: string): string;
    private static getByte;
    private static getByte64;
}
//# sourceMappingURL=base64.d.ts.map