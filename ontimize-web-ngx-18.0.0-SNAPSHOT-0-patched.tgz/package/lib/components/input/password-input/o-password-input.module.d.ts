import * as i0 from "@angular/core";
import * as i1 from "./o-password-input.component";
export declare class OPasswordInputModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OPasswordInputModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OPasswordInputModule, never, [typeof i1.OPasswordInputComponent], [typeof i1.OPasswordInputComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OPasswordInputModule>;
}
//# sourceMappingURL=o-password-input.module.d.ts.map