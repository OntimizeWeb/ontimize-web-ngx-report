export interface BaseResponse {
    isSuccessful(): boolean;
    isFailed(): boolean;
    isUnauthorized(): boolean;
}
//# sourceMappingURL=base-response.interface.d.ts.map