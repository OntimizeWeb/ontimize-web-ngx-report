import { MatDialogRef } from '@angular/material/dialog';
import { OGroupedColumnTypes } from '../../../../../types/o-grouped-column-types.type';
import type { OColumn } from '../../../column/o-column.class';
import { ODualListSelectorComponent } from '../../../../dual-list-selector/o-dual-list-selector.component';
import * as i0 from "@angular/core";
export declare class OTableGroupByColumnsDialogComponent {
    dialogRef: MatDialogRef<OTableGroupByColumnsDialogComponent>;
    columns: Array<OColumn>;
    groupedColumns: Array<OColumn>;
    groupedColumnTypes: OGroupedColumnTypes[];
    dualListSelector: ODualListSelectorComponent;
    constructor(dialogRef: MatDialogRef<OTableGroupByColumnsDialogComponent>, data: any);
    getGroupedColumns(): Array<string>;
    getGroupedColumnTypes(): OGroupedColumnTypes[];
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableGroupByColumnsDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTableGroupByColumnsDialogComponent, "o-table-group-by-columns-dialog", never, {}, {}, never, never, true, never>;
}
//# sourceMappingURL=o-table-group-by-columns-dialog.component.d.ts.map