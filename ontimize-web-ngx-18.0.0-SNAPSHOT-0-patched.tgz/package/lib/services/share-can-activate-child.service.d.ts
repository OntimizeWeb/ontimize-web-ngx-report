import { ActivatedRouteSnapshot, Router, RouterStateSnapshot } from '@angular/router';
import { PermissionsGuardService } from './permissions/permissions-can-activate.guard';
import { PermissionsService } from './permissions/permissions.service';
import * as i0 from "@angular/core";
export declare class ShareCanActivateChildService {
    protected router: Router;
    protected permissionsService: PermissionsService;
    protected permissionsGuard: PermissionsGuardService;
    setPermissionsGuard(guard: PermissionsGuardService): void;
    canActivateChildUsingPermissions(childRoute: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ShareCanActivateChildService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ShareCanActivateChildService>;
}
//# sourceMappingURL=share-can-activate-child.service.d.ts.map