import { Injector, OnInit } from '@angular/core';
import { OValidatorComponent } from './o-validator.component';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_ERROR: string[];
export declare class OErrorComponent implements OnInit {
    protected oValidator: OValidatorComponent;
    protected injector: Injector;
    name: string;
    text: string;
    constructor(oValidator: OValidatorComponent, injector: Injector);
    ngOnInit(): void;
    registerValidatorError(): void;
    getName(): string;
    getText(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<OErrorComponent, [{ optional: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OErrorComponent, "o-error", never, { "name": { "alias": "name"; "required": false; }; "text": { "alias": "text"; "required": false; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=o-error.component.d.ts.map