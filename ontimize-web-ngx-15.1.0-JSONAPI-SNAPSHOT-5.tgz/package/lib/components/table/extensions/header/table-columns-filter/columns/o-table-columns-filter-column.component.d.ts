import * as i0 from "@angular/core";
export type OFilterColumn = {
    attr: string;
    sort: 'asc' | 'desc' | '';
    startView: 'month' | 'year' | 'multi-year' | '';
};
export declare const DEFAULT_INPUTS_O_TABLE_COLUMN_FILTER_COLUMN: string[];
export declare class OTableColumnsFilterColumnComponent {
    attr: string;
    sort: 'asc' | 'desc' | '';
    startView: 'month' | 'year' | 'multi-year' | '';
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableColumnsFilterColumnComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTableColumnsFilterColumnComponent, "o-table-columns-filter-column", never, { "attr": "attr"; "sort": "sort"; "startView": "start-view"; }, {}, never, never, false, never>;
}
//# sourceMappingURL=o-table-columns-filter-column.component.d.ts.map