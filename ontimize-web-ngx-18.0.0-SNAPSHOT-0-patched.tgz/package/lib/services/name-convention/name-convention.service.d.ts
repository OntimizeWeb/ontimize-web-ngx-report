import { INameConvention } from '../../interfaces/name-convention.interface';
export declare class NameConvention implements INameConvention {
    parseColumnsToNameConventionForOntimize(value: any): any[];
    parseColumnsToNameConventionForJSONAPI(value: any): string;
    parseDataToNameConvention(data: any): any;
    parseValuesDataToNameConvention(data: any): any;
    parseFilterExpresionNameConvention(data: any): any;
    parseResultToNameConvention(data: any): any;
    parseFilterToNameConvention(data: any): any;
}
//# sourceMappingURL=name-convention.service.d.ts.map