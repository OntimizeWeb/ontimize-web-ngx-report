import { Injector, OnInit, TemplateRef } from '@angular/core';
import { IMomentPipeArgument, OMomentPipe } from '../../../../../pipes/o-moment.pipe';
import { OComboCustomRenderer } from '../o-combo-renderer.class';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_COMBO_RENDERER_DATE: string[];
export declare class OComboRendererDateComponent extends OComboCustomRenderer implements OnInit {
    protected injector: Injector;
    protected componentPipe: OMomentPipe;
    protected pipeArguments: IMomentPipeArgument;
    protected format: string;
    templateref: TemplateRef<any>;
    constructor(injector: Injector);
    setComponentPipe(): void;
    initialize(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OComboRendererDateComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OComboRendererDateComponent, "o-combo-renderer-date", never, { "format": "format"; }, {}, never, never, false, never>;
}
//# sourceMappingURL=o-combo-renderer-date.component.d.ts.map