import { AfterViewInit, Injector } from '@angular/core';
import { UntypedFormGroup } from '@angular/forms';
import { MatCheckboxChange } from '@angular/material/checkbox';
import { MatDialogRef } from '@angular/material/dialog';
import { MatSelectionList } from '@angular/material/list';
import { OTableBaseDialogClass } from '../o-table-base-dialog.class';
import * as i0 from "@angular/core";
export declare class OTableStoreConfigurationDialogComponent extends OTableBaseDialogClass implements AfterViewInit {
    dialogRef: MatDialogRef<OTableStoreConfigurationDialogComponent>;
    protected injector: Injector;
    propertiesList: MatSelectionList;
    properties: any[];
    formGroup: UntypedFormGroup;
    constructor(dialogRef: MatDialogRef<OTableStoreConfigurationDialogComponent>, injector: Injector);
    ngAfterViewInit(): void;
    areAllSelected(): boolean;
    onSelectAllChange(event: MatCheckboxChange): void;
    getConfigurationAttributes(): any;
    getSelectedTableProperties(): any[];
    isIndeterminate(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableStoreConfigurationDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTableStoreConfigurationDialogComponent, "o-table-store-configuration-dialog", never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=o-table-store-configuration-dialog.component.d.ts.map