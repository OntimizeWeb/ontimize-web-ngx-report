import * as i0 from "@angular/core";
import * as i1 from "./o-password-input.component";
import * as i2 from "../../../shared/shared.module";
import * as i3 from "@angular/common";
import * as i4 from "../text-input/o-text-input.module";
export declare class OPasswordInputModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OPasswordInputModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OPasswordInputModule, [typeof i1.OPasswordInputComponent], [typeof i2.OSharedModule, typeof i3.CommonModule, typeof i4.OTextInputModule], [typeof i1.OPasswordInputComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OPasswordInputModule>;
}
//# sourceMappingURL=o-password-input.module.d.ts.map