import { BaseNameConvention } from './base-name-convention.service';
export declare class NameConventionUpper extends BaseNameConvention {
    parseToStringCase(value: any): any;
    parseOppositeToStringCase(value: any): any;
}
//# sourceMappingURL=name-convention-upper.service.d.ts.map