import { Injector, OnInit, TemplateRef } from '@angular/core';
import { IRealPipeArgument, ORealPipe } from '../../../../../pipes/o-real.pipe';
import { NumberService } from '../../../../../services/number.service';
import { OTableCellRendererIntegerComponent } from '../integer/o-table-cell-renderer-integer.component';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_TABLE_CELL_RENDERER_REAL: string[];
export declare class OTableCellRendererRealComponent extends OTableCellRendererIntegerComponent implements OnInit {
    protected injector: Injector;
    minDecimalDigits: number;
    maxDecimalDigits: number;
    protected decimalSeparator: string;
    protected numberService: NumberService;
    protected componentPipe: ORealPipe;
    protected pipeArguments: IRealPipeArgument;
    templateref: TemplateRef<any>;
    constructor(injector: Injector);
    setComponentPipe(): void;
    initialize(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableCellRendererRealComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTableCellRendererRealComponent, "o-table-cell-renderer-real", never, { "decimalSeparator": { "alias": "decimal-separator"; "required": false; }; "minDecimalDigits": { "alias": "min-decimal-digits"; "required": false; }; "maxDecimalDigits": { "alias": "max-decimal-digits"; "required": false; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=o-table-cell-renderer-real.component.d.ts.map