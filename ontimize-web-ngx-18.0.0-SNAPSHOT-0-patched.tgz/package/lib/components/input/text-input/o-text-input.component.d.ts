import { AfterViewInit, ElementRef, Injector, OnDestroy, OnInit, QueryList } from '@angular/core';
import { ValidatorFn } from '@angular/forms';
import { Subscription } from 'rxjs';
import { OMatPrefix } from '../../../directives/o-mat-prefix.directive';
import { OMatSuffix } from '../../../directives/o-mat-suffix.directive';
import { OFormComponent } from '../../form/o-form.component';
import { OFormDataComponent } from '../../o-form-data-component.class';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_TEXT_INPUT: string[];
export declare class OTextInputComponent extends OFormDataComponent implements OnInit, OnDestroy, AfterViewInit {
    _prefixChildren: QueryList<OMatPrefix>;
    _suffixChildren: QueryList<OMatSuffix>;
    stringCase: string;
    protected _minLength: number;
    protected _maxLength: number;
    protected upperSubscription: Subscription;
    regulatePattern: string;
    constructor(form: OFormComponent, elRef: ElementRef, injector: Injector);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    onFormControlChange(value: any): void;
    protected transformStringCase(value: any): any;
    resolveValidators(): ValidatorFn[];
    set minLength(val: number);
    get minLength(): number;
    set maxLength(val: number);
    get maxLength(): number;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTextInputComponent, [{ optional: true; }, null, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTextInputComponent, "o-text-input", never, { "minLength": { "alias": "min-length"; "required": false; }; "maxLength": { "alias": "max-length"; "required": false; }; "stringCase": { "alias": "string-case"; "required": false; }; "regulatePattern": { "alias": "regulate-pattern"; "required": false; }; }, {}, ["_prefixChildren", "_suffixChildren"], ["[oMatPrefix]", "[oMatSuffix]"], true, never>;
}
//# sourceMappingURL=o-text-input.component.d.ts.map