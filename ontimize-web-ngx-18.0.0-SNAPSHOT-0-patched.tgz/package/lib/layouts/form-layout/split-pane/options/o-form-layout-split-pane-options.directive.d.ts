import { OFormLayoutManagerComponent } from '../../o-form-layout-manager.component';
import * as i0 from "@angular/core";
export declare class OFormLayoutSplitPaneOptionsDirective {
    protected formLayoutManager: OFormLayoutManagerComponent;
    constructor(formLayoutManager: OFormLayoutManagerComponent);
    ngOnChanges(): void;
    mainWidth: number | string;
    mainMaxWidth: number | string;
    mainMinWidth: number | string;
    detailWidth: number | string;
    detailMaxWidth: number | string;
    detailMinWidth: number | string;
    getOptions(): {
        mainWidth: string | number;
        mainMaxWidth: string | number;
        mainMinWidth: string | number;
        detailWidth: string | number;
        detailMaxWidth: string | number;
        detailMinWidth: string | number;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<OFormLayoutSplitPaneOptionsDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OFormLayoutSplitPaneOptionsDirective, "o-form-layout-split-pane-options, o-form-layout-manager[mode=\"split-pane\"]", never, { "mainWidth": { "alias": "main-width"; "required": false; }; "mainMaxWidth": { "alias": "main-max-width"; "required": false; }; "mainMinWidth": { "alias": "main-min-width"; "required": false; }; "detailWidth": { "alias": "detail-width"; "required": false; }; "detailMaxWidth": { "alias": "detail-max-width"; "required": false; }; "detailMinWidth": { "alias": "detail-min-width"; "required": false; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=o-form-layout-split-pane-options.directive.d.ts.map