import { AbstractComponentStateService } from './o-component-state.service';
import { OFormLayoutManagerComponentStateClass } from './o-form-layout-manager-component-state.class';
import { OFormLayoutManagerBase } from '../../layouts/form-layout/o-form-layout-manager-base.class';
import * as i0 from "@angular/core";
export declare class OFormLayoutManagerComponentStateService extends AbstractComponentStateService<OFormLayoutManagerComponentStateClass, OFormLayoutManagerBase> {
    initialize(component: OFormLayoutManagerBase): void;
    initializeState(state: OFormLayoutManagerComponentStateClass): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OFormLayoutManagerComponentStateService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OFormLayoutManagerComponentStateService>;
}
//# sourceMappingURL=o-form-layout-manager-component-state.service.d.ts.map