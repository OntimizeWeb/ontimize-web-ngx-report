import { BaseRequestArgument } from './base-request-argument.adapter';
import { IBaseRequestArgument } from './base-request-argument.interface';
import * as i0 from "@angular/core";
export declare class OntimizeRequestArgumentsAdapter extends BaseRequestArgument implements IBaseRequestArgument {
    parseQueryParameters(args: any): any[];
    static ɵfac: i0.ɵɵFactoryDeclaration<OntimizeRequestArgumentsAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OntimizeRequestArgumentsAdapter>;
}
//# sourceMappingURL=ontimize-request-arguments.adapter.d.ts.map