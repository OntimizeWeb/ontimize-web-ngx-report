import { AfterViewInit, ElementRef, Injector, Renderer2 } from '@angular/core';
import { OTableBase } from '../../../o-table-base.class';
import * as i0 from "@angular/core";
export declare class OTableExpandedFooterDirective implements AfterViewInit {
    table: OTableBase;
    element: ElementRef;
    private renderer;
    protected injector: Injector;
    private spanMessageNotResults;
    private translateService;
    private tableBody;
    private tdTableWithMessage;
    private subscription;
    set colspan(value: number);
    get colspan(): number;
    private _colspan;
    constructor(table: OTableBase, element: ElementRef, renderer: Renderer2, injector: Injector);
    ngAfterViewInit(): void;
    registerContentChange(): void;
    showMessage(display: boolean): void;
    removeMessageSpan(): void;
    destroy(): void;
    protected buildMessage(): string;
    protected tableHasQuickFilter(): boolean;
    protected createMessageSpan(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableExpandedFooterDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OTableExpandedFooterDirective, "[oTableExpandedFooter]", never, { "colspan": { "alias": "oTableExpandedFooterColspan"; "required": false; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=o-table-expanded-footer.directive.d.ts.map