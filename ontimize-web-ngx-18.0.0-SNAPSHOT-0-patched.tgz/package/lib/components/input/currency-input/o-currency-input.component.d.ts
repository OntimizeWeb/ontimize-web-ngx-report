import { OnInit } from '@angular/core';
import { ORealInputComponent } from '../real-input/o-real-input.component';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_CURRENCY_INPUT: string[];
export declare class OCurrencyInputComponent extends ORealInputComponent implements OnInit {
    static currency_icons: string[];
    currency_symbols: {
        EUR: string;
        USD: string;
        BRL: string;
        JPY: string;
        CNY: string;
        RUB: string;
        AED: string;
        CRC: string;
        NGN: string;
        PHP: string;
        PLN: string;
        PYG: string;
        THB: string;
        UAH: string;
        VND: string;
    };
    currencySymbol: string;
    currencySymbolPosition: string;
    protected existsOntimizeIcon(): boolean;
    useIcon(position: string): boolean;
    useSymbol(position: string): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<OCurrencyInputComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OCurrencyInputComponent, "o-currency-input", never, { "currencySymbol": { "alias": "currency-symbol"; "required": false; }; "currencySymbolPosition": { "alias": "currency-symbol-position"; "required": false; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=o-currency-input.component.d.ts.map