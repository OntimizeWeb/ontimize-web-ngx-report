import { PipeTransform } from '@angular/core';
import * as i0 from "@angular/core";
export declare class OrderByPipe implements PipeTransform {
    static _orderByComparator(a: any, b: any): number;
    transform(input: any, [config]: [string?]): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderByPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<OrderByPipe, "orderBy", true>;
}
//# sourceMappingURL=order-by.pipe.d.ts.map