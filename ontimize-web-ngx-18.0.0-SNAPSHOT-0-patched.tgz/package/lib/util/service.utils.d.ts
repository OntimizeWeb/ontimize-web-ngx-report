import { ActivatedRoute, ActivatedRouteSnapshot } from '@angular/router';
import { OExpandableContainerComponent } from '../components/expandable-container/o-expandable-container.component';
import { OFormComponent } from '../components/form/o-form.component';
import { SQLOrder } from '../types/sql-order.type';
export declare class ServiceUtils {
    static getParentKeysFromExpandableContainer(parentKeysObject: object, expandableContainer: OExpandableContainerComponent, route?: ActivatedRoute, checkRouteParamsRecursive?: boolean): {};
    static getParentKeysFromForm(parentKeysObject: object, form: OFormComponent, route?: ActivatedRoute, checkRouteParamsRecursive?: boolean): {};
    static filterContainsAllParentKeys(parentKeysFilter: any, parentKeys: any): boolean;
    static getFilterUsingParentKeys(parentItem: any, parentKeysObject: object): {};
    static getArrayProperties(array: any[], properties: any[]): any[];
    static getObjectProperties(object: any, properties: any[]): any;
    static parseSortColumns(sortColumns: string): Array<SQLOrder>;
    static getRouteParams(route: ActivatedRouteSnapshot, recursive: boolean): object;
}
//# sourceMappingURL=service.utils.d.ts.map