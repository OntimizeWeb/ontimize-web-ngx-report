import * as i0 from "@angular/core";
import * as i1 from "./o-row.component";
import * as i2 from "@angular/common";
import * as i3 from "../../../shared/shared.module";
export declare class ORowModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ORowModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ORowModule, [typeof i1.ORowComponent], [typeof i2.CommonModule, typeof i3.OSharedModule], [typeof i1.ORowComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ORowModule>;
}
//# sourceMappingURL=o-row.module.d.ts.map