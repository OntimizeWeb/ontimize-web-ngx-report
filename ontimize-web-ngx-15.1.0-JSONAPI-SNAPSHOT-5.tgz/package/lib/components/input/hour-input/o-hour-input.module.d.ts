import * as i0 from "@angular/core";
import * as i1 from "./o-hour-input.component";
import * as i2 from "../../../shared/shared.module";
import * as i3 from "@angular/common";
import * as i4 from "ngx-material-timepicker";
export declare class OHourInputModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OHourInputModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OHourInputModule, [typeof i1.OHourInputComponent], [typeof i2.OSharedModule, typeof i3.CommonModule, typeof i4.NgxMaterialTimepickerModule], [typeof i1.OHourInputComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OHourInputModule>;
}
//# sourceMappingURL=o-hour-input.module.d.ts.map