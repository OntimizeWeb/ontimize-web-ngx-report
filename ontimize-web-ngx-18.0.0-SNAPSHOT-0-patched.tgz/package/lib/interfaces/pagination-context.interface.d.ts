export interface PaginationContext {
    pageSize?: number;
    pageNumber?: number;
    offset?: number;
    totalSize?: number;
}
//# sourceMappingURL=pagination-context.interface.d.ts.map