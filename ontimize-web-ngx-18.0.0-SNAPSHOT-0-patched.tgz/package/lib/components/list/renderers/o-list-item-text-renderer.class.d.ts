import { ElementRef, EventEmitter, Injector, QueryList, Renderer2 } from '@angular/core';
import { MatListItemLine, MatListItemTitle } from '@angular/material/list';
import { OListItemComponent } from '../list-item/o-list-item.component';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_TEXT_RENDERER: string[];
export declare const DEFAULT_OUTPUTS_O_TEXT_RENDERER: string[];
export declare class OListItemTextRenderer {
    elRef: ElementRef;
    protected _renderer: Renderer2;
    protected _injector: Injector;
    protected _listItem: OListItemComponent;
    protected _title: string;
    protected _primaryText: string;
    protected _secondaryText: string;
    protected _icon: string;
    onIconClick: EventEmitter<object>;
    titles: QueryList<MatListItemTitle>;
    lines: QueryList<MatListItemLine>;
    constructor(elRef: ElementRef, _renderer: Renderer2, _injector: Injector, _listItem: OListItemComponent);
    modifyMatListItemElement(): void;
    onActionIconClick(e?: Event): void;
    get title(): string;
    set title(val: string);
    get primaryText(): string;
    set primaryText(val: string);
    get secondaryText(): string;
    set secondaryText(val: string);
    get icon(): string;
    set icon(val: string);
    static ɵfac: i0.ɵɵFactoryDeclaration<OListItemTextRenderer, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OListItemTextRenderer, never, never, { "title": { "alias": "title"; "required": false; }; "primaryText": { "alias": "primary-text"; "required": false; }; "secondaryText": { "alias": "secondary-text"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; }, { "onIconClick": "icon-action"; }, never, never, false, never>;
}
//# sourceMappingURL=o-list-item-text-renderer.class.d.ts.map