export type OntimizeEEPermissionsConfig = {
    service?: string;
};
//# sourceMappingURL=ontimize-ee-permissions-config.type.d.ts.map