import { ElementRef, Injector } from '@angular/core';
import { OFormComponent } from '../../../components/form/o-form.component';
import { OFormDataComponent } from '../../o-form-data-component.class';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_SLIDER_INPUT: string[];
export type SliderDisplayFunction = (value: number) => string;
export declare class OSliderComponent extends OFormDataComponent {
    color: string;
    thumbLabel: boolean;
    showTickMarks: boolean;
    min: number;
    max: number;
    step: number;
    oDisplayWith: SliderDisplayFunction;
    constructor(form: OFormComponent, elRef: ElementRef, injector: Injector);
    onClickBlocker(evt: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OSliderComponent, [{ optional: true; }, null, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OSliderComponent, "o-slider", never, { "color": { "alias": "color"; "required": false; }; "max": { "alias": "max"; "required": false; }; "min": { "alias": "min"; "required": false; }; "step": { "alias": "step"; "required": false; }; "thumbLabel": { "alias": "thumb-label"; "required": false; }; "oDisplayWith": { "alias": "display-with"; "required": false; }; "showTickMarks": { "alias": "show-tick-marks"; "required": false; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=o-slider.component.d.ts.map