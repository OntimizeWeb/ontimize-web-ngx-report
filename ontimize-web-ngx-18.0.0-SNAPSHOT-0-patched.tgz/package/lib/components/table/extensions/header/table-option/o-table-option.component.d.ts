import { ChangeDetectorRef, ElementRef, EventEmitter, Injector } from '@angular/core';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_TABLE_OPTION: string[];
export declare const DEFAULT_OUTPUTS_O_TABLE_OPTION: string[];
export declare class OTableOptionComponent {
    protected injector: Injector;
    elRef: ElementRef;
    static O_TABLE_OPTION_ACTIVE_CLASS: string;
    onClick: EventEmitter<object>;
    oattr: string;
    enabled: boolean;
    icon: string;
    olabel: string;
    showCheckboxOption: boolean;
    active: boolean;
    cd: ChangeDetectorRef;
    constructor(injector: Injector, elRef: ElementRef);
    innerOnClick(): void;
    get activeCheckboxOption(): boolean;
    setActive(val: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableOptionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTableOptionComponent, "o-table-option", never, { "oattr": { "alias": "attr"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "showCheckboxOption": { "alias": "show-checkbox-option"; "required": false; }; "olabel": { "alias": "label"; "required": false; }; "active": { "alias": "active"; "required": false; }; }, { "onClick": "onClick"; }, never, never, true, never>;
}
//# sourceMappingURL=o-table-option.component.d.ts.map