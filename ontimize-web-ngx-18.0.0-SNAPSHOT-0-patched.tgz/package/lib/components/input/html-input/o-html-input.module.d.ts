import * as i0 from "@angular/core";
import * as i1 from "./o-html-input.component";
export declare class OHTMLInputModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OHTMLInputModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OHTMLInputModule, never, [typeof i1.OHTMLInputComponent], [typeof i1.OHTMLInputComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OHTMLInputModule>;
}
//# sourceMappingURL=o-html-input.module.d.ts.map