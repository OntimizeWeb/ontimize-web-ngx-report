export interface BaseResponse {
    data: any;
    message: string;
    isSuccessful(): boolean;
    isFailed(): boolean;
    isUnauthorized(): boolean;
}
//# sourceMappingURL=base-response.interface.d.ts.map