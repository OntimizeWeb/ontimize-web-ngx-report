import { AfterViewInit, ElementRef, Injector, OnInit } from '@angular/core';
import { OFormComponent } from '../../form';
import { OTreeComponent } from '../o-tree.component';
import * as i0 from "@angular/core";
export declare class OTreeNodeComponent extends OTreeComponent implements OnInit, AfterViewInit {
    injector: Injector;
    parentComponent: OTreeComponent;
    parentNode: OTreeNodeComponent;
    constructor(injector: Injector, elementRef: ElementRef, form: OFormComponent, parentComponent: OTreeComponent, parentNode: OTreeNodeComponent);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTreeNodeComponent, [null, null, { optional: true; }, { optional: true; }, { optional: true; skipSelf: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTreeNodeComponent, "o-tree-node", never, {}, {}, never, never, true, never>;
}
//# sourceMappingURL=tree-node.component.d.ts.map