import { OServiceBasePermissions } from './o-service-base-permissions.type';
export type OListPermissions = OServiceBasePermissions;
//# sourceMappingURL=o-list-permissions.type.d.ts.map