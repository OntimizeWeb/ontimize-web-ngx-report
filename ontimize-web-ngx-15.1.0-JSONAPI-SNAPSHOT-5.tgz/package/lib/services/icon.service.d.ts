import { Injector } from '@angular/core';
import { SafeHtml } from '@angular/platform-browser';
import { OSafePipe } from '../pipes/o-safe.pipe';
import * as i0 from "@angular/core";
export declare class IconService {
    protected injector: Injector;
    static DEFAULT_ICON_POSITION: string;
    protected _iconPosition: string;
    protected oSafePipe: OSafePipe;
    constructor(injector: Injector);
    get iconPosition(): string;
    set iconPosition(value: string);
    getIconValue(value: any, args: any): SafeHtml;
    static ɵfac: i0.ɵɵFactoryDeclaration<IconService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<IconService>;
}
//# sourceMappingURL=icon.service.d.ts.map