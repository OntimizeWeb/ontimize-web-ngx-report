import * as i0 from "@angular/core";
import * as i1 from "./o-textarea-input.component";
export declare class OTextareaInputModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OTextareaInputModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OTextareaInputModule, never, [typeof i1.OTextareaInputComponent], [typeof i1.OTextareaInputComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OTextareaInputModule>;
}
//# sourceMappingURL=o-textarea-input.module.d.ts.map