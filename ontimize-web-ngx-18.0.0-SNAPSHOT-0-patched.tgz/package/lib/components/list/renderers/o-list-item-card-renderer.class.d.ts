import { ElementRef, EventEmitter, Injector, Renderer2 } from '@angular/core';
import { OListItemComponent } from '../list-item/o-list-item.component';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_CARD_RENDERER: string[];
export declare const DEFAULT_OUTPUTS_O_CARD_RENDERER: string[];
export declare class OListItemCardRenderer {
    elRef: ElementRef;
    protected _renderer: Renderer2;
    protected _injector: Injector;
    protected _listItem: OListItemComponent;
    protected _title: string;
    protected _subtitle: string;
    protected _image: string;
    protected _showImage: boolean;
    protected _action1Text: string;
    protected _action2Text: string;
    onAction1Click: EventEmitter<object>;
    onAction2Click: EventEmitter<object>;
    constructor(elRef: ElementRef, _renderer: Renderer2, _injector: Injector, _listItem: OListItemComponent);
    modifyMatListItemElement(): void;
    onAction1ButtonClick(e?: Event): void;
    onAction2ButtonClick(e?: Event): void;
    compareListHeight(height: string): true;
    get title(): string;
    set title(val: string);
    get subtitle(): string;
    set subtitle(val: string);
    get image(): string;
    set image(val: string);
    get showImage(): boolean;
    set showImage(val: boolean);
    get action1Text(): string;
    set action1Text(val: string);
    get action2Text(): string;
    set action2Text(val: string);
    static ɵfac: i0.ɵɵFactoryDeclaration<OListItemCardRenderer, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OListItemCardRenderer, never, never, { "title": { "alias": "title"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "image": { "alias": "image"; "required": false; }; "showImage": { "alias": "show-image"; "required": false; }; "action1Text": { "alias": "action-1-text"; "required": false; }; "action2Text": { "alias": "action-2-text"; "required": false; }; }, { "onAction1Click": "action-1"; "onAction2Click": "action-2"; }, never, never, false, never>;
}
//# sourceMappingURL=o-list-item-card-renderer.class.d.ts.map