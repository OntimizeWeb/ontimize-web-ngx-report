import { ChangeDetectorRef, Injector, ModuleWithProviders, OnDestroy, PipeTransform } from '@angular/core';
import { OTranslateService } from '../services/translate/o-translate.service';
import * as i0 from "@angular/core";
export interface ITranslatePipeArgument {
    values?: any[];
}
export declare class OTranslatePipe implements PipeTransform, OnDestroy {
    protected injector: Injector;
    value: string;
    lastKey: string;
    lastParams: any;
    onLanguageChanged: any;
    protected oTranslateService: OTranslateService;
    protected _ref: ChangeDetectorRef;
    constructor(injector: Injector);
    ngOnDestroy(): void;
    transform(text: string, args?: ITranslatePipeArgument): string;
    updateValue(key: string): void;
    protected _dispose(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTranslatePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<OTranslatePipe, "oTranslate", false>;
}
export declare class OTranslateModule {
    static forRoot(): ModuleWithProviders<OTranslateModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTranslateModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OTranslateModule, [typeof OTranslatePipe], never, [typeof OTranslatePipe]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OTranslateModule>;
}
//# sourceMappingURL=o-translate.pipe.d.ts.map