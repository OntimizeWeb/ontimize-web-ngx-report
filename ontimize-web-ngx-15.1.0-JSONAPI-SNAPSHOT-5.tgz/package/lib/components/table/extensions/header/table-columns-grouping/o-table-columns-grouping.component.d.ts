import { Injector, OnInit, QueryList } from '@angular/core';
import { OTableColumnsGrouping } from '../../../../../interfaces/o-table-columns-grouping-interface';
import { OTableComponent } from '../../../o-table.component';
import { OTableColumnsGroupingColumnComponent } from './columns/o-table-columns-grouping-column.component';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_TABLE_COLUMN_GROUPING: string[];
export declare const DEFAULT_OUTPUTS_O_TABLE_COLUMN_GROUPING: any[];
export declare class OTableColumnsGroupingComponent implements OTableColumnsGrouping, OnInit {
    protected injector: Injector;
    protected table: OTableComponent;
    protected _columnsArray: string[];
    protected _excludedAggregateColumnsArray: string[];
    groupingColumns: QueryList<OTableColumnsGroupingColumnComponent>;
    constructor(injector: Injector, table: OTableComponent);
    set columns(arg: string);
    get columnsArray(): string[];
    set excludedAggregateColumns(arg: string);
    ngOnInit(): void;
    useColumnAggregate(columnAttr: string, hasDefaultAggregate: boolean): boolean;
    getColumnGrouping(columnAttr: any): OTableColumnsGroupingColumnComponent;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableColumnsGroupingComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTableColumnsGroupingComponent, "o-table-columns-grouping", never, { "columns": "columns"; "excludedAggregateColumns": "excluded-aggregate-columns"; }, {}, ["groupingColumns"], never, false, never>;
}
//# sourceMappingURL=o-table-columns-grouping.component.d.ts.map