import { ElementRef, Injector, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { AuthService } from '../../services/auth.service';
import { DialogService } from '../../services/dialog.service';
import { OUserInfoService, UserInfo } from '../../services/o-user-info.service';
import { OUserInfoConfigurationDirective } from './user-info-configuration/o-user-info-configuration.directive';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_USER_INFO: string[];
export declare const DEFAULT_OUTPUTS_O_USER_INFO: any[];
export declare class OUserInfoComponent implements OnDestroy {
    protected elRef: ElementRef;
    protected injector: Injector;
    protected router: Router;
    protected dialogService: DialogService;
    protected authService: AuthService;
    protected oUserInfoService: OUserInfoService;
    userInfoSubscription: Subscription;
    protected userInfo: UserInfo;
    showLogout: boolean;
    showSettings: boolean;
    showProfile: boolean;
    id: string;
    userInfoConfiguration: OUserInfoConfigurationDirective;
    constructor(elRef: ElementRef, injector: Injector, router: Router);
    ngOnDestroy(): void;
    onLogoutClick(): void;
    onSettingsClick(): void;
    onProfileClick(): void;
    get existsUserInfo(): boolean;
    get avatar(): string;
    get username(): string;
    registerUserInfoConfiguration(userInfoMenu: OUserInfoConfigurationDirective): void;
    private updateInputsByConfiguration;
    static ɵfac: i0.ɵɵFactoryDeclaration<OUserInfoComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OUserInfoComponent, "o-user-info", never, { "showProfile": { "alias": "show-profile"; "required": false; }; "showSettings": { "alias": "show-settings"; "required": false; }; "showLogout": { "alias": "show-logout"; "required": false; }; "id": { "alias": "id"; "required": false; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=o-user-info.component.d.ts.map