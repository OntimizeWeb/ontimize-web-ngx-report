import { OTreeComponent } from '../../components/tree/o-tree.component';
import { AbstractComponentStateService } from './o-component-state.service';
import { OTreeComponentStateClass } from './o-tree-component-state.class';
import * as i0 from "@angular/core";
export declare class OTreeComponentStateService extends AbstractComponentStateService<OTreeComponentStateClass, OTreeComponent> {
    initialize(component: OTreeComponent): void;
    initializeState(state: OTreeComponentStateClass): void;
    getDataToStore(): any;
    protected getTreePropertiesToStore(properties: string[]): any;
    protected getTreePropertyToStore(property: string): any;
    getQuickFilterState(): any;
    protected getPageState(): any;
    protected getSelectionState(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTreeComponentStateService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OTreeComponentStateService>;
}
//# sourceMappingURL=o-tree-component-state.service.d.ts.map