import { CollectionViewer, DataSource, SelectionChange } from '@angular/cdk/collections';
import { FlatTreeControl } from '@angular/cdk/tree';
import { Injector } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { OTreeDao } from './o-tree-dao.service';
import { OTreeComponent } from './o-tree.component';
import { OTreeFlatNode } from '../../types/tree-flat-node.type';
import { MatPaginator } from '@angular/material/paginator';
export declare class OTreeDataSource implements DataSource<OTreeFlatNode> {
    private oTree;
    private _treeControl;
    private injector;
    dataChange: BehaviorSubject<OTreeFlatNode[]>;
    translateService: any;
    protected _database: OTreeDao;
    resultsLength: number;
    protected _paginator: MatPaginator;
    get data(): OTreeFlatNode[];
    set data(value: OTreeFlatNode[]);
    constructor(oTree: OTreeComponent, _treeControl: FlatTreeControl<OTreeFlatNode>, injector: Injector);
    connect(collectionViewer: CollectionViewer): Observable<OTreeFlatNode[]>;
    disconnect(collectionViewer: CollectionViewer): void;
    handleTreeControl(change: SelectionChange<OTreeFlatNode>): void;
    isTreeFlatNode(value: any): boolean;
    updateTree(parentNode: OTreeFlatNode, children: Array<any>, expand: boolean): void;
}
//# sourceMappingURL=o-tree.datasource.d.ts.map