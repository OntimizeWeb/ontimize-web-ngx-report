import { HttpClient } from '@angular/common/http';
import { EventEmitter, Injector } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { Observable, Subscriber } from 'rxjs';
import { AppConfig } from '../../config/app-config';
import { MomentService } from '../../services/moment.service';
import * as i0 from "@angular/core";
export declare function translateServiceFactory(injector: Injector): any;
export declare class OTranslateService {
    protected injector: Injector;
    static ASSETS_PATH: string;
    static ASSETS_EXTENSION: string;
    DEFAULT_LANG: string;
    onLanguageChanged: EventEmitter<any>;
    protected ngxTranslateService: TranslateService;
    protected momentService: MomentService;
    protected httpClient: HttpClient;
    protected localStorageKey: string;
    protected notFoundLang: Array<string>;
    protected appConfig: AppConfig;
    protected existingLangFiles: Array<string>;
    protected defaultLocale: string;
    constructor(injector: Injector);
    storeLanguage(language: string): void;
    getStoredLanguage(): string;
    protected checkExistingLangFile(lang: string): Promise<any>;
    setDefaultLang(lang: string): void;
    get(text: string, values?: any[]): string;
    setAppLang(lang: string): Observable<any>;
    use(lang: string, observer?: Subscriber<any>): void;
    protected propagateLang(lang: string, langRes?: any, observer?: Subscriber<any>): void;
    getNgxTranslateService(): TranslateService;
    getCurrentLang(): string;
    getBrowserLang(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTranslateService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OTranslateService>;
}
//# sourceMappingURL=o-translate.service.d.ts.map