import * as i0 from "@angular/core";
import * as i1 from "./tree-node/tree-node.component";
import * as i2 from "./o-tree.component";
import * as i3 from "./header/tree-menu/o-tree-menu.component";
export declare class OTreeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OTreeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OTreeModule, never, [typeof i1.OTreeNodeComponent, typeof i2.OTreeComponent, typeof i3.OTreeMenuComponent], [typeof i2.OTreeComponent, typeof i1.OTreeNodeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OTreeModule>;
}
//# sourceMappingURL=o-tree.module.d.ts.map