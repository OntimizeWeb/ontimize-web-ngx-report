import { CdkVirtualScrollViewport, VirtualScrollStrategy } from "@angular/cdk/scrolling";
import { Observable, Subject } from "rxjs";
import * as i0 from "@angular/core";
export declare class OTableVirtualScrollStrategy implements VirtualScrollStrategy {
    private viewport;
    private rowHeight;
    private headerHeight;
    private footerHeight;
    private readonly indexChange;
    scrolledIndexChange: Observable<number>;
    readonly stickyChange: Subject<number>;
    private bufferMultiplier;
    get dataLength(): number;
    set dataLength(value: number);
    private _dataLength;
    attach(viewport: CdkVirtualScrollViewport): void;
    detach(): void;
    destroy(): void;
    onContentRendered(): void;
    onRenderedOffsetChanged(): void;
    scrollToIndex(index: number, behavior?: ScrollBehavior): void;
    onContentScrolled(): void;
    setConfig(rowHeight: number, headerHeight: number, footerHeight: number): void;
    onDataLengthChanged(): void;
    private updateContent;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableVirtualScrollStrategy, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OTableVirtualScrollStrategy>;
}
//# sourceMappingURL=o-table-strategy.service.d.ts.map