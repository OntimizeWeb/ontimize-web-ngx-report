import { EventEmitter, OnInit } from '@angular/core';
import * as i0 from "@angular/core";
export declare class OKeyboardListenerDirective implements OnInit {
    keyboardKeys: string;
    onKeysPressed: EventEmitter<object>;
    protected keyboardNumberKeysArray: Array<number>;
    protected activeKeys: object;
    keyDown(e: KeyboardEvent): void;
    keyUp(e: KeyboardEvent): void;
    ngOnInit(): void;
    parseKeyboardKeys(): void;
    checkNeededKeys(e: KeyboardEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OKeyboardListenerDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OKeyboardListenerDirective, "[oKeyboardListener]", never, { "keyboardKeys": "keyboardKeys"; }, { "onKeysPressed": "onKeysPressed"; }, never, never, false, never>;
}
//# sourceMappingURL=keyboard-listener.directive.d.ts.map