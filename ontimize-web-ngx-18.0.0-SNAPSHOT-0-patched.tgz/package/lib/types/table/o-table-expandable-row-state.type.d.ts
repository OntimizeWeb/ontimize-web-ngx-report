export type OTableExpandableRowState = {
    keys: {
        [k: string]: any;
    };
};
//# sourceMappingURL=o-table-expandable-row-state.type.d.ts.map