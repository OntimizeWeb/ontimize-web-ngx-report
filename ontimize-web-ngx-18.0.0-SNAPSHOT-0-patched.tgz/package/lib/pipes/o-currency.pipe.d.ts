import { Injector, PipeTransform } from '@angular/core';
import { CurrencyService } from '../services/currency.service';
import { ORealPipe } from './o-real.pipe';
import * as i0 from "@angular/core";
export interface ICurrencyPipeArgument {
    currencySimbol?: string;
    currencySymbolPosition?: string;
    grouping?: boolean;
    thousandSeparator?: string;
    decimalSeparator?: string;
    minDecimalDigits?: number;
    maxDecimalDigits?: number;
}
export declare class OCurrencyPipe extends ORealPipe implements PipeTransform {
    protected injector: Injector;
    protected currencyService: CurrencyService;
    constructor(injector: Injector);
    transform(text: string, args: ICurrencyPipeArgument): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<OCurrencyPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<OCurrencyPipe, "oCurrency", true>;
}
//# sourceMappingURL=o-currency.pipe.d.ts.map