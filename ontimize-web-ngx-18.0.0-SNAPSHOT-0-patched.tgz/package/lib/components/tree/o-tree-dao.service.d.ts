import { BehaviorSubject, Observable } from 'rxjs';
import { OTreeFlatNode } from '../../types/tree-flat-node.type';
import { ServiceResponse } from '../../interfaces/service-response.interface';
import * as i0 from "@angular/core";
export declare class OTreeDao {
    protected _isLoadingResults: boolean;
    protected loadingTimer: any;
    dataChange: BehaviorSubject<any[]>;
    sqlTypesChange: BehaviorSubject<object>;
    get data(): any[];
    rootLevelNodes: OTreeFlatNode[];
    flatNodeMap: Map<OTreeFlatNode, any>;
    setDataArray(data: Array<any>): Observable<any[]>;
    get isLoadingResults(): boolean;
    set isLoadingResults(val: boolean);
    protected cleanTimer(): void;
    queryNodeChildren(flatNode: OTreeFlatNode, recursive: boolean): Observable<ServiceResponse>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTreeDao, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OTreeDao>;
}
//# sourceMappingURL=o-tree-dao.service.d.ts.map