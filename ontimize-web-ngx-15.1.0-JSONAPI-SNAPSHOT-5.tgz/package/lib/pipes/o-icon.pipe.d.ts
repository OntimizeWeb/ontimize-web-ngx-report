import { Injector, PipeTransform } from '@angular/core';
import { IconService } from '../services/icon.service';
import * as i0 from "@angular/core";
export interface IIconPipeArgument {
    iconPosition?: string;
    icon: string;
}
export declare class OIconPipe implements PipeTransform {
    protected injector: Injector;
    protected iconService: IconService;
    constructor(injector: Injector);
    transform(text: any, args: IIconPipeArgument): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<OIconPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<OIconPipe, "oIcon", false>;
}
//# sourceMappingURL=o-icon.pipe.d.ts.map