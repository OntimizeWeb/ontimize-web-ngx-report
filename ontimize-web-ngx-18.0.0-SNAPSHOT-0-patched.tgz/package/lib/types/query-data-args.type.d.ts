export type OQueryDataArgs = {
    replace?: boolean;
    sqltypes?: object;
    offset?: number;
    length?: number;
};
//# sourceMappingURL=query-data-args.type.d.ts.map