import { SessionInfo } from "./session-info.type";
export type ServiceConfig = {
    [key: string]: {
        path: string;
        serviceType?: string;
        urlBase?: string;
        session?: SessionInfo;
        exportPath?: string;
        downloadPath?: string;
    };
};
export type OntimizeServiceConfig = ServiceConfig & {
    fileManagerPath?: string;
};
export type JSONAPIServiceConfig = ServiceConfig & {
    delimiter?: string;
};
//# sourceMappingURL=service-configuration.type.d.ts.map