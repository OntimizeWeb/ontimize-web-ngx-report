import { DialogPosition } from '@angular/material/dialog';
import { OFormLayoutManagerComponent } from '../../o-form-layout-manager.component';
import * as i0 from "@angular/core";
export declare class OFormLayoutDialogOptionsDirective {
    protected formLayoutManager: OFormLayoutManagerComponent;
    constructor(formLayoutManager: OFormLayoutManagerComponent);
    ngOnChanges(): void;
    width: string;
    minWidth: number | string;
    maxWidth: number | string;
    height: string;
    minHeight: number | string;
    maxHeight: number | string;
    class: string | string[];
    position: DialogPosition;
    backdropClass: string;
    protected _closeOnNavigation: boolean;
    set closeOnNavigation(value: boolean);
    protected _disableClose: boolean;
    set disableClose(value: boolean);
    title: string;
    labelColumns: string;
    separator: string;
    dialogTitleSeparator: any;
    protected _showFullscreenButton: boolean;
    set showFullscreenButton(value: boolean);
    getOptions(): {
        width: string;
        minWidth: string | number;
        maxWidth: string | number;
        height: string;
        minHeight: string | number;
        maxHeight: string | number;
        class: string | string[];
        position: DialogPosition;
        backdropClass: string;
        disableClose: boolean;
        closeOnNavigation: boolean;
        title: string;
        labelColumns: string;
        separator: string;
        dialogTitleSeparator: any;
        showFullscreenButton: boolean;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<OFormLayoutDialogOptionsDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OFormLayoutDialogOptionsDirective, "o-form-layout-dialog-options, o-form-layout-manager[mode=\"dialog\"]", never, { "width": { "alias": "width"; "required": false; }; "minWidth": { "alias": "min-width"; "required": false; }; "maxWidth": { "alias": "max-width"; "required": false; }; "height": { "alias": "height"; "required": false; }; "minHeight": { "alias": "min-height"; "required": false; }; "maxHeight": { "alias": "max-height"; "required": false; }; "class": { "alias": "class"; "required": false; }; "position": { "alias": "position"; "required": false; }; "backdropClass": { "alias": "backdrop-class"; "required": false; }; "closeOnNavigation": { "alias": "close-on-navigation"; "required": false; }; "disableClose": { "alias": "disable-close"; "required": false; }; "title": { "alias": "title"; "required": false; }; "labelColumns": { "alias": "label-columns"; "required": false; }; "separator": { "alias": "separator"; "required": false; }; "dialogTitleSeparator": { "alias": "dialog-title-separator"; "required": false; }; "showFullscreenButton": { "alias": "show-fullscreen-button"; "required": false; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=o-form-layout-dialog-options.directive.d.ts.map