import { Observable } from "rxjs";
import { ServiceResponse } from "../../interfaces/service-response.interface";
export declare class BaseQueryArgument {
    request(method: string, service: any, queryArguments: any): Observable<ServiceResponse>;
    parseQueryParameters(args: any): any;
}
//# sourceMappingURL=base-query-argument.adapter.d.ts.map