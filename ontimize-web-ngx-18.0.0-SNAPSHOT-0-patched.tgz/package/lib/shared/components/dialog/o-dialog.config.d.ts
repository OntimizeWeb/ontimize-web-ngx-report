export type AlertType = 'info' | 'warn' | 'error';
export declare class ODialogConfig {
    alertType?: AlertType;
    okButtonText?: string;
    cancelButtonText?: string;
    icon?: string;
}
//# sourceMappingURL=o-dialog.config.d.ts.map