import { EventEmitter, Injector, OnInit, TemplateRef } from '@angular/core';
import { OBaseTableCellRenderer } from '../o-base-table-cell-renderer.class';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_TABLE_CELL_RENDERER_ACTION: string[];
export declare const DEFAULT_OUTPUTS_O_TABLE_CELL_RENDERER_ACTION: string[];
export declare class OTableCellRendererActionComponent extends OBaseTableCellRenderer implements OnInit {
    protected injector: Injector;
    onClick: EventEmitter<object>;
    action: string;
    _icon: string;
    text: string;
    iconPosition: string;
    svgIcon: string;
    templateref: TemplateRef<any>;
    constructor(injector: Injector);
    initialize(): void;
    getCellData(value: any): any;
    innerOnClick(event: any, rowData: any): void;
    get icon(): string;
    set icon(arg: string);
    isIconPositionLeft(): boolean;
    isIconPositionRight(): boolean;
    isSvgIconPositionRight(): boolean;
    isSvgIconPositionLeft(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableCellRendererActionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTableCellRendererActionComponent, "o-table-cell-renderer-action", never, { "icon": { "alias": "icon"; "required": false; }; "svgIcon": { "alias": "svg-icon"; "required": false; }; "action": { "alias": "action"; "required": false; }; "text": { "alias": "text"; "required": false; }; "iconPosition": { "alias": "icon-position"; "required": false; }; }, { "onClick": "onClick"; }, never, never, true, never>;
}
//# sourceMappingURL=o-table-cell-renderer-action.component.d.ts.map