import { EventEmitter, Injector, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { MatSelectionList } from '@angular/material/list';
import { DialogService } from '../../../../../services/dialog.service';
import { OTableConfiguration } from '../../../../../types/table/o-table-configuration.type';
import * as i0 from "@angular/core";
export declare class OTableApplyConfigurationDialogComponent implements OnInit {
    dialogRef: MatDialogRef<OTableApplyConfigurationDialogComponent>;
    protected injector: Injector;
    default_configuration: string;
    configurations: OTableConfiguration[];
    onDelete: EventEmitter<string>;
    protected configurationList: MatSelectionList;
    protected dialogService: DialogService;
    constructor(dialogRef: MatDialogRef<OTableApplyConfigurationDialogComponent>, data: OTableConfiguration[], injector: Injector);
    ngOnInit(): void;
    loadConfigurations(configurations: OTableConfiguration[]): void;
    removeConfiguration(configurationName: string): void;
    isDefaultConfigurationSelected(): boolean;
    getSelectedConfigurationName(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableApplyConfigurationDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTableApplyConfigurationDialogComponent, "o-table-apply-configuration-dialog", never, {}, {}, never, never, true, never>;
}
//# sourceMappingURL=o-table-apply-configuration-dialog.component.d.ts.map