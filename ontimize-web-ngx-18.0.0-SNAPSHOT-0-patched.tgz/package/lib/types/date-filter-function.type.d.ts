export type DateFilterFunction = (date: Date) => boolean;
//# sourceMappingURL=date-filter-function.type.d.ts.map