export type OntimizePermissionsConfig = {
    entity: string;
    keyColumn: string;
    valueColumn: string;
};
//# sourceMappingURL=ontimize-permissions-config.type.d.ts.map