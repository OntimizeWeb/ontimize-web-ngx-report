import * as i0 from "@angular/core";
import * as i1 from "./o-app-layout.component";
import * as i2 from "./app-layout-header/o-app-layout-header.component";
import * as i3 from "./app-layout-sidenav/o-app-layout-sidenav.component";
import * as i4 from "@angular/common";
import * as i5 from "../../shared/shared.module";
import * as i6 from "@angular/router";
import * as i7 from "../../components/app-sidenav/o-app-sidenav.module";
import * as i8 from "../../components/app-header/o-app-header.module";
export declare class OAppLayoutModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OAppLayoutModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OAppLayoutModule, [typeof i1.OAppLayoutComponent, typeof i2.OAppLayoutHeaderComponent, typeof i3.OAppLayoutSidenavComponent], [typeof i4.CommonModule, typeof i5.OSharedModule, typeof i6.RouterModule, typeof i7.OAppSidenavModule, typeof i8.OAppHeaderModule], [typeof i1.OAppLayoutComponent, typeof i2.OAppLayoutHeaderComponent, typeof i3.OAppLayoutSidenavComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OAppLayoutModule>;
}
//# sourceMappingURL=o-app-layout.module.d.ts.map