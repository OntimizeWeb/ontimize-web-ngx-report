export interface PaginationData {
    pageNumber?: number;
    pageSize?: number;
    startRecordIndex?: number;
    totalQueryRecordsNumber?: number;
}
//# sourceMappingURL=pagination-data.interface.d.ts.map