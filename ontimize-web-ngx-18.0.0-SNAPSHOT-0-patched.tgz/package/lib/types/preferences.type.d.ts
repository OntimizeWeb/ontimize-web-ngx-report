export type OPreference = {
    PREFERENCEID?: number;
    PREFERENCEENTITY: string;
    PREFERENCEDESCRIPTION?: string;
    PREFERENCENAME?: string;
    PREFERENCEPREFERENCES?: string;
};
//# sourceMappingURL=preferences.type.d.ts.map