export declare class OTableExportConfiguration {
    service: string;
    columns: [];
    serviceType: string;
    visibleButtons: string;
    options?: any;
}
//# sourceMappingURL=o-table-export-configuration.class.d.ts.map