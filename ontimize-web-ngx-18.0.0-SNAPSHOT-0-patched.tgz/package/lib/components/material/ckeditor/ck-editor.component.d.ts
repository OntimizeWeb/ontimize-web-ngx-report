import { AfterViewInit, ElementRef, EventEmitter, NgZone, OnDestroy } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import * as i0 from "@angular/core";
export declare class CKEditorComponent implements AfterViewInit, OnDestroy, ControlValueAccessor {
    protected ngZone: NgZone;
    protected ckIns: any;
    protected identifier: string;
    protected innerValue: string;
    get instance(): any;
    protected _readonly: boolean;
    set readonly(value: boolean);
    get readonly(): boolean;
    config: any;
    skin: string;
    language: string;
    fullPage: boolean;
    inline: boolean;
    id: string;
    change: EventEmitter<any>;
    ready: EventEmitter<any>;
    blur: EventEmitter<any>;
    focus: EventEmitter<any>;
    ck: ElementRef;
    constructor(ngZone: NgZone);
    protected static getRandomIdentifier(id?: string): string;
    ngOnDestroy(): void;
    ngAfterViewInit(): void;
    initCKEditor(identifier: string): void;
    destroyCKEditor(): void;
    protected updateValue(value: string): void;
    writeValue(value: any): void;
    protected propagateChange(_: any): void;
    protected propagateTouch(): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CKEditorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CKEditorComponent, "ck-editor", ["ckEditor"], { "readonly": { "alias": "readonly"; "required": false; }; "config": { "alias": "config"; "required": false; }; "skin": { "alias": "skin"; "required": false; }; "language": { "alias": "language"; "required": false; }; "fullPage": { "alias": "fullPage"; "required": false; }; "inline": { "alias": "inline"; "required": false; }; "id": { "alias": "id"; "required": false; }; }, { "change": "change"; "ready": "ready"; "blur": "blur"; "focus": "focus"; }, never, never, true, never>;
}
//# sourceMappingURL=ck-editor.component.d.ts.map