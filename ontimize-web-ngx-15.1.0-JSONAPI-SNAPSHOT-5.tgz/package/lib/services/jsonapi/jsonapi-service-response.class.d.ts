import { HttpHeaders } from "@angular/common/http";
import { ServiceResponse } from "../../interfaces/service-response.interface";
export declare class JSONAPIServiceResponse implements ServiceResponse {
    status: number;
    statusText: string;
    headers: HttpHeaders;
    ok: boolean;
    body: any;
    context: any;
    code: number;
    message: string;
    sqlTypes: {
        [key: string]: number;
    };
    startRecordIndex: number;
    totalQueryRecordsNumber: number;
    data: any;
    constructor(status: number, statusText: string, headers: HttpHeaders, ok: boolean, body: any, context: any);
    isSuccessful(): boolean;
    isFailed(): boolean;
    isUnauthorized(): boolean;
}
//# sourceMappingURL=jsonapi-service-response.class.d.ts.map