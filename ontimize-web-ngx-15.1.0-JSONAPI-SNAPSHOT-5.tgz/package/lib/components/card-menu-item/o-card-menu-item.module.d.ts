import * as i0 from "@angular/core";
import * as i1 from "./o-card-menu-item.component";
import * as i2 from "@angular/common";
import * as i3 from "../../shared/shared.module";
export declare class OCardMenuItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OCardMenuItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OCardMenuItemModule, [typeof i1.OCardMenuItemComponent], [typeof i2.CommonModule, typeof i3.OSharedModule], [typeof i1.OCardMenuItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OCardMenuItemModule>;
}
//# sourceMappingURL=o-card-menu-item.module.d.ts.map