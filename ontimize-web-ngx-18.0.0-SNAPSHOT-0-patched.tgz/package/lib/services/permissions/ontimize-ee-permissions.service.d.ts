import { HttpHeaders } from '@angular/common/http';
import { Injector } from '@angular/core';
import { Observable } from 'rxjs';
import { IPermissionsService } from '../../interfaces/permissions-service.interface';
import { OntimizeEEPermissionsConfig } from '../../types/ontimize-ee-permissions-config.type';
import { OntimizeBasePermissionsService } from './ontimize-base-permissions-service.class';
import * as i0 from "@angular/core";
export declare class OntimizeEEPermissionsService extends OntimizeBasePermissionsService implements IPermissionsService {
    protected injector: Injector;
    static DEFAULT_PERMISSIONS_PATH: string;
    static PERMISSIONS_KEY: string;
    path: string;
    protected _user: string;
    protected _urlBase: string;
    constructor(injector: Injector);
    getDefaultServiceConfiguration(permissionsConfig: OntimizeEEPermissionsConfig): any;
    configureService(permissionsConfig: OntimizeEEPermissionsConfig): void;
    loadPermissions(): Observable<any>;
    protected buildHeaders(): HttpHeaders;
    static ɵfac: i0.ɵɵFactoryDeclaration<OntimizeEEPermissionsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OntimizeEEPermissionsService>;
}
//# sourceMappingURL=ontimize-ee-permissions.service.d.ts.map