import { Injector } from "@angular/core";
import { OTableBase } from "../components/table/o-table-base.class";
import * as i0 from "@angular/core";
export declare class OntimizeExportDataBaseProviderService {
    protected injector: Injector;
    table: OTableBase;
    columns: any;
    colsNotIncluded: string[];
    columnNames: any;
    sqlTypes: any;
    entity: string;
    service: string;
    filter: any;
    constructor(injector: Injector);
    initializeProvider(table: OTableBase): void;
    protected getFilterWithBasicExpression(): any;
    private applyParentItemExpression;
    private applyColumnFilters;
    private applyQuickAndBuilderFilters;
    static ɵfac: i0.ɵɵFactoryDeclaration<OntimizeExportDataBaseProviderService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OntimizeExportDataBaseProviderService>;
}
//# sourceMappingURL=ontimize-export-data-base-provider.service.d.ts.map