import * as i0 from "@angular/core";
import * as i1 from "./o-grid.component";
import * as i2 from "./grid-item/o-grid-item.directive";
import * as i3 from "./grid-item/o-grid-item.component";
import * as i4 from "./skeketon/o-grid-skeleton.component";
import * as i5 from "@angular/common";
import * as i6 from "../input/search-input/o-search-input.module";
import * as i7 from "../../shared/shared.module";
import * as i8 from "@angular/router";
import * as i9 from "../o-data-toolbar/o-data-toolbar.module";
import * as i10 from "ngx-skeleton-loader";
export declare class OGridModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OGridModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OGridModule, [typeof i1.OGridComponent, typeof i2.OGridItemDirective, typeof i3.OGridItemComponent, typeof i4.OGridSkeletonComponent], [typeof i5.CommonModule, typeof i6.OSearchInputModule, typeof i7.OSharedModule, typeof i8.RouterModule, typeof i9.ODataToolbarModule, typeof i10.NgxSkeletonLoaderModule], [typeof i1.OGridComponent, typeof i3.OGridItemComponent, typeof i2.OGridItemDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OGridModule>;
}
//# sourceMappingURL=o-grid.module.d.ts.map