import { HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { IServiceResponseAdapter } from '../../interfaces/service-response-adapter.interface';
import { OntimizeServiceResponse } from './ontimize-service-response.class';
import * as i0 from "@angular/core";
export declare class OntimizeServiceResponseAdapter implements IServiceResponseAdapter<OntimizeServiceResponse> {
    context: any;
    adapt(res: HttpResponse<any>): OntimizeServiceResponse;
    adaptError(error: HttpErrorResponse): HttpErrorResponse;
    static ɵfac: i0.ɵɵFactoryDeclaration<OntimizeServiceResponseAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OntimizeServiceResponseAdapter>;
}
//# sourceMappingURL=ontimize-service-response.adapter.d.ts.map