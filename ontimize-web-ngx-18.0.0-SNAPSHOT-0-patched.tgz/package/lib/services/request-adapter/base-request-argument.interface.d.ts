export interface IBaseRequestArgument {
    parseQueryParameters(params: any): any;
}
//# sourceMappingURL=base-request-argument.interface.d.ts.map