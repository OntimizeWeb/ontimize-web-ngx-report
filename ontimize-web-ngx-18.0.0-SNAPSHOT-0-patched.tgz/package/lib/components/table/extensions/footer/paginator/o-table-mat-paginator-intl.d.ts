import { Injector } from '@angular/core';
import { MatPaginatorIntl } from '@angular/material/paginator';
import { OTranslateService } from '../../../../../services/translate/o-translate.service';
import * as i0 from "@angular/core";
export declare class OTableMatPaginatorIntl extends MatPaginatorIntl {
    protected injector: Injector;
    itemsPerPageLabel: any;
    nextPageLabel: any;
    previousPageLabel: any;
    translateService: OTranslateService;
    protected onLanguageChangeSubscribe: any;
    constructor(injector: Injector);
    getORangeLabel(page: number, pageSize: number, length: number): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableMatPaginatorIntl, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OTableMatPaginatorIntl>;
}
//# sourceMappingURL=o-table-mat-paginator-intl.d.ts.map