import * as i0 from "@angular/core";
export declare class OFileDragAndDropDirective {
    private onFileDropped;
    fileDragging: boolean;
    onDragOver(evt: any): void;
    onDragLeave(evt: any): void;
    onDrop(evt: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OFileDragAndDropDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OFileDragAndDropDirective, "[oFileDragAndDrop]", never, {}, { "onFileDropped": "onFileDropped"; }, never, never, true, never>;
}
//# sourceMappingURL=o-file-drag-and-drop.directive.d.ts.map