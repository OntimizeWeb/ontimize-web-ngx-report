import { ElementRef, Injector } from '@angular/core';
import { ThemePalette } from '@angular/material/core';
import { OFormComponent } from '../../form/o-form.component';
import { OBooleanFormDataComponent } from '../o-boolean-form-data-component.class';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_CHECKBOX: string[];
export declare class OCheckboxComponent extends OBooleanFormDataComponent {
    color: ThemePalette;
    labelPosition: 'before' | 'after';
    constructor(form: OFormComponent, elRef: ElementRef, injector: Injector);
    initialize(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OCheckboxComponent, [{ optional: true; }, null, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OCheckboxComponent, "o-checkbox", never, { "color": "color"; "labelPosition": "label-position"; }, {}, never, never, false, never>;
}
//# sourceMappingURL=o-checkbox.component.d.ts.map