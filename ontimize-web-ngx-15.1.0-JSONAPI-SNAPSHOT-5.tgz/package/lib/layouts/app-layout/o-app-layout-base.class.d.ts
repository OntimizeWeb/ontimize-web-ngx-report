export declare abstract class OAppLayoutBase {
    abstract useFlagIcons: boolean;
    F: any;
}
//# sourceMappingURL=o-app-layout-base.class.d.ts.map