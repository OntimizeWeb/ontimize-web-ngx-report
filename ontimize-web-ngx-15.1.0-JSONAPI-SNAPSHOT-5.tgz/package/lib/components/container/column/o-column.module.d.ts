import * as i0 from "@angular/core";
import * as i1 from "./o-column.component";
import * as i2 from "@angular/common";
import * as i3 from "../../../shared/shared.module";
export declare class OColumnModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OColumnModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OColumnModule, [typeof i1.OColumnComponent], [typeof i2.CommonModule, typeof i3.OSharedModule], [typeof i1.OColumnComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OColumnModule>;
}
//# sourceMappingURL=o-column.module.d.ts.map