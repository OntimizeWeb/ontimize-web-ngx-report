import { Injector, OnInit, QueryList } from '@angular/core';
import type { OColumn } from '../../../column/o-column.class';
import { OTableComponent } from '../../../o-table.component';
import { OFilterColumn, OTableColumnsFilterColumnComponent } from './columns/o-table-columns-filter-column.component';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_TABLE_COLUMN_FILTER: string[];
export declare const DEFAULT_OUTPUTS_O_TABLE_COLUMN_FILTER: any[];
export declare class OTableColumnsFilterComponent implements OnInit {
    protected injector: Injector;
    protected table: OTableComponent;
    static DEFAULT_COMPARISON_TYPE: string;
    static MODEL_COMPARISON_TYPE: string;
    static OTableColumnsFilterModes: string[];
    protected _columns: string;
    protected _mode: string;
    preloadValues: boolean;
    get mode(): string;
    set mode(val: string);
    protected _columnsArray: Array<OFilterColumn>;
    protected columnsComparisonProperty: object;
    filterColumns: QueryList<OTableColumnsFilterColumnComponent>;
    constructor(injector: Injector, table: OTableComponent);
    ngOnInit(): void;
    ngAfterContentInit(): void;
    isColumnFilterable(attr: string): boolean;
    getSortValueOfFilterColumn(attr: string): string;
    getStartViewValueOfFilterColumn(attr: string): string;
    getColumnComparisonValue(column: OColumn, val: any): any;
    set columns(arg: string);
    set columnsArray(arg: OFilterColumn[]);
    get columnsArray(): OFilterColumn[];
    parseColumns(columns: string): OFilterColumn[];
    parseFilterColumns(columns: QueryList<OTableColumnsFilterColumnComponent>): OFilterColumn[];
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableColumnsFilterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTableColumnsFilterComponent, "o-table-columns-filter", never, { "columns": "columns"; "preloadValues": "preload-values"; "mode": "mode"; }, {}, ["filterColumns"], never, false, never>;
}
//# sourceMappingURL=o-table-columns-filter.component.d.ts.map