import { OServiceBasePermissions } from './o-service-base-permissions.type';
export type OTreePermissions = OServiceBasePermissions;
//# sourceMappingURL=o-tree-permissions.type.d.ts.map