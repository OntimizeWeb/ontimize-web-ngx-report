import { OGridComponent } from '../../components/grid/o-grid.component';
import { AbstractComponentStateService } from './o-component-state.service';
import { OGridComponentStateClass } from './o-grid-component-state.class';
import * as i0 from "@angular/core";
export declare class OGridComponentStateService extends AbstractComponentStateService<OGridComponentStateClass, OGridComponent> {
    initialize(component: OGridComponent): void;
    initializeState(state: OGridComponentStateClass): void;
    getDataToStore(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<OGridComponentStateService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OGridComponentStateService>;
}
//# sourceMappingURL=o-grid-component-state.service.d.ts.map