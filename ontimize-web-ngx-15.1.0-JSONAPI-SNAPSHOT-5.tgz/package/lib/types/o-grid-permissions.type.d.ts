import { OServiceBasePermissions } from './o-service-base-permissions.type';
export type OGridPermissions = OServiceBasePermissions;
//# sourceMappingURL=o-grid-permissions.type.d.ts.map