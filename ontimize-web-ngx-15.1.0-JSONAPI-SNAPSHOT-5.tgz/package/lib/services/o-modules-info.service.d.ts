import { Injector } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export declare class OModulesInfoService {
    protected injector: Injector;
    protected router: Router;
    private subject;
    constructor(injector: Injector, router: Router);
    getModuleChangeObservable(): Observable<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OModulesInfoService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OModulesInfoService>;
}
//# sourceMappingURL=o-modules-info.service.d.ts.map