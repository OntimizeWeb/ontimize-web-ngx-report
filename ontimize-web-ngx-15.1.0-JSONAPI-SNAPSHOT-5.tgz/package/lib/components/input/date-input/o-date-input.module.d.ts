import * as i0 from "@angular/core";
import * as i1 from "./o-date-input.component";
import * as i2 from "@angular/common";
import * as i3 from "../../../shared/shared.module";
export declare class ODateInputModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ODateInputModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ODateInputModule, [typeof i1.ODateInputComponent], [typeof i2.CommonModule, typeof i3.OSharedModule], [typeof i1.ODateInputComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ODateInputModule>;
}
//# sourceMappingURL=o-date-input.module.d.ts.map