import { EventEmitter, TemplateRef } from '@angular/core';
import * as i0 from "@angular/core";
export declare const DEFAULT_OUTPUTS_O_TABLE_ROW_EXPANDABLE: string[];
export declare const DEFAULT_INPUTS_O_TABLE_ROW_EXPANDABLE: string[];
export declare class OTableRowExpandedChange {
    data: any;
    rowIndex: number;
}
export declare class OTableRowExpandableComponent {
    templateRef: TemplateRef<any>;
    onExpanded: EventEmitter<OTableRowExpandedChange>;
    onCollapsed: EventEmitter<OTableRowExpandedChange>;
    private _iconCollapse;
    private _iconExpand;
    expandableColumnVisible: boolean;
    multiple: boolean;
    set iconCollapse(value: string);
    get iconCollapse(): string;
    set iconExpand(value: string);
    get iconExpand(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableRowExpandableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTableRowExpandableComponent, "o-table-row-expandable", never, { "iconExpand": { "alias": "icon-expand"; "required": false; }; "iconCollapse": { "alias": "icon-collapse"; "required": false; }; "expandableColumnVisible": { "alias": "expandable-column-visible"; "required": false; }; "multiple": { "alias": "multiple"; "required": false; }; }, { "onExpanded": "onExpanded"; "onCollapsed": "onCollapsed"; }, ["templateRef"], never, true, never>;
}
//# sourceMappingURL=o-table-row-expandable.component.d.ts.map