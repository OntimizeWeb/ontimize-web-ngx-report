import { ElementRef, Injector, OnDestroy } from '@angular/core';
import { OSkeletonComponent } from '../../../o-skeleton.component';
import * as i0 from "@angular/core";
export declare class OTableSkeletonComponent extends OSkeletonComponent implements OnDestroy {
    protected elRef: ElementRef;
    protected injector: Injector;
    constructor(elRef: ElementRef, injector: Injector);
    get count(): number[];
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableSkeletonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTableSkeletonComponent, "o-table-skeleton", never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=o-table-skeleton.component.d.ts.map