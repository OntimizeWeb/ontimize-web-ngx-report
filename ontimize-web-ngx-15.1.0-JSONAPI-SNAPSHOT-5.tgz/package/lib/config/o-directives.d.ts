import { OListItemDirective } from '../components/list/list-item/o-list-item.directive';
import { OLockerDirective } from '../directives/locker.directive';
import { OHiddenDirective } from '../directives/o-hidden.directive';
import { OMatErrorDirective } from '../directives/o-mat-error.directive';
import { OTabGroupDirective } from '../directives/o-tab-group.directive';
export declare const ONTIMIZE_DIRECTIVES: (typeof OListItemDirective | typeof OMatErrorDirective | typeof OLockerDirective | typeof OHiddenDirective | typeof OTabGroupDirective)[];
//# sourceMappingURL=o-directives.d.ts.map