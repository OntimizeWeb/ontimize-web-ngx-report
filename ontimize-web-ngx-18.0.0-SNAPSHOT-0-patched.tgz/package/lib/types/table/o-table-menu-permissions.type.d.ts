import { OPermissions } from '../o-permissions.type';
export type OTableMenuPermissions = {
    visible: boolean;
    enabled: boolean;
    items?: OPermissions[];
};
//# sourceMappingURL=o-table-menu-permissions.type.d.ts.map