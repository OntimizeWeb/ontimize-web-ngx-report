import * as i0 from "@angular/core";
import * as i1 from "./o-slider.component";
import * as i2 from "@angular/common";
import * as i3 from "../../../shared/shared.module";
export declare class OSliderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OSliderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OSliderModule, [typeof i1.OSliderComponent], [typeof i2.CommonModule, typeof i3.OSharedModule], [typeof i1.OSliderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OSliderModule>;
}
//# sourceMappingURL=o-slider.module.d.ts.map