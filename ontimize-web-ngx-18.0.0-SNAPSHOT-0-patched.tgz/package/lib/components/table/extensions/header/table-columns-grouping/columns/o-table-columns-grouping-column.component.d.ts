import { GroupedColumnAggregateConfiguration } from '../../../../../../interfaces/o-table-columns-grouping-interface';
import { AggregateFunction } from '../../../../../../types/aggregate-function.type';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_TABLE_COLUMN_GROUPING_COLUMN: string[];
export declare class OTableColumnsGroupingColumnComponent {
    attr: string;
    title: string;
    aggregateName: string;
    private _aggregate;
    aggregateFunction: AggregateFunction;
    expandGroupsSameLevel: boolean;
    changeAggregateSameLevel: boolean;
    set aggregate(value: string);
    get aggregate(): string;
    getAggregateConfiguration(): GroupedColumnAggregateConfiguration;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableColumnsGroupingColumnComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTableColumnsGroupingColumnComponent, "o-table-columns-grouping-column", never, { "attr": { "alias": "attr"; "required": false; }; "title": { "alias": "title"; "required": false; }; "aggregateName": { "alias": "aggregate-name"; "required": false; }; "aggregate": { "alias": "aggregate"; "required": false; }; "aggregateFunction": { "alias": "aggregate-function"; "required": false; }; "expandGroupsSameLevel": { "alias": "expand-groups-same-level"; "required": false; }; "changeAggregateSameLevel": { "alias": "change-aggregate-same-level"; "required": false; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=o-table-columns-grouping-column.component.d.ts.map