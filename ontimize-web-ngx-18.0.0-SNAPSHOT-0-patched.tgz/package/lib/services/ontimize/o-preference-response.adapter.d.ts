import { HttpResponse } from "@angular/common/http";
import { OntimizeServiceResponseAdapter } from "./ontimize-service-response.adapter";
import { OntimizeServiceResponse } from "./ontimize-service-response.class";
import * as i0 from "@angular/core";
export declare class OPreferenceResponseAdapter extends OntimizeServiceResponseAdapter {
    adapt(res: HttpResponse<any>): OntimizeServiceResponse;
    static ɵfac: i0.ɵɵFactoryDeclaration<OPreferenceResponseAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OPreferenceResponseAdapter>;
}
//# sourceMappingURL=o-preference-response.adapter.d.ts.map