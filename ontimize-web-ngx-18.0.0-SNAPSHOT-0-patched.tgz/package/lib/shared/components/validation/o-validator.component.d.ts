import { Injector } from '@angular/core';
import { AsyncValidatorFn, ValidatorFn } from '@angular/forms';
import { ErrorData } from '../../../types/error-data.type';
import { OErrorComponent } from './o-error.component';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_VALIDATOR: string[];
export declare class OValidatorComponent {
    protected injector: Injector;
    validatorFn: ValidatorFn;
    asyncValidatorFn: AsyncValidatorFn;
    errorName: string;
    errorText: string;
    protected errorsData: ErrorData[];
    constructor(injector: Injector);
    registerError(oError: OErrorComponent): void;
    getValidatorFn(): ValidatorFn;
    getAsyncValidatorFn(): AsyncValidatorFn;
    getErrorsData(): ErrorData[];
    static ɵfac: i0.ɵɵFactoryDeclaration<OValidatorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OValidatorComponent, "o-validator", never, { "validatorFn": { "alias": "validator-function"; "required": false; }; "asyncValidatorFn": { "alias": "async-validator-function"; "required": false; }; "errorName": { "alias": "error-name"; "required": false; }; "errorText": { "alias": "error-text"; "required": false; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=o-validator.component.d.ts.map