import { Injector } from '@angular/core';
import { Observable } from 'rxjs';
import { IPermissionsService } from '../../interfaces/permissions-service.interface';
import { OntimizePermissionsConfig } from '../../types/ontimize-permissions-config.type';
import { OntimizeBasePermissionsService } from './ontimize-base-permissions-service.class';
import * as i0 from "@angular/core";
export declare class OntimizePermissionsService extends OntimizeBasePermissionsService implements IPermissionsService {
    protected injector: Injector;
    entity: string;
    keyColumn: string;
    valueColumn: string;
    protected _user: string;
    protected _urlBase: string;
    constructor(injector: Injector);
    getDefaultServiceConfiguration(): any;
    configureService(permissionsConfig: OntimizePermissionsConfig): void;
    loadPermissions(): Observable<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OntimizePermissionsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OntimizePermissionsService>;
}
//# sourceMappingURL=ontimize-permissions.service.d.ts.map