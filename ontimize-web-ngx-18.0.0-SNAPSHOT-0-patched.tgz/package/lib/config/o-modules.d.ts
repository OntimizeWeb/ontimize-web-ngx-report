import { HttpClient } from '@angular/common/http';
import { Injector } from '@angular/core';
import { AppConfig } from '../config/app-config';
import { OTranslateHttpLoader } from '../services/translate/o-translate-http-loader';
import { OTranslateParser } from '../services/translate/o-translate.parser';
import * as i0 from "@angular/core";
export declare class OntimizeWebTranslateModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OntimizeWebTranslateModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OntimizeWebTranslateModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OntimizeWebTranslateModule>;
}
export declare const INTERNAL_ONTIMIZE_MODULES_EXPORTED: any;
export declare function OHttpLoaderFactory(http: HttpClient, injector: Injector, appConfig: AppConfig): OTranslateHttpLoader;
export declare function OTranslateParserFactory(): OTranslateParser;
export declare const INTERNAL_ONTIMIZE_MODULES: any;
export declare const ONTIMIZE_MODULES: any;
export declare const ONTIMIZE_MODULES_WITHOUT_ANIMATIONS: any;
//# sourceMappingURL=o-modules.d.ts.map