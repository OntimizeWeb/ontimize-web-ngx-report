import { Injector } from "@angular/core";
import { IExportDataProvider } from "../interfaces/export-data-provider.interface";
import { OTableExportData } from "../interfaces/o-table-export-data.interface";
import { OntimizeExportDataBaseProviderService } from "./ontimize-export-data-base-provider.service";
import * as i0 from "@angular/core";
export declare class OntimizeExportDataProviderService extends OntimizeExportDataBaseProviderService implements IExportDataProvider {
    protected injector: Injector;
    constructor(injector: Injector);
    getExportConfiguration(): OTableExportData;
    static ɵfac: i0.ɵɵFactoryDeclaration<OntimizeExportDataProviderService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OntimizeExportDataProviderService>;
}
//# sourceMappingURL=ontimize-export-data-provider.service.d.ts.map