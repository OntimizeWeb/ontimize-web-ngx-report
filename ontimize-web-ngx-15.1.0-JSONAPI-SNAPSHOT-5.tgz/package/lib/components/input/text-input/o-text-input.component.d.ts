import { ElementRef, Injector, OnInit, QueryList } from '@angular/core';
import { ValidatorFn } from '@angular/forms';
import { OFormComponent } from '../../form/o-form.component';
import { OFormDataComponent } from '../../o-form-data-component.class';
import { OMatPrefix } from '../../../directives/o-mat-prefix.directive';
import { OMatSuffix } from '../../../directives/o-mat-suffix.directive';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_TEXT_INPUT: string[];
export declare class OTextInputComponent extends OFormDataComponent implements OnInit {
    _prefixChildren: QueryList<OMatPrefix>;
    _suffixChildren: QueryList<OMatSuffix>;
    protected _minLength: number;
    protected _maxLength: number;
    constructor(form: OFormComponent, elRef: ElementRef, injector: Injector);
    ngOnInit(): void;
    resolveValidators(): ValidatorFn[];
    set minLength(val: number);
    get minLength(): number;
    set maxLength(val: number);
    get maxLength(): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTextInputComponent, [{ optional: true; }, null, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTextInputComponent, "o-text-input", never, { "minLength": "min-length"; "maxLength": "max-length"; }, {}, ["_prefixChildren", "_suffixChildren"], ["[oMatPrefix]", "[oMatSuffix]"], false, never>;
}
//# sourceMappingURL=o-text-input.component.d.ts.map