export declare class OPreferenceMappingUtils {
    static readonly STANDARDREPORTMAPPING: {
        ID: string;
        NAME: string;
        DESCRIPTION: string;
        ENTITY: string;
        SERVICE: string;
        TYPE: string;
        PREFERENCES: string;
    };
    static readonly STANDARDINSERTREPORTMAPPING: {
        id: string;
        name: string;
        description: string;
        entity: string;
        service: string;
        type: string;
        params: string;
    };
    static readonly STANDARDPARAMETERMAPPING: {
        name: string;
        description: string;
    };
    static readonly ONTIMIZEPARAMETERMAPPING: {
        reportParameterName: string;
        reportParameterDescription: string;
    };
    static readonly ONTIMIZEPREFERENCESMAPPING: {
        preferenceid: string;
        preferencename: string;
        preferencedescription: string;
        preferenceentity: string;
        preferenceservice: string;
        preferencetype: string;
        preferenceparameters: string;
    };
    static readonly JSONAPIPREFERENCESMAPPING: {
        preferenceid: string;
        preferencename: string;
        preferencedescription: string;
        preferenceentity: string;
        preferenceservice: string;
        preferencetype: string;
        preferenceparameters: string;
    };
    static transformKeys(data: string[], keyMapping: {
        [key: string]: string;
    }): string[];
    private static mapObjectKeys;
    static transformData(data: {
        [key: string]: any;
    } | {
        [key: string]: any;
    }[], keyMapping: {
        [key: string]: string;
    }, parameterKeyMapping?: {
        [key: string]: string;
    }): {
        [key: string]: any;
    }[] | {
        [key: string]: any;
    };
    static standarDataMapping(array: {
        [key: string]: any;
    } | {
        [key: string]: any;
    }[]): {
        [key: string]: any;
    }[] | {
        [key: string]: any;
    };
    static standarMappingKeys(array: string[]): string[];
    static ontimizePreferencesMappingKeys(array: string[]): string[];
    static ontimizePreferencesDataMapping(array: {
        [key: string]: any;
    } | {
        [key: string]: any;
    }[]): {
        [key: string]: any;
    }[] | {
        [key: string]: any;
    };
    static jsonApiPreferencesMappingKeys(array: string[]): string[];
    static jsonApiPreferencesDataMapping(array: {
        [key: string]: any;
    } | {
        [key: string]: any;
    }[]): {
        [key: string]: any;
    }[] | {
        [key: string]: any;
    };
}
//# sourceMappingURL=preference-mapping-util.d.ts.map