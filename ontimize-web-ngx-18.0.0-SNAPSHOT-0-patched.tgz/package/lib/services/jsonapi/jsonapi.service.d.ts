import { HttpHeaders } from '@angular/common/http';
import { Injector } from '@angular/core';
import { Observable } from 'rxjs';
import { AppConfig } from '../../config/app-config';
import { IAuthService } from '../../interfaces/auth-service.interface';
import { JSONAPIResponse } from '../../interfaces/jsonapi-response.interface';
import { JSONAPIQueryParameter } from '../../types/json-query-parameter.type';
import { BaseDataService } from '../base-data-service.class';
import * as i0 from "@angular/core";
export declare class JSONAPIService extends BaseDataService<JSONAPIResponse> implements IAuthService {
    protected injector: Injector;
    protected _startSessionPath: string;
    protected config: AppConfig;
    protected readonly DEFAULT_DELIMITER = "_";
    delimiter: string;
    constructor(injector: Injector);
    startsession(user: string, password: string): Observable<string | number>;
    endsession(user: string, sessionId: number): Observable<number>;
    protected buildHeaders(): HttpHeaders;
    hassession(user: string, sessionId: any): Observable<boolean>;
    configureService(config: any): void;
    protected getValidDelimiter(delimiter?: string): string;
    query(queryParams: JSONAPIQueryParameter): Observable<JSONAPIResponse>;
    advancedQuery(queryParams: JSONAPIQueryParameter): Observable<JSONAPIResponse>;
    queryById(queryParams: JSONAPIQueryParameter): Observable<JSONAPIResponse>;
    protected serializeCompositeKey(keyObj: string | object): string;
    protected parseNameConventionQueryParams(queryParams: JSONAPIQueryParameter): JSONAPIQueryParameter;
    insert(attributes: object, type: string): Observable<JSONAPIResponse>;
    update(id: string | object, attributes: object, type: string): Observable<JSONAPIResponse>;
    delete(id: object): Observable<JSONAPIResponse>;
    static ɵfac: i0.ɵɵFactoryDeclaration<JSONAPIService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<JSONAPIService>;
}
//# sourceMappingURL=jsonapi.service.d.ts.map