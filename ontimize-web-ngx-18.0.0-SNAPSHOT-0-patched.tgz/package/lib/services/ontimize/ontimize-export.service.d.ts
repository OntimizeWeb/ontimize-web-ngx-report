import { HttpHeaders } from '@angular/common/http';
import { Injector } from '@angular/core';
import { Observable, Subscriber } from 'rxjs';
import { IExportDataProvider } from '../../interfaces/export-data-provider.interface';
import { IExportService } from '../../interfaces/export-service.interface';
import { ServiceResponse } from '../../interfaces/service-response.interface';
import { BaseService } from '../base-service.class';
import * as i0 from "@angular/core";
export declare class OntimizeExportService extends BaseService<ServiceResponse> implements IExportService {
    protected injector: Injector;
    exportPath: string;
    downloadPath: string;
    servicePath: string;
    exportDataProvider: IExportDataProvider;
    constructor(injector: Injector);
    configureService(config: any): void;
    protected buildHeaders(): HttpHeaders;
    exportData(format: string): Observable<any>;
    protected parseSuccessfulExportDataResponse(format: string, resp: ServiceResponse, subscriber: Subscriber<ServiceResponse>): void;
    downloadFile(fileId: string, fileExtension: string): Observable<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OntimizeExportService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OntimizeExportService>;
}
//# sourceMappingURL=ontimize-export.service.d.ts.map