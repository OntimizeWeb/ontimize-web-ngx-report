import * as i0 from "@angular/core";
import * as i1 from "./o-nif-input.component";
export declare class ONIFInputModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ONIFInputModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ONIFInputModule, never, [typeof i1.ONIFInputComponent], [typeof i1.ONIFInputComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ONIFInputModule>;
}
//# sourceMappingURL=o-nif-input.module.d.ts.map