import * as i0 from "@angular/core";
import * as i1 from "./o-text-input.component";
export declare class OTextInputModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OTextInputModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OTextInputModule, never, [typeof i1.OTextInputComponent], [typeof i1.OTextInputComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OTextInputModule>;
}
//# sourceMappingURL=o-text-input.module.d.ts.map