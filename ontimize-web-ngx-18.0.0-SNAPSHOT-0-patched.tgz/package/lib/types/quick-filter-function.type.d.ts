import { Expression } from './expression.type';
export type QuickFilterFunction = (filter: string) => Expression | object;
//# sourceMappingURL=quick-filter-function.type.d.ts.map