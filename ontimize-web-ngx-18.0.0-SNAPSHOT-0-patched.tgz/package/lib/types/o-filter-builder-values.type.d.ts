export type OFilterBuilderValues = {
    attr: string;
    value: any;
};
export type OFilterBuilderStatus = {
    name: string;
    description?: string;
    'stored-filter'?: OFilterBuilderValues[];
};
//# sourceMappingURL=o-filter-builder-values.type.d.ts.map