import { HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { JSONAPIServiceResponse } from './jsonapi-service-response.class';
import { IServiceResponseAdapter } from '../../interfaces/service-response-adapter.interface';
import { JSONAPIContext } from '../../types/jsonapi-context.type';
import * as i0 from "@angular/core";
export declare class JSONAPIServiceResponseAdapter implements IServiceResponseAdapter<JSONAPIServiceResponse> {
    context: any;
    adapt(res: HttpResponse<any>): JSONAPIServiceResponse;
    adaptError(httpError: HttpErrorResponse): any;
    getErrorMessage(error: any): string;
    setContext(context: JSONAPIContext): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<JSONAPIServiceResponseAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<JSONAPIServiceResponseAdapter>;
}
//# sourceMappingURL=jsonapi-service-response.adapter.d.ts.map