import { ActivatedRouteSnapshot, CanActivateChild, CanActivateChildFn, Router, RouterStateSnapshot } from '@angular/router';
import { ShareCanActivateChildService } from '../share-can-activate-child.service';
import { SnackBarService } from '../snackbar.service';
import { PermissionsService } from './permissions.service';
import * as i0 from "@angular/core";
export declare class PermissionsGuardService implements CanActivateChild {
    protected router: Router;
    protected permissionsService: PermissionsService;
    protected snackBarService: SnackBarService;
    protected shareCanActivateChildService: ShareCanActivateChildService;
    constructor();
    canActivateChild(childRoute: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<PermissionsGuardService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PermissionsGuardService>;
}
export declare const permissionsGuard: CanActivateChildFn;
//# sourceMappingURL=permissions-can-activate.guard.d.ts.map