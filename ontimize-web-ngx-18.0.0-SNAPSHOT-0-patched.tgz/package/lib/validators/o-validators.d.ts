import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';
export declare const TWELVE_HOUR_FORMAT_PATTERN = "^(([0-9]|([01]?[0-9])):([0-9]|([0-5][0-9])) *([AaPp][Mm])*)$";
export declare const TWENTY_FOUR_HOUR_FORMAT_PATTERN = "^([0-9]|([01]?[0-9]|2[0-3])):[0-9]|([0-5][0-9])$";
export declare class OValidators {
    static twelveHourFormatValidator(control: AbstractControl): ValidationErrors;
    static twentyFourHourFormatValidator(control: AbstractControl): ValidationErrors;
    static emailValidator(control: AbstractControl): ValidationErrors;
    static phoneValidator(control: AbstractControl, countryCode?: any): ValidationErrors;
    static nifValidator(control: AbstractControl): ValidationErrors;
    static patternValidator(regex: RegExp, key: string): ValidatorFn;
    static createMinValidator(min: number): ValidatorFn;
    static createMaxValidator(max: number): ValidatorFn;
}
//# sourceMappingURL=o-validators.d.ts.map