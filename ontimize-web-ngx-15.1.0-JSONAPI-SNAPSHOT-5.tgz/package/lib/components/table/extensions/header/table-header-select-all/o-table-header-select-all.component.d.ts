import { OTableHeaderComponent } from "../table-header/o-table-header.component";
import { BehaviorSubject, Subscription } from "rxjs";
import type { OColumn } from "../../../column/o-column.class";
import { OTableBase } from "../../../o-table-base.class";
import * as i0 from "@angular/core";
export declare class OTableHeaderSelectAllComponent extends OTableHeaderComponent {
    table: OTableBase;
    column: OColumn;
    resizable: boolean;
    isAllSelected: BehaviorSubject<boolean>;
    isIndeterminate: BehaviorSubject<boolean>;
    selectionChangeSubscription: Subscription;
    constructor(table: OTableBase);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableHeaderSelectAllComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTableHeaderSelectAllComponent, "o-table-header-select-all", never, { "column": "column"; }, {}, never, never, false, never>;
}
//# sourceMappingURL=o-table-header-select-all.component.d.ts.map