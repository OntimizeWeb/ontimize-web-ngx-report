export type AggregateFunction = (value: any[]) => number;
//# sourceMappingURL=aggregate-function.type.d.ts.map