import { TranslateDefaultParser } from '@ngx-translate/core';
import * as i0 from "@angular/core";
export declare class OTranslateParser extends TranslateDefaultParser {
    templateMatcher: RegExp;
    interpolate(expr: string, params?: any): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTranslateParser, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OTranslateParser>;
}
//# sourceMappingURL=o-translate.parser.d.ts.map