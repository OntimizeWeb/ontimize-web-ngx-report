import { AfterViewInit, ElementRef, Injector, Renderer2 } from '@angular/core';
import { OListItemComponent } from '../../list-item/o-list-item.component';
import { OListItemCardRenderer } from '../o-list-item-card-renderer.class';
import * as i0 from "@angular/core";
export declare class OListItemCardComponent extends OListItemCardRenderer implements AfterViewInit {
    constructor(elRef: ElementRef, _renderer: Renderer2, _injector: Injector, _listItem: OListItemComponent);
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OListItemCardComponent, [null, null, null, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OListItemCardComponent, "o-list-item-card", never, {}, {}, never, never, true, never>;
}
//# sourceMappingURL=o-list-item-card.component.d.ts.map