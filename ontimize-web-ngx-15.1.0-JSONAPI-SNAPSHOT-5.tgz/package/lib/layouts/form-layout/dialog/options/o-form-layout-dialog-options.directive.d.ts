import { DialogPosition } from '@angular/material/dialog';
import { OFormLayoutManagerComponent } from '../../o-form-layout-manager.component';
import * as i0 from "@angular/core";
export declare class OFormLayoutDialogOptionsDirective {
    protected formLayoutManager: OFormLayoutManagerComponent;
    constructor(formLayoutManager: OFormLayoutManagerComponent);
    ngOnChanges(): void;
    width: string;
    minWidth: number | string;
    maxWidth: number | string;
    height: string;
    minHeight: number | string;
    maxHeight: number | string;
    class: string | string[];
    position: DialogPosition;
    backdropClass: string;
    protected _closeOnNavigation: boolean;
    set closeOnNavigation(value: boolean);
    protected _disableClose: boolean;
    set disableClose(value: boolean);
    title: string;
    labelColumns: string;
    separator: string;
    dialogTitleSeparator: any;
    getOptions(): {
        width: string;
        minWidth: string | number;
        maxWidth: string | number;
        height: string;
        minHeight: string | number;
        maxHeight: string | number;
        class: string | string[];
        position: DialogPosition;
        backdropClass: string;
        disableClose: boolean;
        closeOnNavigation: boolean;
        title: string;
        labelColumns: string;
        separator: string;
        dialogTitleSeparator: any;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<OFormLayoutDialogOptionsDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OFormLayoutDialogOptionsDirective, "o-form-layout-dialog-options, o-form-layout-manager[mode=\"dialog\"]", never, { "width": "width"; "minWidth": "min-width"; "maxWidth": "max-width"; "height": "height"; "minHeight": "min-height"; "maxHeight": "max-height"; "class": "class"; "position": "position"; "backdropClass": "backdrop-class"; "closeOnNavigation": "close-on-navigation"; "disableClose": "disable-close"; "title": "title"; "labelColumns": "label-columns"; "separator": "separator"; "dialogTitleSeparator": "dialog-title-separator"; }, {}, never, never, false, never>;
}
//# sourceMappingURL=o-form-layout-dialog-options.directive.d.ts.map