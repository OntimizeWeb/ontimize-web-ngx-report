export type OColumnTooltip = {
    value?: string;
    function?: (rowData: any) => any;
};
//# sourceMappingURL=o-column-tooltip.type.d.ts.map