import * as i0 from "@angular/core";
import * as i1 from "./o-form-container.component";
import * as i2 from "../../shared/shared.module";
import * as i3 from "@angular/common";
export declare class OFormContainerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OFormContainerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OFormContainerModule, [typeof i1.OFormContainerComponent], [typeof i2.OSharedModule, typeof i3.CommonModule], [typeof i1.OFormContainerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OFormContainerModule>;
}
//# sourceMappingURL=o-form-container.module.d.ts.map