export declare const O_TABLE_CELL_RENDERERS_INPUTS: string[];
export declare const O_TABLE_CELL_RENDERERS_OUTPUTS: string[];
//# sourceMappingURL=cell-renderer-inputs.d.ts.map