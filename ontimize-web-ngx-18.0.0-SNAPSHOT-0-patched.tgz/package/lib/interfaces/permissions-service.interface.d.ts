export interface IPermissionsService {
    loadPermissions(): any;
}
//# sourceMappingURL=permissions-service.interface.d.ts.map