import * as i0 from "@angular/core";
import * as i1 from "./o-time-input.component";
import * as i2 from "@angular/common";
import * as i3 from "../date-input/o-date-input.module";
import * as i4 from "../hour-input/o-hour-input.module";
import * as i5 from "../../../shared/shared.module";
export declare class OTimeInputModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OTimeInputModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OTimeInputModule, [typeof i1.OTimeInputComponent], [typeof i2.CommonModule, typeof i3.ODateInputModule, typeof i4.OHourInputModule, typeof i5.OSharedModule], [typeof i1.OTimeInputComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OTimeInputModule>;
}
//# sourceMappingURL=o-time-input.module.d.ts.map